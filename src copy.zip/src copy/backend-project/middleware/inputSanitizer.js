const validator = require("validator")

// Sanitize string input to prevent XSS and injection attacks
const sanitizeString = (str) => {
  if (typeof str !== "string") return str

  // Trim whitespace
  str = str.trim()

  // Escape HTML to prevent XSS
  str = validator.escape(str)

  // Remove any potential SQL injection patterns (even though we use MongoDB)
  str = str.replace(/['";\\]/g, "")

  return str
}

// Sanitize email
const sanitizeEmail = (email) => {
  if (typeof email !== "string") return email

  email = email.trim().toLowerCase()

  // Normalize and validate email
  if (validator.isEmail(email)) {
    return validator.normalizeEmail(email)
  }

  return email
}

// Sanitize phone number
const sanitizePhone = (phone) => {
  if (typeof phone !== "string") return phone

  // Remove all non-numeric characters except + at the start
  phone = phone.trim()
  if (phone.startsWith("+")) {
    return "+" + phone.slice(1).replace(/\D/g, "")
  }
  return phone.replace(/\D/g, "")
}

// Middleware to sanitize request body
const sanitizeBody = (req, res, next) => {
  if (req.body) {
    Object.keys(req.body).forEach((key) => {
      const value = req.body[key]

      if (typeof value === "string") {
        // Special handling for specific fields
        if (key === "email") {
          req.body[key] = sanitizeEmail(value)
        } else if (key === "phone" || key === "phoneNumber") {
          req.body[key] = sanitizePhone(value)
        } else if (key !== "password" && key !== "confirmPassword") {
          // Don't sanitize passwords as they may contain special characters
          req.body[key] = sanitizeString(value)
        }
      }
    })
  }

  next()
}

// Validate patient signup input
const validatePatientSignup = (req, res, next) => {
  const { name, email, phone, gender, password, confirmPassword, termsAccepted } = req.body

  const errors = []

  // Validate name
  if (!name || name.trim().length < 2) {
    errors.push("Name must be at least 2 characters long")
  }

  if (name && name.length > 100) {
    errors.push("Name must not exceed 100 characters")
  }

  // Validate email
  if (!email || !validator.isEmail(email)) {
    errors.push("Please provide a valid email address")
  }

  // Validate phone
  if (!phone || phone.length < 10) {
    errors.push("Please provide a valid phone number")
  }

  // Validate gender
  if (!gender || !["male", "female", "other"].includes(gender.toLowerCase())) {
    errors.push("Please select a valid gender")
  }

  // Validate password
  if (!password || password.length < 8) {
    errors.push("Password must be at least 8 characters long")
  }

  // Check password strength
  if (password) {
    const hasUpperCase = /[A-Z]/.test(password)
    const hasLowerCase = /[a-z]/.test(password)
    const hasNumber = /[0-9]/.test(password)

    if (!hasUpperCase || !hasLowerCase || !hasNumber) {
      errors.push("Password must contain uppercase, lowercase, and number")
    }
  }

  // Validate password confirmation
  if (password !== confirmPassword) {
    errors.push("Passwords do not match")
  }

  // Validate terms acceptance
  if (!termsAccepted || termsAccepted !== true) {
    errors.push("You must accept the terms and conditions")
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: "Validation failed",
      errors: errors,
    })
  }

  next()
}

// Validate patient login input
const validatePatientLogin = (req, res, next) => {
  const { email, password } = req.body

  const errors = []

  // Validate email
  if (!email || !validator.isEmail(email)) {
    errors.push("Please provide a valid email address")
  }

  // Validate password
  if (!password || password.length < 1) {
    errors.push("Please provide a password")
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: "Validation failed",
      errors: errors,
    })
  }

  next()
}

module.exports = {
  sanitizeBody,
  sanitizeString,
  sanitizeEmail,
  sanitizePhone,
  validatePatientSignup,
  validatePatientLogin,
}
