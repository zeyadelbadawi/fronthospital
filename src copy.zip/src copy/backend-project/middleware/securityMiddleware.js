const helmet = require("helmet")
const mongoSanitize = require("express-mongo-sanitize")
const xss = require("xss-clean")

const securityMiddleware = (app) => {
  // Set security headers
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          scriptSrc: ["'self'"],
          imgSrc: ["'self'", "data:", "https:"],
        },
      },
      hsts: {
        maxAge: 31536000,
        includeSubDomains: true,
        preload: true,
      },
    }),
  )

  // Sanitize data against NoSQL injection
  app.use(mongoSanitize())

  // Sanitize data against XSS
  app.use(xss())

  // Prevent parameter pollution
  app.use((req, res, next) => {
    // Remove duplicate parameters
    for (const key in req.body) {
      if (Array.isArray(req.body[key])) {
        req.body[key] = req.body[key][0]
      }
    }
    next()
  })
}

module.exports = securityMiddleware
