// models/Checks.js

const mongoose = require("mongoose")

const checksSchema = new mongoose.Schema(
  {
    patientId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Patient",
      required: true,
    },

    programId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
    },

    moneyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Money",
      required: true,
    },

    checkNumber: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    amount: {
      type: Number,
      required: true,
      min: [0.01, "Amount must be greater than 0"],
    },

    dueDate: {
      type: Date,
      required: true,
      validate: {
        validator: (value) => value >= new Date().setHours(0, 0, 0, 0),
        message: "Due date cannot be in the past",
      },
    },

    bankName: {
      type: String,
      trim: true,
      maxlength: [100, "Bank name cannot exceed 100 characters"],
    },

    notes: {
      type: String,
      trim: true,
      maxlength: [500, "Notes cannot exceed 500 characters"],
    },

    status: {
      type: String,
      enum: ["pending", "deposited", "cleared", "bounced", "cancelled"],
      default: "pending",
    },

    depositedDate: {
      type: Date,
    },

    clearedDate: {
      type: Date,
    },

    bouncedDate: {
      type: Date,
    },

    bouncedReason: {
      type: String,
      trim: true,
    },

    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  },
)

// Indexes for better performance
checksSchema.index({ patientId: 1, status: 1 })
checksSchema.index({ dueDate: 1, status: 1 })
checksSchema.index({ moneyId: 1 })

// Virtual for check age (days since creation)
checksSchema.virtual("checkAge").get(function () {
  return Math.floor((new Date() - this.createdAt) / (1000 * 60 * 60 * 24))
})

// Virtual for days until due
checksSchema.virtual("daysUntilDue").get(function () {
  return Math.floor((this.dueDate - new Date()) / (1000 * 60 * 60 * 24))
})

// Virtual for overdue status
checksSchema.virtual("isOverdue").get(function () {
  return this.status === "pending" && new Date() > this.dueDate
})

// Pre-save middleware for validation
checksSchema.pre("save", function (next) {
  // Ensure deposited date is set when status is deposited
  if (this.status === "deposited" && !this.depositedDate) {
    this.depositedDate = new Date()
  }

  // Ensure cleared date is set when status is cleared
  if (this.status === "cleared" && !this.clearedDate) {
    this.clearedDate = new Date()
  }

  // Ensure bounced date is set when status is bounced
  if (this.status === "bounced" && !this.bouncedDate) {
    this.bouncedDate = new Date()
  }

  next()
})

const Checks = mongoose.model("Checks", checksSchema)

module.exports = Checks
