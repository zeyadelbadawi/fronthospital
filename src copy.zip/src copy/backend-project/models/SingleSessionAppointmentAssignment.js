const mongoose = require("mongoose")

const singleSessionAppointmentAssignmentSchema = new mongoose.Schema(
    {
        appointmentId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "SingleProgram",
            required: true,
        },
        doctorId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Doctor",
            required: true,
        },
        patientId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Patient",
            required: true,
        },
        department: {
            type: String,
            required: true,
            enum: ["speech", "physical_therapy", "Psychotherapy", "ABA", "occupational_therapy", "special_education"],
        },
        status: {
            type: String,
            enum: ["active", "inactive"],
            default: "active",
        },
        assignedAt: {
            type: Date,
            default: Date.now,
        },
        assignedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Admin",
            required: true,
        },
    },
    { timestamps: true },
)

// Index for faster queries
singleSessionAppointmentAssignmentSchema.index({ appointmentId: 1, department: 1 })
singleSessionAppointmentAssignmentSchema.index({ doctorId: 1, status: 1 })
singleSessionAppointmentAssignmentSchema.index({ patientId: 1 })

const SingleSessionAppointmentAssignment = mongoose.model(
    "SingleSessionAppointmentAssignment",
    singleSessionAppointmentAssignmentSchema,
)

module.exports = SingleSessionAppointmentAssignment
