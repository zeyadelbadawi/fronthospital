const mongoose = require("mongoose")

const doctorFileSchema = new mongoose.Schema(
  {
    doctorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Doctor",
      required: true,
    },
    departmentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Department",
      required: true,
    },
    fileName: {
      type: String,
      required: true,
    },
    uniqueName: {
      type: String,
      required: true,
    },
    fullPath: {
      type: String,
      required: true,
    },
    quarterOfYear: {
      type: Number,
      enum: [1, 2, 3, 4],
      required: true,
    },
    year: {
      type: Number,
      required: true,
    },
    // Additional fields can be added here if needed
  },
  { timestamps: true },
)

const DoctorFile = mongoose.model("DoctorFile", doctorFileSchema)
module.exports = DoctorFile
