const mongoose = require("mongoose")

const schoolPlanSchema = new mongoose.Schema(
  {
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Patient",
      required: true,
    },
    unicValue: {
      type: String,
      required: true,
      trim: true,
    },
    title: {
      type: String,
      default: "School Program Plan",
    },
    filePath: {
      type: String,
      default: "",
    },
    fileName: {
      type: String,
      default: "",
    },
    programDescription: {
      type: String,
      default: "",
    },
    planContent: {
      type: String,
      default: "",
    },
    isLocked: {
      type: Boolean,
      default: false,
    },
    lockedAt: {
      type: Date,
      default: null,
    },
    lastModified: {
      type: Date,
      default: Date.now,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
    updatedAt: {
      type: Date,
      default: Date.now,
    },
    status: {
      type: String,
      enum: ["draft", "active", "completed", "archived"],
      default: "draft",
    },
  },
  {
    timestamps: true,
  },
)

// Create compound index for patient + unicValue (unique combination)
schoolPlanSchema.index({ patient: 1, unicValue: 1 }, { unique: true })

// Update the updatedAt field before saving
schoolPlanSchema.pre("save", function (next) {
  this.updatedAt = new Date()
  this.lastModified = new Date()
  next()
})

module.exports = mongoose.model("SchoolPlan", schoolPlanSchema)
