const mongoose = require("mongoose")

const fullProgramSchema = new mongoose.Schema(
  {
    patientid: { type: mongoose.Schema.Types.ObjectId, ref: "Patient", required: true },
    date: { type: Date, required: true },
    time: { type: String, required: true },
    description: { type: String, required: true },
    status: { type: String, default: "not active" },

    // Payment Tracking Fields
    programType: { type: String, required: true }, // "full_program", "school_evaluation", "single_session"
    totalAmount: { type: Number, required: true }, // Total amount to be paid
    paidAmount: { type: Number, default: 0 }, // Amount already paid
    remainingAmount: { type: Number, required: true }, // Amount remaining
    paymentStatus: {
      type: String,
      enum: ["PENDING", "PARTIALLY_PAID", "FULLY_PAID"],
      default: "PENDING",
    },
    paymentMethod: {
      type: String,
      enum: ["CASH", "INSTALLMENT", "MIXED", "BANK_TRANSFER"],
      default: "CASH",
    },
    transferScreenshot: {
      type: String,
      default: null,
    },

    // Assignment tracking
    isAssigned: { type: Boolean, default: false },
    assignmentDate: { type: Date },
    subscriptionEndDate: { type: Date },

    selectedDepartments: {
      type: [String],
      default: ["ABA", "Speech", "SpecialEducation", "PhysicalTherapy", "OccupationalTherapy", "Psychotherapy"],
      enum: ["ABA", "Speech", "SpecialEducation", "PhysicalTherapy", "OccupationalTherapy", "Psychotherapy"],
    },
    doctorNotes: {
      type: String,
      default: null,
    },
    departmentSelectionDate: {
      type: Date,
      default: null,
    },
    selectedByDoctor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Doctor",
      default: null,
    },
  },
  { timestamps: true },
)

// Virtual for payment completion percentage
fullProgramSchema.virtual("paymentPercentage").get(function () {
  return this.totalAmount > 0 ? Math.round((this.paidAmount / this.totalAmount) * 100) : 0
})

// Method to update payment status
fullProgramSchema.methods.updatePaymentStatus = function () {
  if (this.paidAmount >= this.totalAmount) {
    this.paymentStatus = "FULLY_PAID"
    this.remainingAmount = 0
  } else if (this.paidAmount > 0) {
    this.paymentStatus = "PARTIALLY_PAID"
    this.remainingAmount = this.totalAmount - this.paidAmount
  } else {
    this.paymentStatus = "PENDING"
    this.remainingAmount = this.totalAmount
  }
}

const FullProgram = mongoose.model("FullProgram", fullProgramSchema)
module.exports = FullProgram
