const mongoose = require("mongoose")

const doctorStudentAssignmentSchema = new mongoose.Schema(
  {
    doctor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Doctor",
      required: true,
    },
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Patient",
      required: true,
    },
    department: {
      type: String,
      required: true,
      enum: ["ABA", "physicalTherapy", "OccupationalTherapy", "SpecialEducation", "speech", "Psychotherapy"],
    },
    assignedDate: {
      type: Date,
      default: Date.now,
    },
    subscriptionEndDate: {
      type: Date,
      required: true,
    },
    status: {
      type: String,
      enum: ["active", "completed", "cancelled"],
      default: "active",
    },
    notes: {
      type: String,
      default: "",
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  },
  {
    timestamps: true,
  },
)

// Index for efficient queries
doctorStudentAssignmentSchema.index({ doctor: 1, department: 1 })
doctorStudentAssignmentSchema.index({ patient: 1, department: 1 })
doctorStudentAssignmentSchema.index({ subscriptionEndDate: 1 })

const DoctorStudentAssignment = mongoose.model("DoctorStudentAssignment", doctorStudentAssignmentSchema)

module.exports = DoctorStudentAssignment
