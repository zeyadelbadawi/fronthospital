const mongoose = require('mongoose');

const PatientoccupationalTherapyAssignmentSchemaS = new mongoose.Schema(
  {
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Patient',
      required: true,
    },
    assignedDate: {
      type: Date,
      default: Date.now,
    },
    status: {
      type: String,
      enum: ['active', 'completed', 'suspended'],
      default: 'active',
    },
    notes: {
      type: String,
      required: false,
    },
        programId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "SingleProgram",
          required: false,
        },
        sessionNumber: {
          type: Number,
          default: 1,
        },
        completedAt: {
          type: Date,
          required: false,
        },
        cancelledAt: {
          type: Date,
          required: false,
        },
  },
  { timestamps: true },
);

// Index for better query performance
PatientoccupationalTherapyAssignmentSchemaS.index({ patient: 1, sessionNumber: 1 })
PatientoccupationalTherapyAssignmentSchemaS.index({ status: 1 })


const PatientoccupationalTherapyAssignmentS = mongoose.model(
  'PatientoccupationalTherapyAssignmentS',
  PatientoccupationalTherapyAssignmentSchemaS,
  'patient_occupational_therapy_assignments_s' // Specify a distinct collection name here
);

module.exports = PatientoccupationalTherapyAssignmentS;
