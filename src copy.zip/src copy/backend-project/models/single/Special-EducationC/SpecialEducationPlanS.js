const mongoose = require('mongoose');

const SpecialEducationPlanSchemaS = new mongoose.Schema(
  {
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Patient', // Reference to the Patient model
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    filePath: {
      type: String, // Stores the file path of the uploaded document
    },
    fileName: {
      type: String, // Stores the original file name
    },
    lastModified: {
      type: Date,
      default: Date.now, // Automatically set when modified
    },
  },
  { timestamps: true } // Automatically manages createdAt and updatedAt fields
);

const SpecialEducationPlanS = mongoose.model(
  'SpecialEducationPlanS',
  SpecialEducationPlanSchemaS,
  'special_education_plans_s' // Specify a distinct collection name here
);

module.exports = SpecialEducationPlanS;
