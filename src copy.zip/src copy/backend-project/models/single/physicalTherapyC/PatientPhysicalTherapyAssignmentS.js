const mongoose = require("mongoose")

const patientPhysicalTherapyAssignmentSchemaS = new mongoose.Schema(
  {
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Patient",
      required: true,
    },
    assignedDate: {
      type: Date,
      default: Date.now,
    },
    status: {
      type: String,
      enum: ["active", "completed", "suspended", "cancelled"],
      default: "active",
    },
    notes: {
      type: String,
      required: false,
    },
    programId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "SingleProgram",
      required: false,
    },
    sessionNumber: {
      type: Number,
      default: 1,
    },
    completedAt: {
      type: Date,
      required: false,
    },
    cancelledAt: {
      type: Date,
      required: false,
    },
  },
  { timestamps: true },
)

// Index for better query performance
patientPhysicalTherapyAssignmentSchemaS.index({ patient: 1, sessionNumber: 1 })
patientPhysicalTherapyAssignmentSchemaS.index({ status: 1 })

const PatientPhysicalTherapyAssignmentS = mongoose.model(
  "PatientPhysicalTherapyAssignmentS",
  patientPhysicalTherapyAssignmentSchemaS,
  "patient_physical_therapy_assignments_s",
)

module.exports = PatientPhysicalTherapyAssignmentS
