const mongoose = require("mongoose")

const loginAttemptSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    lowercase: true,
    trim: true,
  },
  role: {
    type: String,
    enum: ["patient", "admin", "doctor", "accountant", "HeadDoctor"],
  },
  ipAddress: {
    type: String,
    required: true,
  },
  userAgent: {
    type: String,
  },
  success: {
    type: Boolean,
    required: true,
    default: false,
  },
  failureReason: {
    type: String,
  },
  blocked: {
    type: Boolean,
    default: false,
  },
  timestamp: {
    type: Date,
    default: Date.now,
    expires: 2592000, // Auto-delete after 30 days
  },
})

// Index for faster queries
loginAttemptSchema.index({ email: 1, timestamp: -1 })
loginAttemptSchema.index({ ipAddress: 1, timestamp: -1 })
loginAttemptSchema.index({ email: 1, role: 1, timestamp: -1 })

loginAttemptSchema.statics.shouldLockAccount = async function (email, role) {
  const fifteenMinutesAgo = new Date(Date.now() - 15 * 60 * 1000)

  const failedAttempts = await this.countDocuments({
    email: email,
    role: role,
    success: false,
    timestamp: { $gte: fifteenMinutesAgo },
  })

  return failedAttempts >= 5
}

loginAttemptSchema.statics.isSuspiciousIP = async function (ipAddress) {
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000)

  // Check for too many failed attempts from same IP across different accounts
  const failedAttempts = await this.countDocuments({
    ipAddress: ipAddress,
    success: false,
    timestamp: { $gte: oneHourAgo },
  })

  // If more than 10 failed attempts from same IP in 1 hour, flag as suspicious
  return failedAttempts >= 10
}

const LoginAttempt = mongoose.model("LoginAttempt", loginAttemptSchema)

module.exports = LoginAttempt
