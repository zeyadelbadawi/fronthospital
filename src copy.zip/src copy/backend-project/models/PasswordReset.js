const mongoose = require("mongoose")

const passwordResetSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    lowercase: true,
    trim: true,
  },
  token: {
    type: String,
    required: true,
    unique: true,
  },
  expiresAt: {
    type: Date,
    required: true,
    default: () => new Date(Date.now() + 3600000), // 1 hour from now
  },
  used: {
    type: Boolean,
    default: false,
  },
  createdAt: {
    type: Date,
    default: Date.now,
    expires: 3600, // Auto-delete after 1 hour
  },
})

// Index for faster queries
passwordResetSchema.index({ email: 1, createdAt: -1 })

const PasswordReset = mongoose.model("PasswordReset", passwordResetSchema)

module.exports = PasswordReset
