const mongoose = require("mongoose")

const ABAPlanSchema = new mongoose.Schema({
  patient: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Patient",
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  filePath: {
    type: String,
    required: false,
  },
  fullPath: {
    type: String,
    required: false,
  },
  fileName: {
    type: String,
    required: false,
  },
  content: {
    type: String,
    required: false,
  },
  quarterOfYear: {
    type: Number,
    required: true,
    min: 1,
    max: 4,
  },
  year: {
    type: Number,
    required: true,
  },
  createdBy: {
    type: String,
    default: "System",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  lastModified: {
    type: Date,
    default: Date.now,
  },
  isClosed: {
    type: Boolean,
    default: false,
  },
})

ABAPlanSchema.index({ patient: 1, quarterOfYear: 1, year: 1 }, { unique: true })

module.exports = mongoose.model("ABAPlan", ABAPlanSchema)
