const mongoose = require("mongoose")

const doctorSchema = new mongoose.Schema(
  {
    username: { type: String, required: false },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }, // The password will be hashed
    phone: { type: String, required: false },
    role: { type: String, default: "doctor" },
    departments: [{ type: mongoose.Schema.Types.ObjectId, ref: "Department" }], // Reference to multiple departments
    // Additional fields can be added here
  },
  { timestamps: true },
)

// Additional methods or hooks can be added here

const Doctor = mongoose.model("Doctor", doctorSchema)
module.exports = Doctor
