const mongoose = require('mongoose');

const HeadDoctorSchema = new mongoose.Schema({
  username: { type: String, required: false },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },  // The password will be hashed
  role: { type: String, default: 'HeadDoctor' },
}, 

{ timestamps: true });

const HeadDoctor = mongoose.model('HeadDoctor', HeadDoctorSchema);
module.exports = HeadDoctor;
