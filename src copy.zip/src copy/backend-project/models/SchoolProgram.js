const mongoose = require("mongoose")

const schoolProgramSchema = new mongoose.Schema(
  {
    patientid: { type: mongoose.Schema.Types.ObjectId, ref: "Patient", required: true },
    date: { type: Date, required: true },
    time: { type: String, required: true },
    description: { type: String, required: false },
    unicValue: { type: String, required: true },
    status: { type: String, default: "not completed" },
    paymentStatus: {
      type: String,
      enum: ["PENDING", "FULLY_PAID"],
      default: "PENDING",
    },
    paymentMethod: {
      type: String,
      enum: ["CASH", "ONLINE", "BANK_TRANSFER"],
      default: "CASH",
    },
    transferScreenshot: {
      type: String,
      default: null,
    },
    totalAmount: {
      type: Number,
      default: 0,
    },
    paidAmount: {
      type: Number,
      default: 0,
    },
    assignedDoctor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Doctor",
      default: null,
    },
  },
  { timestamps: true },
)

const SchoolProgram = mongoose.model("SchoolProgram", schoolProgramSchema)
module.exports = SchoolProgram
