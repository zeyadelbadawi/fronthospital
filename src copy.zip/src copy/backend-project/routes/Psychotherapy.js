const express = require("express")
const router = express.Router()
const formidable = require("formidable")
const fs = require("fs")
const path = require("path")
const { v4: uuidv4 } = require("uuid")
const PatientPsychotherapyAssignment = require("../models/psychotherapy/PatientPsychotherapyAssignment")
const Patient = require("../models/users/Patient")
const PsychotherapyPlan = require("../models/psychotherapy/PsychotherapyPlan")
// Helper function to get next quarter (same as doctor system)
const getNextQuarterAndYear = (currentQ, currentY) => {
  if (currentQ === 4) {
    return { quarter: 1, year: currentY + 1 }
  }
  return { quarter: currentQ + 1, year: currentY }
}

// Get all Psychotherapy patient assignments
router.get("/patient-assignments", async (req, res) => {
  try {
    const { page = 1, limit = 50, search = "" } = req.query
    const skip = (page - 1) * limit

    console.log("Fetching Psychotherapy patient assignments with params:", { page, limit, search })

    // Build search query
    let searchQuery = {}
    if (search) {
      // First find patients that match the search criteria
      const matchingPatients = await Patient.find({
        $or: [
          { name: { $regex: search, $options: "i" } },
          { email: { $regex: search, $options: "i" } },
          { patientId: { $regex: search, $options: "i" } },
        ],
      }).select("_id")

      const patientIds = matchingPatients.map((p) => p._id)
      searchQuery = { patient: { $in: patientIds } }
    }

    // Fetch assignments with populated patient data only (no doctorId since it doesn't exist in schema)
    const assignments = await PatientPsychotherapyAssignment.find(searchQuery)
      .populate("patient", "name email patientId phone dateOfBirth")
      .sort({ assignedDate: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await PatientPsychotherapyAssignment.countDocuments(searchQuery)

    console.log(`Found ${assignments.length} Psychotherapy patient assignments`)

    res.json({
      success: true,
      assignments,
      pagination: {
        currentPage: Number.parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalItems: total,
        itemsPerPage: Number.parseInt(limit),
      },
    })
  } catch (error) {
    console.error("Error fetching Psychotherapy patient assignments:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching Psychotherapy patient assignments",
      error: error.message,
    })
  }
})

// Get all OccupationalTherapy assignments
router.get("/Psycho-Therapy-assignments", async (req, res) => {
  try {
    const { page = 1, limit = 50, search = "" } = req.query
    const skip = (page - 1) * limit

    console.log("Fetching Psychotherapy assignments with params:", { page, limit, search })

    // Build search query
    let searchQuery = {}
    if (search) {
      const matchingPatients = await Patient.find({
        $or: [
          { name: { $regex: search, $options: "i" } },
          { email: { $regex: search, $options: "i" } },
          { patientId: { $regex: search, $options: "i" } },
        ],
      }).select("_id")

      const patientIds = matchingPatients.map((p) => p._id)
      searchQuery = { patient: { $in: patientIds } }
    }

    const assignments = await PatientPsychotherapyAssignment.find(searchQuery)
      .populate("patient", "name email patientId phone dateOfBirth")
      .sort({ assignedDate: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await PatientPsychotherapyAssignment.countDocuments(searchQuery)

    console.log(`Found ${assignments.length} Psychotherapy assignments`)

    res.json({
      success: true,
      assignments,
      pagination: {
        currentPage: Number.parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalItems: total,
        itemsPerPage: Number.parseInt(limit),
      },
    })
  } catch (error) {
    console.error("Error fetching Psychotherapy assignments:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching Psychotherapy assignments",
      error: error.message,
    })
  }
})

// Add Psychotherapy Assignment
router.post('/assign-to-Psychotherapy', async (req, res) => {
  const { patientId, notes } = req.body

  if (!patientId) {
    return res.status(400).json({ message: "Invalid or missing patient ID" })
  }

  try {
    const patient = await Patient.findById(patientId)
    if (!patient) {
      return res.status(404).json({ message: "Patient not found" })
    }

    // Ensure the patient is not already assigned to Psychotherapy
    const existingAssignment = await PatientPsychotherapyAssignment.findOne({
      patient: patientId,
    })
    if (existingAssignment) {
      return res.status(400).json({ message: "Patient already assigned to Psychotherapy" })
    }

    const assignment = new PatientPsychotherapyAssignment({
      patient: patientId,
      notes: notes || "",
      status: "active",
    })

    await assignment.save()

    res.status(201).json({ message: "Patient assigned to Psychotherapy successfully", assignment })
  } catch (err) {
    res.status(500).json({ message: "Error assigning patient to Psychotherapy", error: err.message })
  }
})

// Unassign from Psychotherapy
router.delete("/unassign-from-Psychotherapy/:patientId", async (req, res) => {
  const { patientId } = req.params

  try {
    const assignment = await PatientPsychotherapyAssignment.findOneAndDelete({ patient: patientId })

    if (!assignment) {
      return res.status(404).json({ message: "Assignment not found" })
    }

    res.status(200).json({ message: "Patient unassigned from Psychotherapy" })
  } catch (err) {
    res.status(500).json({ message: "Error unassigning patient" })
  }
})

// Get Psychotherapy Plan for a patient (latest or specific quarter/year)
router.get("/plan/:patientId", async (req, res) => {
  const { patientId } = req.params
  const { year, quarter } = req.query // Optional query parameters for historical plans

  try {
    let plan
    if (year && quarter) {
      plan = await PsychotherapyPlan.findOne({ patient: patientId, year: Number(year), quarterOfYear: Number(quarter) })
    } else {
      // Fetch the latest plan by default
      plan = await PsychotherapyPlan.findOne({ patient: patientId }).sort({ year: -1, quarterOfYear: -1, lastModified: -1 })
    }

    if (!plan) {
      return res.status(404).json({ message: "No plan found for this patient for the specified quarter/year." })
    }
    res.status(200).json(plan)
  } catch (err) {
    console.error("Error fetching Psychotherapy plan:", err)
    res.status(500).json({ message: "Error fetching Psychotherapy plan" })
  }
})

// Get all Psychotherapy Plans for a patient
router.get("/plans/:patientId", async (req, res) => {
  const { patientId } = req.params
  try {
    const plans = await PsychotherapyPlan.find({ patient: patientId }).sort({ year: -1, quarterOfYear: -1, lastModified: -1 })
    res.status(200).json(plans)
  } catch (err) {
    console.error("Error fetching all Psychotherapy plans:", err)
    res.status(500).json({ message: "Error fetching all Psychotherapy plans" })
  }
})

// Create Psychotherapy Plan (now creates a new historical entry)
router.post("/plan", async (req, res) => {
  const { patient, title, content, createdBy, quarterOfYear, year } = req.body

  try {
    // Check for duplicate plan for the same patient, quarter, and year
    const existingPlan = await PsychotherapyPlan.findOne({ patient, quarterOfYear, year })
    if (existingPlan) {
      return res
        .status(400)
        .json({ message: "A plan already exists for this patient for the specified quarter and year." })
    }

    const plan = new PsychotherapyPlan({
      patient,
      title,
      content,
      createdBy: createdBy || "System",
      lastModified: new Date(),
      quarterOfYear,
      year,
    })

    await plan.save()

    res.status(201).json(plan)
  } catch (err) {
    console.error("Error creating Psychotherapy plan:", err)
    res.status(500).json({ message: "Error creating Psychotherapy plan" })
  }
})

// Modified Update Psychotherapy Plan to handle multipart/form-data
router.put("/plan/:planId", (req, res) => {
  const form = new formidable.IncomingForm()
  form.keepExtensions = true
  form.maxFileSize = 50 * 1024 * 1024 // Set max file size to 50MB

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form for Psychotherapy plan update:", err)
      return res.status(500).json({ message: "Error parsing uploaded data for Psychotherapy plan." })
    }

    const planId = req.params.planId

    try {
      const existingPlan = await PsychotherapyPlan.findById(planId)
      if (!existingPlan) {
        return res.status(404).json({ message: "Psychotherapy Plan not found" })
      }

      // Extract fields from formidable
      const patientId = fields.patientId?.[0]
      const quarterOfYear = Number.parseInt(fields.quarterOfYear?.[0], 10)
      const year = Number.parseInt(fields.year?.[0], 10)
      const title = fields.title?.[0] || existingPlan.title

      // Basic validation
      if (!patientId || !quarterOfYear || !year) {
        return res.status(400).json({ message: "Patient ID, quarter, and year are required for update." })
      }
      if (![1, 2, 3, 4].includes(quarterOfYear)) {
        return res.status(400).json({ message: "quarterOfYear must be 1, 2, 3, or 4" })
      }

      let fileName = existingPlan.fileName
      let uniqueFileName = existingPlan.filePath // This is the unique name on disk
      let fullPath = existingPlan.fullPath

      // Check if a new document file is provided
      const file = files.document?.[0]
      if (file) {
        const tempFilePath = file.filepath
        const originalFileName = file.originalFilename
        const newUniqueFileName = `${uuidv4()}${path.extname(originalFileName)}`

        // Determine upload directory based on patient, quarter, and year
        const uploadDir = path.join(__dirname, "../uploads", `Q${quarterOfYear}`, `${year}`, "Psychotherapy", "patient-plans")

        if (!fs.existsSync(uploadDir)) {
          fs.mkdirSync(uploadDir, { recursive: true })
        }

        const finalFilePath = path.join(uploadDir, newUniqueFileName)
        fs.copyFileSync(tempFilePath, finalFilePath)
        fs.unlinkSync(tempFilePath) // Delete temp file

        // Delete old file from disk if it exists
        const oldFilePathOnDisk = path.join(
          __dirname,
          "../uploads",
          `Q${existingPlan.quarterOfYear}`,
          `${existingPlan.year}`,
          "Psychotherapy",
          "patient-plans",
          existingPlan.filePath,
        )
        if (fs.existsSync(oldFilePathOnDisk)) {
          fs.unlinkSync(oldFilePathOnDisk)
        }

        fileName = originalFileName
        uniqueFileName = newUniqueFileName
        fullPath = `/uploads/Q${quarterOfYear}/${year}/Psychotherapy/patient-plans/${newUniqueFileName}`
      }

      // Update PsychotherapyPlan document in DB
      const updatedPlan = await PsychotherapyPlan.findByIdAndUpdate(
        planId,
        {
          patient: patientId,
          title: title,
          fileName: fileName,
          filePath: uniqueFileName, // Store the unique name on disk
          fullPath: fullPath, // Store the full relative path for access
          quarterOfYear: quarterOfYear,
          year: year,
          lastModified: new Date(),
        },
        { new: true }, // Return the updated document
      )

      res.status(200).json({
        message: "Psychotherapy Plan updated successfully",
        plan: { ...updatedPlan._doc },
      })
    } catch (error) {
      console.error("Error updating Psychotherapy plan:", error)
      res.status(500).json({ message: "Error updating Psychotherapy plan", details: error.message })
    }
  })
})

router.post("/upload-plan", (req, res) => {
  const form = new formidable.IncomingForm()
  form.keepExtensions = true
  form.maxFileSize = 10 * 1024 * 1024 // 10MB

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err)
      return res.status(500).json({ message: "Error parsing uploaded file" })
    }

    const patientId = fields.patientId && fields.patientId[0] ? fields.patientId[0] : null
    const quarterOfYear = fields.quarterOfYear && fields.quarterOfYear[0] ? Number(fields.quarterOfYear[0]) : null
    const year = fields.year && fields.year[0] ? Number(fields.year[0]) : null

    if (!patientId || !quarterOfYear || !year) {
      return res.status(400).json({ message: "Patient ID, quarter, and year are required." })
    }

    if (quarterOfYear < 1 || quarterOfYear > 4) {
      return res.status(400).json({ message: "Quarter of year must be between 1 and 4" })
    }

    // Check for duplicate plan
    const existingPlan = await PsychotherapyPlan.findOne({ patient: patientId, quarterOfYear, year })
    if (existingPlan) {
      return res.status(400).json({
        message: "A plan already exists for this patient for the specified quarter and year.",
      })
    }

    try {
      const file = files.document[0]
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" })
      }

      const tempFilePath = file.filepath
      const originalFileName = file.originalFilename
      const uniqueFileName = `${uuidv4()}${path.extname(originalFileName)}`

      // Create organized directory structure like doctor system
      const uploadDir = path.join(__dirname, "../uploads", `Q${quarterOfYear}`, `${year}`, "Psychotherapy", "patient-plans")

      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true })
      }

      const finalFilePath = path.join(uploadDir, uniqueFileName)
      fs.copyFileSync(tempFilePath, finalFilePath)
      fs.unlinkSync(tempFilePath)

      const newPlan = await PsychotherapyPlan.create({
        patient: patientId,
        fileName: originalFileName,
        filePath: uniqueFileName,
        fullPath: `/uploads/Q${quarterOfYear}/${year}/Psychotherapy/patient-plans/${uniqueFileName}`,
        title: originalFileName.replace(/\.[^/.]+$/, ""),
        quarterOfYear,
        year,
      })

      res.status(200).json({
        message: "File uploaded and saved successfully",
        plan: { ...newPlan._doc },
      })
    } catch (error) {
      console.error("Error saving Psychotherapy plan:", error)
      res.status(500).json({ message: "Error saving file" })
    }
  })
})



router.post("/close-and-generate-next-plan", async (req, res) => {
  const { patientId, quarterToClose, yearToClose } = req.body

  if (!patientId || !quarterToClose || !yearToClose) {
    return res.status(400).json({ message: "Missing required fields for closing quarter" })
  }

  try {
    const { quarter: nextQuarter, year: nextYear } = getNextQuarterAndYear(quarterToClose, yearToClose)

    // Mark current quarter as closed
    await PsychotherapyPlan.updateOne(
      { patient: patientId, quarterOfYear: quarterToClose, year: yearToClose },
      { isClosed: true }
    )

    // Check if a plan already exists for the next quarter
    const existingNextPlan = await PsychotherapyPlan.findOne({
      patient: patientId,
      quarterOfYear: nextQuarter,
      year: nextYear,
    })

    if (existingNextPlan) {
      return res.status(409).json({
        message: `A plan already exists for Q${nextQuarter}/${nextYear}. No new plan generated.`,
        plan: existingNextPlan,
      })
    }

    // Get template
    const templateFileName = "Psychotherapy-Plantemplate-patient.docx"
    const templatePath = path.join(__dirname, "../uploads/templates", templateFileName)

    if (!fs.existsSync(templatePath)) {
      return res.status(404).json({
        message: "Default template for Psychotherapy department not found. Please upload one.",
      })
    }

    // Generate unique filename for the new plan
    const uniqueFileName = `${uuidv4()}.docx`
    const uploadDir = path.join(__dirname, "../uploads", `Q${nextQuarter}`, `${nextYear}`, "Psychotherapy", "patient-plans")

    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true })
    }

    const finalFilePath = path.join(uploadDir, uniqueFileName)
    fs.copyFileSync(templatePath, finalFilePath)

    // Create new PsychotherapyPlan entry
    const newPlan = await PsychotherapyPlan.create({
      patient: patientId,
      title: `Psychotherapy Plan Q${nextQuarter} ${nextYear}`,
      fileName: `Default Plan for Q${nextQuarter} ${nextYear}`,
      filePath: uniqueFileName,
      fullPath: `/uploads/Q${nextQuarter}/${nextYear}/Psychotherapy/patient-plans/${uniqueFileName}`,
      quarterOfYear: nextQuarter,
      year: nextYear,
      isClosed: false, // New plan is open by default
    })

    res.status(200).json({
      message: `Quarter ${quarterToClose}/${yearToClose} closed. New plan for Q${nextQuarter}/${nextYear} generated from template.`,
      plan: { ...newPlan._doc },
    })
  } catch (error) {
    console.error("Error closing quarter and generating next plan:", error)
    res.status(500).json({ message: "Error processing quarter closure and plan generation" })
  }
})



router.get("/view-plans/:patientId", async (req, res) => {
  const { patientId } = req.params
  const { last, quarter, year, startDate, endDate } = req.query

  try {
    if (!patientId) {
      return res.status(400).json({ message: "Missing required patient ID" })
    }

    // Get all closed quarters plus the latest open quarter
    const closedPlans = await PsychotherapyPlan.find({ patient: patientId, isClosed: true })
      .sort({ year: -1, quarterOfYear: -1 })

    const latestOpenPlan = await PsychotherapyPlan.findOne({ patient: patientId, isClosed: false })
      .sort({ year: -1, quarterOfYear: -1 })

    // Combine results
    let visiblePlans = closedPlans
    if (latestOpenPlan) {
      visiblePlans.unshift(latestOpenPlan)
    }

    // Apply optional filters
    if (quarter || year) {
      visiblePlans = visiblePlans.filter(plan => {
        if (quarter && plan.quarterOfYear !== Number.parseInt(quarter)) return false
        if (year && plan.year !== Number.parseInt(year)) return false
        return true
      })
    }

    if (startDate && endDate) {
      const start = new Date(startDate)
      const end = new Date(endDate)
      visiblePlans = visiblePlans.filter(plan =>
        (plan.createdAt >= start && plan.createdAt <= end) ||
        (plan.lastModified >= start && plan.lastModified <= end)
      )
    }

    res.status(200).json({
      message: "Psychotherapy plans retrieved successfully",
      plans: last === "true" ? visiblePlans[0] || null : visiblePlans,
    })
  } catch (error) {
    console.error("Error retrieving Psychotherapy plans:", error)
    res.status(500).json({ message: "Error retrieving Psychotherapy plans" })
  }
})


router.delete("/delete-plan/:id", async (req, res) => {
  try {
    const { id } = req.params
    const deletedPlan = await PsychotherapyPlan.findByIdAndDelete(id)

    if (!deletedPlan) {
      return res.status(404).json({ message: "Psychotherapy Plan not found." })
    }

    // Delete the associated file from the file system
    if (deletedPlan.fullPath) {
      const filePathOnDisk = path.join(__dirname, "..", deletedPlan.fullPath)
      if (fs.existsSync(filePathOnDisk)) {
        fs.unlinkSync(filePathOnDisk)
        console.log(`Deleted associated plan file: ${filePathOnDisk}`)
      } else {
        console.warn(`File not found for deletion (plan ID: ${id}): ${filePathOnDisk}`)
      }
    }

    res.status(200).json({ message: "Psychotherapy Plan and associated file deleted successfully!" })
  } catch (error) {
    console.error("Error deleting Psychotherapy plan and file:", error)
    res.status(500).json({ message: "Server error during plan deletion." })
  }
})

// Get Psychotherapy Plans for a patient
router.get("/get-plans/:patientId", async (req, res) => {
  const { patientId } = req.params
  const { last, quarter, year } = req.query

  try {
    if (!patientId) {
      return res.status(400).json({ message: "Missing required patient ID" })
    }

    const query = { patient: patientId }

    // Add quarter and year filters if provided
    if (quarter) query.quarterOfYear = Number.parseInt(quarter)
    if (year) query.year = Number.parseInt(year)

    let plans
    if (last === "true") {
      // Return only the latest plan
      plans = await PsychotherapyPlan.findOne(query).sort({ createdAt: -1 })
    } else {
      // Return all plans matching the query
      plans = await PsychotherapyPlan.find(query).sort({ year: -1, quarterOfYear: -1, createdAt: -1 })
    }

    res.status(200).json({
      message: "Psychotherapy plans retrieved successfully",
      plans,
    })
  } catch (error) {
    res.status(500).json({ message: "Error retrieving Psychotherapy plans" })
  }
})

module.exports = router
