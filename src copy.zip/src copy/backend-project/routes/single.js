const express = require("express")
const router = express.Router()
const SingleProgram = require("../models/SingleProgram")
const Patient = require("../models/users/Patient")

// Get all single programs for a specific patient
router.get("/single-programs/patient/:patientId", async (req, res) => {
  const { patientId } = req.params

  try {
    const singlePrograms = await SingleProgram.find({ patientid: patientId }).sort({ date: -1, time: -1 })

    if (!singlePrograms || singlePrograms.length === 0) {
      return res.status(404).json({ message: "No single programs found for this patient" })
    }

    res.status(200).json(singlePrograms)
  } catch (err) {
    console.error("Error fetching single programs:", err)
    res.status(500).json({ message: "Error fetching single programs" })
  }
})

// Get a specific single program by ID
router.get("/single-programs/:programId", async (req, res) => {
  const { programId } = req.params

  try {
    const singleProgram = await SingleProgram.findById(programId).populate({
      path: "patientid",
      select: "name email phone",
      model: "Patient",
    })

    if (!singleProgram) {
      return res.status(404).json({ message: "Single program not found" })
    }

    res.status(200).json(singleProgram)
  } catch (err) {
    console.error("Error fetching single program:", err)
    res.status(500).json({ message: "Error fetching single program" })
  }
})

// Get all single programs (for admin view)
router.get("/single-programs", async (req, res) => {
  try {
    const singlePrograms = await SingleProgram.find()
      .populate({
        path: "patientid",
        select: "name email phone",
        model: "Patient",
      })
      .sort({ date: -1, time: -1 })

    res.status(200).json(singlePrograms)
  } catch (err) {
    console.error("Error fetching all single programs:", err)
    res.status(500).json({ message: "Error fetching single programs" })
  }
})

// Create a new single program
router.post("/single-programs", async (req, res) => {
  const { patientid, date, time, description, programkind } = req.body

  try {
    const singleProgram = new SingleProgram({
      patientid,
      date,
      time,
      description,
      programkind,
    })

    const savedProgram = await singleProgram.save()

    // Populate the patient data for response
    const populatedProgram = await SingleProgram.findById(savedProgram._id).populate({
      path: "patientid",
      select: "name email phone",
      model: "Patient",
    })

    res.status(201).json(populatedProgram)
  } catch (err) {
    console.error("Error creating single program:", err)
    res.status(500).json({ message: "Error creating single program" })
  }
})

// Update a single program
router.put("/single-programs/:programId", async (req, res) => {
  const { programId } = req.params
  const { patientid, date, time, description, programkind } = req.body

  try {
    const updatedProgram = await SingleProgram.findByIdAndUpdate(
      programId,
      { patientid, date, time, description, programkind },
      { new: true },
    ).populate({
      path: "patientid",
      select: "name email phone",
      model: "Patient",
    })

    if (!updatedProgram) {
      return res.status(404).json({ message: "Single program not found" })
    }

    res.status(200).json(updatedProgram)
  } catch (err) {
    console.error("Error updating single program:", err)
    res.status(500).json({ message: "Error updating single program" })
  }
})

// Delete a single program
router.delete("/single-programs/:programId", async (req, res) => {
  const { programId } = req.params

  try {
    const deletedProgram = await SingleProgram.findByIdAndDelete(programId)

    if (!deletedProgram) {
      return res.status(404).json({ message: "Single program not found" })
    }

    res.status(200).json({ message: "Single program deleted successfully" })
  } catch (err) {
    console.error("Error deleting single program:", err)
    res.status(500).json({ message: "Error deleting single program" })
  }
})

module.exports = router
