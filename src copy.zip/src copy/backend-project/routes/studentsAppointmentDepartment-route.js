const express = require("express")
const StudentsAppointmentDepartment = require("../models/StudentsAppointmentDepartment")
const Patient = require("../models/users/Patient")
const Appointment = require("../models/appointment") // ADD THIS LINE
const DoctorStudentAssignment = require("../models/DoctorStudentAssignment") // ADD THIS LINE
/* Category */
const PatientPhysicalTherapyAssignment = require("../models/physicalTherapy/PatientPhysicalTherapyAssignment")
const PatientABAAssignment = require("../models/ABA/PatientABAAssignment")
const PatientoccupationalTherapyAssignment = require("../models/Occupational-therapy/PatientOccupationalTherapyAssignment")
const PatientSpecialEducationAssignment = require("../models/Special-Education/PatientSpecialEducationAssignment")
const PatientSpeechAssignment = require("../models/Speech/PatientSpeechAssignment")
const Doctor = require("../models/users/Doctor") // Correctly import Doctor model here

const Department = require("../models/department")

const studentsAppointmentDepartmentRouter = express.Router()

/* UPDATED ENDPOINT: Check if patient is already assigned to other appointments in the same department */
studentsAppointmentDepartmentRouter.get(
  "/check-existing-assignment/:patientId/:department/:currentAppointmentId",
  async (req, res) => {
    try {
      const { patientId, department, currentAppointmentId } = req.params

      console.log(
        `Checking existing assignments for patient: ${patientId}, department: ${department}, current appointment: ${currentAppointmentId}`,
      )

      // Find ALL appointments where the patient is already assigned in the same department
      const existingAssignments = await StudentsAppointmentDepartment.find({
        patientId: patientId,
        department: department,
        appointmentId: { $ne: currentAppointmentId }, // Exclude current appointment
      }).populate({
        path: "appointmentId",
        populate: {
          path: "doctor",
          select: "username email",
        },
      })

      if (existingAssignments.length > 0) {
        console.log(`Found ${existingAssignments.length} existing assignments:`, existingAssignments)

        // Extract appointment details for easier frontend handling
        const existingAppointments = existingAssignments.map((assignment) => ({
          assignmentId: assignment._id,
          appointment: assignment.appointmentId,
          department: assignment.department,
        }))

        return res.status(200).json({
          hasExistingAssignment: true,
          existingAppointments: existingAppointments,
          totalConflicts: existingAssignments.length,
        })
      }

      return res.status(200).json({
        hasExistingAssignment: false,
        existingAppointments: [],
        totalConflicts: 0,
      })
    } catch (error) {
      console.error("Error checking existing assignments:", error)
      res.status(500).json({
        message: "Error checking existing assignments",
        error: error.message,
      })
    }
  },
)

/* UPDATED add function - with multiple conflicts checking */
studentsAppointmentDepartmentRouter.post("/", async (req, res) => {
  try {
    const { patientId, appointmentId, department, forceAssign = false } = req.body

    // Validate required fields
    if (!patientId || !appointmentId || !department) {
      return res.status(400).json({ error: "Missing required fields" })
    }

    // Check if already assigned to this exact appointment
    const exactMatch = await StudentsAppointmentDepartment.findOne({
      department,
      appointmentId,
      patientId,
    })

    if (exactMatch) {
      return res.status(400).json({
        error: "Patient is already assigned to this appointment",
      })
    }

    // If not forcing assignment, check for conflicts in the same department
    if (!forceAssign) {
      const conflictingAssignments = await StudentsAppointmentDepartment.find({
        patientId: patientId,
        department: department,
        appointmentId: { $ne: appointmentId },
      }).populate({
        path: "appointmentId",
        populate: {
          path: "doctor",
          select: "username email",
        },
      })

      if (conflictingAssignments.length > 0) {
        // Extract appointment details for easier frontend handling
        const existingAppointments = conflictingAssignments.map((assignment) => ({
          assignmentId: assignment._id,
          appointment: assignment.appointmentId,
          department: assignment.department,
        }))

        return res.status(409).json({
          error: `Patient already assigned to ${conflictingAssignments.length} other appointment(s) in this department`,
          conflictDetails: {
            hasExistingAssignment: true,
            existingAppointments: existingAppointments,
            totalConflicts: conflictingAssignments.length,
          },
        })
      }
    }

    // Create the assignment
    const studentsAppointment = new StudentsAppointmentDepartment({
      appointmentId,
      patientId,
      department,
    })

    await studentsAppointment.save()
    return res.status(201).json({
      message: "Students appointment created successfully",
      studentsAppointment: studentsAppointment,
    })
  } catch (error) {
    console.error("Error creating student appointment:", error)
    return res.status(500).json({ error: "Failed to create Students appointment" })
  }
})

/* All function */
studentsAppointmentDepartmentRouter.get("/:department/:slotId", async (req, res) => {
  try {
    const { department, slotId } = req.params
    // Validate required fields
    if (!department || !slotId) {
      return res.status(400).json({ error: "Missing required fields" })
    }
    const studentsAppointment = await StudentsAppointmentDepartment.find({
      department,
      appointmentId: slotId,
    }).populate(["patientId", "appointmentId"])
    return res.status(200).json({ studentsAppointment: studentsAppointment })
  } catch (error) {
    return res.status(500).json({ error: "Failed to fetch students appointment" })
  }
})

/* Delete function */
studentsAppointmentDepartmentRouter.delete("/:id", async (req, res) => {
  try {
    const deletedStudentsAppointmentDepartment = await StudentsAppointmentDepartment.findByIdAndDelete(req.params.id)
    if (!deletedStudentsAppointmentDepartment) {
      return res.status(404).json({ error: "Student appointment not found" })
    }
    return res.status(200).json({ message: "Student appointment deleted successfully" })
  } catch (error) {
    return res.status(500).json({ error: "Failed to delete student appointment" })
  }
})

/* py */
studentsAppointmentDepartmentRouter.get(
  "/physical-therapy-assignments/:department/:appointmentId",
  async (req, res) => {
    const { department, appointmentId } = req.params

    try {
      if (!department || !appointmentId) {
        return res.status(400).json({ error: "Missing required fields" })
      }
      // Find all students registered in the given appointment and department
      const registeredStudents = await StudentsAppointmentDepartment.find({
        department: department,
        appointmentId: appointmentId,
      }).select("patientId")

      // Extract just the patientIds from the results
      const registeredStudentIds = registeredStudents.map((student) => student.patientId)

      // Find all students NOT in the registeredStudentIds array
      const unregisteredStudents = await PatientPhysicalTherapyAssignment.find({
        patient: { $nin: registeredStudentIds },
      }).populate("patient")

      return res.status(200).json({
        assignments: unregisteredStudents,
      })
    } catch (err) {
      res.status(500).json({ message: "Error fetching physical therapy assignments" })
    }
  },
)
/* ABA-assignments */
studentsAppointmentDepartmentRouter.get("/ABA-assignments/:department/:appointmentId", async (req, res) => {
  const { department, appointmentId } = req.params

  try {
    if (!department || !appointmentId) {
      return res.status(400).json({ error: "Missing required fields" })
    }
    // Find all students registered in the given appointment and department
    const registeredStudents = await StudentsAppointmentDepartment.find({
      department: department,
      appointmentId: appointmentId,
    }).select("patientId")

    // Extract just the patientIds from the results
    const registeredStudentIds = registeredStudents.map((student) => student.patientId)

    // Find all students NOT in the registeredStudentIds array
    const unregisteredStudents = await PatientABAAssignment.find({
      patient: { $nin: registeredStudentIds },
    }).populate("patient")

    return res.status(200).json({
      assignments: unregisteredStudents,
    })
  } catch (err) {
    res.status(500).json({ message: "Error fetching ABA assignments" })
  }
})
/* Occupational-therapy-assignments */
studentsAppointmentDepartmentRouter.get(
  "/Occupational-therapy-assignments/:department/:appointmentId",
  async (req, res) => {
    const { department, appointmentId } = req.params

    try {
      if (!department || !appointmentId) {
        return res.status(400).json({ error: "Missing required fields" })
      }
      // Find all students registered in the given appointment and department
      const registeredStudents = await StudentsAppointmentDepartment.find({
        department: department,
        appointmentId: appointmentId,
      }).select("patientId")

      // Extract just the patientIds from the results
      const registeredStudentIds = registeredStudents.map((student) => student.patientId)

      // Find all students NOT in the registeredStudentIds array
      const unregisteredStudents = await PatientoccupationalTherapyAssignment.find({
        patient: { $nin: registeredStudentIds },
      }).populate("patient")

      return res.status(200).json({
        assignments: unregisteredStudents,
      })
    } catch (err) {
      res.status(500).json({ message: "Error fetching Occupational therapy assignments" })
    }
  },
)
/* Special-Education-assignments */
studentsAppointmentDepartmentRouter.get(
  "/Special-Education-assignments/:department/:appointmentId",
  async (req, res) => {
    const { department, appointmentId } = req.params

    try {
      if (!department || !appointmentId) {
        return res.status(400).json({ error: "Missing required fields" })
      }
      // Find all students registered in the given appointment and department
      const registeredStudents = await StudentsAppointmentDepartment.find({
        department: department,
        appointmentId: appointmentId,
      }).select("patientId")

      // Extract just the patientIds from the results
      const registeredStudentIds = registeredStudents.map((student) => student.patientId)

      // Find all students NOT in the registeredStudentIds array
      const unregisteredStudents = await PatientSpecialEducationAssignment.find({
        patient: { $nin: registeredStudentIds },
      }).populate("patient")

      return res.status(200).json({
        assignments: unregisteredStudents,
      })
    } catch (err) {
      res.status(500).json({ message: "Error fetching Special Education assignments" })
    }
  },
)
/* Speech-assignments */
studentsAppointmentDepartmentRouter.get("/Speech-assignments/:department/:appointmentId", async (req, res) => {
  const { department, appointmentId } = req.params

  try {
    if (!department || !appointmentId) {
      return res.status(400).json({ error: "Missing required fields" })
    }
    // Find all students registered in the given appointment and department
    const registeredStudents = await StudentsAppointmentDepartment.find({
      department: department,
      appointmentId: appointmentId,
    }).select("patientId")

    // Extract just the patientIds from the results
    const registeredStudentIds = registeredStudents.map((student) => student.patientId)

    // Find all students NOT in the registeredStudentIds array
    const unregisteredStudents = await PatientSpeechAssignment.find({
      patient: { $nin: registeredStudentIds },
    }).populate("patient")

    return res.status(200).json({
      assignments: unregisteredStudents,
    })
  } catch (err) {
    res.status(500).json({ message: "Error fetching Speech assignments" })
  }
})

/* Doctor-specific patients endpoint - NEW */
studentsAppointmentDepartmentRouter.get("/doctor-patients/:doctorId/:department/:appointmentId", async (req, res) => {
  const { doctorId, department, appointmentId } = req.params

  try {
    if (!doctorId || !department || !appointmentId) {
      return res.status(400).json({ error: "Missing required fields" })
    }

    console.log(
      `Fetching doctor patients for doctor: ${doctorId}, department: ${department}, appointment: ${appointmentId}`,
    )

    // Step 1: Find all students already registered for this appointment
    const registeredStudents = await StudentsAppointmentDepartment.find({
      department: department,
      appointmentId: appointmentId,
    }).select("patientId")

    // Extract just the patientIds from the results
    const registeredStudentIds = registeredStudents.map((student) => student.patientId.toString())

    console.log(`Found ${registeredStudentIds.length} already registered students`)

    // Step 2: Find all students assigned to this doctor in this department
    const doctorStudents = await DoctorStudentAssignment.find({
      doctor: doctorId,
      department: { $regex: new RegExp(department, "i") },
      status: { $ne: "inactive" },
    }).populate("patient")

    console.log(`Found ${doctorStudents.length} students assigned to doctor in ${department}`)

    // Step 3: Filter out students who are already registered for this appointment
    const availableStudents = doctorStudents.filter(
      (assignment) => !registeredStudentIds.includes(assignment.patient._id.toString()),
    )

    console.log(`Found ${availableStudents.length} available students for appointment`)

    return res.status(200).json({
      assignments: availableStudents,
      totalDoctorStudents: doctorStudents.length,
      registeredStudents: registeredStudentIds.length,
      availableStudents: availableStudents.length,
    })
  } catch (err) {
    console.error("Error fetching doctor patients:", err)
    res.status(500).json({
      message: "Error fetching doctor patients",
      error: err.message,
    })
  }
})

// Endpoint to add a student to an appointment
studentsAppointmentDepartmentRouter.post("/add", async (req, res) => {
  try {
    const { patientId, appointmentId, forceAssign } = req.body

    // Check for existing assignments for the patient in the same department
    const appointment = await Appointment.findById(appointmentId).populate("doctor")
    if (!appointment) {
      return res.status(404).json({ error: "Appointment not found" })
    }

    const existingAssignments = await StudentsAppointmentDepartment.find({
      patientId: patientId,
      department: appointment.department,
    }).populate("appointmentId")

    if (existingAssignments.length > 0 && !forceAssign) {
      return res.status(409).json({
        error: "Patient already assigned to another appointment in this department.",
        conflicts: existingAssignments.map((assignment) => ({
          appointmentId: assignment.appointmentId._id,
          day: assignment.appointmentId.day,
          start_time: assignment.appointmentId.start_time,
          end_time: assignment.appointmentId.end_time,
          department: assignment.department,
        })),
      })
    }

    const newAssignment = new StudentsAppointmentDepartment({
      patientId,
      appointmentId,
      department: appointment.department,
    })

    await newAssignment.save()

    const Notification = require("../models/notifications")
    const Patient = require("../models/users/Patient")

    const patient = await Patient.findById(patientId)
    const studentName = patient?.name || patient?.firstName || "Unknown Student"

    const notification = new Notification({
      receiverId: appointment.doctor._id.toString(),
      rule: "Doctor",
      title: "Student Added to Appointment",
      titleAr: "تم إضافة طالب إلى الموعد",
      message: `Student "${studentName}" has been added to your ${appointment.department} appointment on ${appointment.day}`,
      messageAr: `تم إضافة الطالب "${studentName}" إلى موعدك في ${appointment.department} يوم ${appointment.day}`,
      type: "create",
    })

    await notification.save()

    // Emit notification via socket if doctor is online
    const io = req.app.get("io")
    const onlineUsers = req.app.get("onlineUsers")
    const doctorId = appointment.doctor._id.toString()
    const socketId = onlineUsers.get(doctorId)
    if (socketId) {
      const unreadNotifications = await Notification.find({
        receiverId: doctorId,
        isRead: false,
      })
      io.to(socketId).emit("newNotification", {
        count: unreadNotifications.length,
        notifications: [notification],
      })
    }

    return res.status(201).json({ message: "Student assigned successfully", assignment: newAssignment })
  } catch (error) {
    console.error("Error assigning student:", error)
    return res.status(500).json({ error: "Failed to assign student" })
  }
})

// Endpoint to remove a student from an appointment
studentsAppointmentDepartmentRouter.delete("/remove/:assignmentId", async (req, res) => {
  try {
    const { assignmentId } = req.params
    const deletedAssignment = await StudentsAppointmentDepartment.findByIdAndDelete(assignmentId)

    if (!deletedAssignment) {
      return res.status(404).json({ error: "Assignment not found" })
    }

    return res.status(200).json({ message: "Student unassigned successfully" })
  } catch (error) {
    console.error("Error unassigning student:", error)
    return res.status(500).json({ error: "Failed to unassign student" })
  }
})

// Endpoint to get all assigned students for a specific appointment
studentsAppointmentDepartmentRouter.get("/assigned-to-appointment/:appointmentId", async (req, res) => {
  try {
    const { appointmentId } = req.params
    const assignedStudents = await StudentsAppointmentDepartment.find({ appointmentId }).populate("patientId")
    return res.status(200).json({ assignedStudents })
  } catch (error) {
    console.error("Error fetching assigned students for appointment:", error)
    return res.status(500).json({ error: "Failed to fetch assigned students" })
  }
})

// NEW: Check for doctor change conflicts
studentsAppointmentDepartmentRouter.get(
  "/check-doctor-change-conflicts/:appointmentId/:oldDoctorId/:newDoctorId",
  async (req, res) => {
    try {
      const { appointmentId, oldDoctorId, newDoctorId } = req.params

      const appointment = await Appointment.findById(appointmentId).populate("doctor")
      if (!appointment) {
        return res.status(404).json({ error: "Appointment not found" })
      }

      // Find all students assigned to this specific appointment
      const assignedStudents = await StudentsAppointmentDepartment.find({
        appointmentId: appointmentId,
      }).populate("patientId", "name email")

      const conflictingStudents = []

      // Check if any of these assigned students have the old doctor as their primary doctor
      for (const assignment of assignedStudents) {
        // CORRECTED: Query DoctorStudentAssignment to check the patient-doctor link
        const doctorStudentAssignment = await DoctorStudentAssignment.findOne({
          patient: assignment.patientId._id,
          doctor: oldDoctorId,
          department: { $regex: new RegExp(appointment.department, "i") }, // Match department
          status: { $ne: "inactive" }, // Consider only active assignments
        })

        if (doctorStudentAssignment) {
          conflictingStudents.push({
            patientId: assignment.patientId._id,
            patientName: assignment.patientId.name,
            patientEmail: assignment.patientId.email,
          })
        }
      }

      const oldDoctor = await Doctor.findById(oldDoctorId)

      return res.status(200).json({
        hasConflicts: conflictingStudents.length > 0,
        totalConflicts: conflictingStudents.length,
        conflictingStudents: conflictingStudents,
        oldDoctorName: oldDoctor ? oldDoctor.username : "Unknown Doctor",
        appointmentDepartment: appointment.department,
        newDoctorId: newDoctorId, // Pass new doctor ID back for frontend to use
      })
    } catch (error) {
      console.error("Error checking doctor change conflicts:", error)
      return res.status(500).json({ error: "Failed to check doctor change conflicts" })
    }
  },
)

// NEW: Handle doctor change actions (keep or remove students)
studentsAppointmentDepartmentRouter.post("/handle-doctor-change", async (req, res) => {
  try {
    const { appointmentId, conflictingStudentIds, action } = req.body

    if (action === "remove") {
      // Remove conflicting students from this specific appointment
      await StudentsAppointmentDepartment.deleteMany({
        appointmentId: appointmentId,
        patientId: { $in: conflictingStudentIds },
      })
      return res.status(200).json({ message: "Conflicting students removed from appointment." })
    } else if (action === "keep") {
      // No action needed on the backend for "keep" as students remain assigned
      return res.status(200).json({ message: "Conflicting students kept in appointment." })
    } else {
      return res.status(400).json({ error: "Invalid action specified." })
    }
  } catch (error) {
    console.error("Error handling doctor change:", error)
    return res.status(500).json({ error: "Failed to handle doctor change" })
  }
})

studentsAppointmentDepartmentRouter.get("/doctors-by-department/:departmentName", async (req, res) => {
  try {
    const { departmentName } = req.params
    console.log("Fetching doctors for department:", departmentName)

    // First, try to find the department by name (case-insensitive)
    let department = await Department.findOne({
      name: { $regex: new RegExp(`^${departmentName}$`, "i") },
    })

    // If not found, try alternative names
    if (!department) {
      const alternativeNames = {
        ABA: ["Applied Behavior Analysis", "ABA", "Behavioral Analysis"],
        Speech: ["speech", "Speech Therapy", "Speech", "Speech-Language Pathology"],
        PhysicalTherapy: ["PhysicalTherapy", "physicalTherapy", "PT", "Physiotherapy"], // Added for consistency
        OccupationalTherapy: ["OccupationalTherapy", "Occupational Therapy", "OT"],
        "Special Education": ["SpecialEducation", "Special Education", "Special Ed", "SPED"],
      }
      const searchNames = alternativeNames[departmentName] || [departmentName]
      for (const name of searchNames) {
        department = await Department.findOne({
          name: { $regex: new RegExp(`^${name}$`, "i") },
        })
        if (department) break
      }
    }

    // If still not found, create the department
    if (!department) {
      console.log("Department not found, creating:", departmentName)
      department = new Department({
        name: departmentName,
        description: `${departmentName} Department`,
        isActive: true,
      })
      await department.save()
      console.log("Created department:", department)
    }

    console.log("Using department:", department)

    // ✅ FIXED: Only use ObjectId matching for departments field
    const doctors = await Doctor.find({
      $and: [
        {
          // Only query by department ObjectId since departments field contains ObjectIds
          departments: department._id,
        },
        {
          $or: [{ role: "doctor" }, { role: { $exists: false } }],
        },
      ],
    }).populate("departments", "name")

    console.log("Found doctors:", doctors.length)

    // ✅ ENHANCED: Better debugging to see all available fields
    console.log("Raw doctor data:")
    doctors.forEach((doctor, index) => {
      console.log(`Doctor ${index + 1}:`, {
        _id: doctor._id,
        name: doctor.name,
        username: doctor.username,
        firstName: doctor.firstName,
        lastName: doctor.lastName,
        fullName: doctor.fullName,
        email: doctor.email,
        role: doctor.role,
        departments: doctor.departments?.map((d) => d.name),
        // Show all fields to debug
        allFields: Object.keys(doctor.toObject()),
      })
    })

    // ✅ ENHANCED: Create a display name for each doctor
    const doctorsWithDisplayName = doctors.map((doctor) => {
      // Try different name combinations
      const displayName =
        doctor.name ||
        doctor.username ||
        doctor.fullName ||
        (doctor.firstName && doctor.lastName ? `${doctor.firstName} ${doctor.lastName}` : null) ||
        doctor.firstName ||
        doctor.lastName ||
        doctor.email?.split("@")[0] ||
        "Unknown Doctor"

      return {
        _id: doctor._id,
        name: doctor.name,
        username: doctor.username,
        firstName: doctor.firstName,
        lastName: doctor.lastName,
        displayName: displayName,
        email: doctor.email,
        role: doctor.role,
        departments: doctor.departments,
        // Include original doctor object for compatibility
        ...doctor.toObject(),
      }
    })

    console.log(
      "Doctor details with display names:",
      doctorsWithDisplayName.map((d) => ({
        displayName: d.displayName,
        name: d.name,
        username: d.username,
        firstName: d.firstName,
        lastName: d.lastName,
        email: d.email,
        departments: d.departments?.map((dept) => dept.name),
        role: d.role,
      })),
    )

    // If no doctors found, let's check what doctors exist
    if (doctors.length === 0) {
      const allDoctors = await Doctor.find({}).populate("departments", "name")
      console.log("All doctors in database:")
      allDoctors.forEach((doctor, index) => {
        console.log(`All Doctor ${index + 1}:`, {
          _id: doctor._id,
          name: doctor.name,
          username: doctor.username,
          firstName: doctor.firstName,
          lastName: doctor.lastName,
          email: doctor.email,
          role: doctor.role,
          departments: doctor.departments?.map((d) => d.name),
          allFields: Object.keys(doctor.toObject()),
        })
      })
    }

    res.status(200).json({
      success: true,
      doctors: doctorsWithDisplayName, // Return enhanced doctors with display names
      department: department.name,
      departmentId: department._id,
    })
  } catch (error) {
    console.error("Error fetching doctors by department:", error)
    res.status(500).json({
      message: "Error fetching doctors by department",
      error: error.message,
      stack: process.env.NODE_ENV === "development" ? error.stack : undefined,
    })
  }
})

module.exports = studentsAppointmentDepartmentRouter
