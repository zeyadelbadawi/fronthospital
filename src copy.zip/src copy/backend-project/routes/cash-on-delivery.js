const express = require("express")
const router = express.Router()

// Import models (you'll need to adjust these imports based on your actual model structure)
const FullProgram = require("../models/FullProgram")
const SingleProgram = require("../models/SingleProgram")
const SchoolProgram = require("../models/SchoolProgram")
const Money = require("../models/Money")
const Patient = require("../models/Patient") // Assuming you have a Patient model

// Get all cash on delivery records
router.get("/cash-on-delivery-records", async (req, res) => {
  try {
    console.log("Fetching cash on delivery records...")

    const cashOnDeliveryRecords = []

    // Search in all program types for cash on delivery records
    const fullPrograms = await FullProgram.find({
      paymentStatus: { $in: ["CASH_ON_DELIVERY", "FULLY_PAID"] },
      paymentMethod: "CASH_ON_DELIVERY",
    }).populate("patientid", "name email")

    const singlePrograms = await SingleProgram.find({
      paymentStatus: { $in: ["CASH_ON_DELIVERY", "FULLY_PAID"] },
      paymentMethod: "CASH_ON_DELIVERY",
    }).populate("patientid", "name email")

    const schoolPrograms = await SchoolProgram.find({
      paymentStatus: { $in: ["CASH_ON_DELIVERY", "FULLY_PAID"] },
      paymentMethod: "CASH_ON_DELIVERY",
    }).populate("patientid", "name email")

    // Format full programs
    fullPrograms.forEach((program) => {
      cashOnDeliveryRecords.push({
        _id: program._id,
        programType: "full_program",
        patientId: program.patientid?._id,
        patientName: program.patientid?.name || "Unknown Patient",
        patientEmail: program.patientid?.email,
        date: program.date,
        time: program.time,
        description: program.description,
        totalAmount: program.totalAmount || 5000,
        paidAmount: program.paidAmount || 0,
        remainingAmount: program.remainingAmount || program.totalAmount,
        paymentStatus: program.paymentStatus,
        paymentMethod: program.paymentMethod,
        createdAt: program.createdAt || program.date,
      })
    })

    // Format single programs
    singlePrograms.forEach((program) => {
      cashOnDeliveryRecords.push({
        _id: program._id,
        programType: "single_session",
        patientId: program.patientid?._id,
        patientName: program.patientid?.name || "Unknown Patient",
        patientEmail: program.patientid?.email,
        date: program.date,
        time: program.time,
        description: program.description,
        totalAmount: program.totalAmount || 100,
        paidAmount: program.paidAmount || 0,
        remainingAmount: program.remainingAmount || program.totalAmount,
        paymentStatus: program.paymentStatus,
        paymentMethod: program.paymentMethod,
        programKind: program.programkind,
        createdAt: program.createdAt || program.date,
      })
    })

    // Format school programs
    schoolPrograms.forEach((program) => {
      cashOnDeliveryRecords.push({
        _id: program._id,
        programType: "school_evaluation",
        patientId: program.patientid?._id,
        patientName: program.patientid?.name || "Unknown Patient",
        patientEmail: program.patientid?.email,
        date: program.date,
        time: program.time,
        description: program.description,
        totalAmount: program.totalAmount || 400,
        paidAmount: program.paidAmount || 0,
        remainingAmount: program.remainingAmount || program.totalAmount,
        paymentStatus: program.paymentStatus,
        paymentMethod: program.paymentMethod,
        unicValue: program.unicValue,
        createdAt: program.createdAt || program.date,
      })
    })

    // Sort by creation date (newest first)
    cashOnDeliveryRecords.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))

    console.log(`Found ${cashOnDeliveryRecords.length} cash on delivery records`)

    res.status(200).json({
      message: "Cash on delivery records fetched successfully",
      records: cashOnDeliveryRecords,
      total: cashOnDeliveryRecords.length,
    })
  } catch (error) {
    console.error("Error fetching cash on delivery records:", error)
    res.status(500).json({
      message: "Error fetching cash on delivery records",
      error: error.message,
    })
  }
})

// Complete cash on delivery payment
router.post("/complete-cash-on-delivery-payment", async (req, res) => {
  try {
    console.log("Completing cash on delivery payment:", req.body)

    const { programId, programType, totalAmount } = req.body

    if (!programId || !programType || !totalAmount) {
      return res.status(400).json({
        message: "Missing required fields: programId, programType, totalAmount",
      })
    }

    let Model
    switch (programType) {
      case "full_program":
        Model = FullProgram
        break
      case "single_session":
        Model = SingleProgram
        break
      case "school_evaluation":
        Model = SchoolProgram
        break
      default:
        return res.status(400).json({
          message: "Invalid program type",
        })
    }

    // Find the program
    const program = await Model.findById(programId).populate("patientid", "name email")

    if (!program) {
      return res.status(404).json({
        message: "Program not found",
      })
    }

    if (program.paymentStatus !== "CASH_ON_DELIVERY") {
      return res.status(400).json({
        message: "This program is not marked as cash on delivery",
      })
    }

    // Update program payment status
    program.paidAmount = totalAmount
    program.remainingAmount = 0
    program.paymentStatus = "FULLY_PAID"
    program.paymentMethod = "CASH" // Change from CASH_ON_DELIVERY to CASH

    await program.save()

    // Create money record for the completed payment
    const moneyRecord = new Money({
      patientId: program.patientid._id,
      programId: programId,
      price: totalAmount,
      status: "completed",
      invoiceId: `COD-${Date.now()}`,
      programType: programType,
      comment: `Cash on delivery payment completed for ${programType} - ${program.patientid.name}`,
    })

    await moneyRecord.save()

    console.log("Cash on delivery payment completed successfully:", {
      programId,
      programType,
      totalAmount,
      patientName: program.patientid.name,
    })

    res.status(200).json({
      message: "Cash on delivery payment completed successfully",
      program: {
        _id: program._id,
        programType,
        patientName: program.patientid.name,
        totalAmount,
        paymentStatus: program.paymentStatus,
        paymentMethod: program.paymentMethod,
      },
      moneyRecord: {
        _id: moneyRecord._id,
        invoiceId: moneyRecord.invoiceId,
        price: moneyRecord.price,
        status: moneyRecord.status,
      },
    })
  } catch (error) {
    console.error("Error completing cash on delivery payment:", error)
    res.status(500).json({
      message: "Error completing cash on delivery payment",
      error: error.message,
    })
  }
})

module.exports = router
