// In your backend routes (Express.js example)
const express = require("express")
const router = express.Router()
const FullProgram = require("../models/FullProgram")

// Helper function to calculate payment status
const calculatePaymentStatus = async (appointmentId) => {
  try {
    const Money = require("../models/Money")
    const Checks = require("../models/Checks")

    // Get all completed money records for this appointment
    const moneyRecords = await Money.find({
      programId: appointmentId,
      status: "completed",
    })
    const totalMoneyPaid = moneyRecords.reduce((sum, record) => sum + record.price, 0)

    // Get all cleared checks for this appointment
    const clearedChecks = await Checks.find({
      programId: appointmentId,
      status: "cleared",
      isActive: true,
    })
    const totalChecksPaid = clearedChecks.reduce((sum, check) => sum + check.amount, 0)

    const totalPaid = totalMoneyPaid + totalChecksPaid

    return {
      totalPaid,
      moneyPaid: totalMoneyPaid,
      checksPaid: totalChecksPaid,
    }
  } catch (error) {
    console.error("Error calculating payment status:", error)
    return { totalPaid: 0, moneyPaid: 0, checksPaid: 0 }
  }
}

// GET all appointments
router.get("/fullprogram", async (req, res) => {
  try {
    const appointments = await FullProgram.find()

    // Add payment calculations for each appointment and update their status
    const appointmentsWithPaymentInfo = await Promise.all(
      appointments.map(async (appointment) => {
        const paymentInfo = await calculatePaymentStatus(appointment._id)

        // Update the appointment's payment status based on actual payments
        let updatedPaymentStatus = appointment.paymentStatus
        let updatedPaidAmount = appointment.paidAmount || 0
        let updatedRemainingAmount = appointment.remainingAmount || appointment.totalAmount || 0

        // If we have actual payments, update the status
        if (paymentInfo.totalPaid > 0) {
          updatedPaidAmount = paymentInfo.totalPaid
          updatedRemainingAmount = Math.max(0, (appointment.totalAmount || 0) - paymentInfo.totalPaid)

          if (paymentInfo.totalPaid >= (appointment.totalAmount || 0)) {
            updatedPaymentStatus = "FULLY_PAID"
            updatedRemainingAmount = 0
          } else if (paymentInfo.totalPaid > 0) {
            updatedPaymentStatus = "PARTIALLY_PAID"
          }

          // Update the appointment in database if status changed
          if (
            updatedPaymentStatus !== appointment.paymentStatus ||
            updatedPaidAmount !== appointment.paidAmount ||
            updatedRemainingAmount !== appointment.remainingAmount
          ) {
            await FullProgram.findByIdAndUpdate(appointment._id, {
              paymentStatus: updatedPaymentStatus,
              paidAmount: updatedPaidAmount,
              remainingAmount: updatedRemainingAmount,
            })
          }
        }

        const paymentPercentage =
          (appointment.totalAmount || 0) > 0
            ? Math.round((updatedPaidAmount / (appointment.totalAmount || 1)) * 100)
            : 0

        return {
          ...appointment.toObject(),
          calculatedPaidAmount: updatedPaidAmount,
          moneyPaid: paymentInfo.moneyPaid,
          checksPaid: paymentInfo.checksPaid,
          paymentPercentage: paymentPercentage,
          paymentStatus: updatedPaymentStatus,
          paidAmount: updatedPaidAmount,
          remainingAmount: updatedRemainingAmount,
        }
      }),
    )

    res.json(appointmentsWithPaymentInfo)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// UPDATE an appointment
router.put("/fullprogram/:id", async (req, res) => {
  try {
    const { status, paidAmount, remainingAmount, paymentStatus, ...appointmentData } = req.body

    // Find the appointment by ID
    const appointment = await FullProgram.findById(req.params.id)

    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" })
    }

    // If payment amounts are provided, update them
    if (paidAmount !== undefined) {
      appointment.paidAmount = paidAmount
    }

    if (remainingAmount !== undefined) {
      appointment.remainingAmount = remainingAmount
    }

    if (paymentStatus) {
      appointment.paymentStatus = paymentStatus
    }

    // Parse the appointment date and time for automatic status updates
    const currentDateTime = new Date()
    const appointmentDateTime = new Date(`${appointment.date}T${appointment.time}`)

    // If the appointment time has passed and the status is not 'complete', mark it as complete
    if (appointmentDateTime < currentDateTime && appointment.status !== "complete" && !status) {
      appointment.status = "complete"
    } else if (status) {
      appointment.status = status
    }

    // Update payment status method
    // appointment.updatePaymentStatus() // Assuming this method exists on the model

    // Update the appointment with new data
    const updatedAppointment = await FullProgram.findByIdAndUpdate(
      req.params.id,
      {
        ...appointmentData,
        status: appointment.status,
        paidAmount: appointment.paidAmount,
        remainingAmount: appointment.remainingAmount,
        paymentStatus: appointment.paymentStatus,
      },
      { new: true },
    )

    // Send the updated appointment back as the response
    res.json(updatedAppointment)
  } catch (error) {
    console.error("Error updating appointment:", error)
    res.status(400).json({ message: error.message })
  }
})

// DELETE an appointment
router.delete("/fullprogram/:id", async (req, res) => {
  try {
    await FullProgram.findByIdAndDelete(req.params.id)
    res.status(204).end()
  } catch (error) {
    res.status(400).json({ message: error.message })
  }
})

// GET a single appointment by ID
router.get("/fullprogram/:id", async (req, res) => {
  try {
    const appointment = await FullProgram.findById(req.params.id)
    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" })
    }
    res.json(appointment)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

module.exports = router
