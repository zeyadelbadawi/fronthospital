const express = require("express")
const router = express.Router()
const { body, param, validationResult } = require("express-validator")
const Patient = require("../models/users/Patient")
const SchoolProgram = require("../models/SchoolProgram")
const SchoolPlan = require("../models/School/schoolPlan") // Fixed import path for SchoolPlan model
const mongoose = require("mongoose") // Declared mongoose variable

// Get school programs with pagination and search - FIXED POPULATION
router.get("/school-programs", async (req, res) => {
  const { page = 1, limit = 10, search = "" } = req.query

  try {
    const query = {}

    if (search) {
      // Search in patient name or unicValue
      const patients = await Patient.find({
        name: { $regex: search, $options: "i" },
      }).select("_id")

      if (patients.length > 0) {
        query.$or = [
          { patientid: { $in: patients.map((p) => p._id) } },
          { unicValue: { $regex: search, $options: "i" } },
        ]
      } else {
        query.unicValue = { $regex: search, $options: "i" }
      }
    }

    const programs = await SchoolProgram.find(query)
      .populate({
        path: "patientid", // This should match your SchoolProgram model field
        select: "name email phone dateOfBirth address gender assignedDepartment",
        model: "Patient",
      })
      .skip((Number.parseInt(page) - 1) * Number.parseInt(limit))
      .limit(Number.parseInt(limit))
      .sort({ createdAt: -1 })

    const totalPrograms = await SchoolProgram.countDocuments(query)

    // Transform the data to include patient info at the root level
    const transformedPrograms = programs.map((program) => ({
      ...program.toObject(),
      patient: program.patientid, // Make sure patient data is accessible
      patientName: program.patientid?.name || "Unknown Patient",
      patientEmail: program.patientid?.email || "",
      patientPhone: program.patientid?.phone || "",
    }))

    res.status(200).json({
      programs: transformedPrograms,
      totalPages: Math.ceil(totalPrograms / Number.parseInt(limit)),
      currentPage: Number.parseInt(page),
      totalPrograms,
    })
  } catch (error) {
    console.error("Error fetching school programs:", error)
    res.status(500).json({ message: "Error fetching school programs", error: error.message })
  }
})

// Get appointments by unicValue - FIXED POPULATION
router.get("/school-programs/by-unic/:unicValue", async (req, res) => {
  const { unicValue } = req.params

  try {
    const appointments = await SchoolProgram.find({ unicValue })
      .populate({
        path: "patientid",
        select: "name email phone dateOfBirth address gender assignedDepartment",
        model: "Patient",
      })
      .sort({ date: 1, time: 1 })

    // Transform the data to include patient info
    const transformedAppointments = appointments.map((appointment) => ({
      ...appointment.toObject(),
      patient: appointment.patientid,
      patientName: appointment.patientid?.name || "Unknown Patient",
      patientEmail: appointment.patientid?.email || "",
      patientPhone: appointment.patientid?.phone || "",
    }))

    res.status(200).json({
      appointments: transformedAppointments,
      unicValue,
    })
  } catch (error) {
    console.error("Error fetching appointments by unicValue:", error)
    res.status(500).json({ message: "Error fetching appointments", error: error.message })
  }
})

// Get appointments by patient ID
router.get("/school-programs/by-patient/:patientId", async (req, res) => {
  const { patientId } = req.params

  try {
    const appointments = await SchoolProgram.find({ patientid: patientId })
      .populate({
        path: "patientid",
        select: "name email phone dateOfBirth address gender assignedDepartment",
        model: "Patient",
      })
      .sort({ date: 1, time: 1 })

    // Transform the data to include patient info
    const transformedAppointments = appointments.map((appointment) => ({
      ...appointment.toObject(),
      patient: appointment.patientid,
      patientName: appointment.patientid?.name || "Unknown Patient",
      patientEmail: appointment.patientid?.email || "",
      patientPhone: appointment.patientid?.phone || "",
    }))

    res.status(200).json({
      appointments: transformedAppointments,
      patientId,
    })
  } catch (error) {
    console.error("Error fetching appointments by patient ID:", error)
    res.status(500).json({ message: "Error fetching appointments", error: error.message })
  }
})

// Add new appointment to existing program group - ENHANCED ERROR HANDLING
router.post(
  "/school-programs/add-appointment",
  [
    body("patientid").notEmpty().withMessage("Patient ID is required"),
    body("date").isISO8601().withMessage("Valid date is required"),
    body("time")
      .matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/)
      .withMessage("Valid time format required (HH:MM)"),
    body("description").isLength({ min: 5 }).withMessage("Description must be at least 5 characters"),
    body("unicValue").notEmpty().withMessage("Program ID (unicValue) is required"),
  ],
  async (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({
        message: "Validation failed",
        errors: errors.array(),
      })
    }

    const { patientid, date, time, description, unicValue } = req.body

    try {
      // Validate patient exists
      const patient = await Patient.findById(patientid)
      if (!patient) {
        return res.status(404).json({ message: "Patient not found" })
      }

      console.log("[v0] Adding appointment for patient:", patient.name, "ID:", patient._id)

      // Validate unicValue exists
      const existingProgram = await SchoolProgram.findOne({ unicValue })
      if (!existingProgram) {
        return res.status(404).json({ message: "Program group not found" })
      }

      const allAppointments = await SchoolProgram.find({ unicValue })
      console.log("[v0] Existing appointments for this evaluation:", allAppointments.length)
      console.log("[v0] Appointment statuses:", allAppointments.map(apt => ({ id: apt._id, status: apt.status })))

      // Check for appointment conflicts
      const appointmentDateTime = new Date(`${date}T${time}`)
      const now = new Date()

      if (appointmentDateTime <= now) {
        return res.status(400).json({ message: "Appointment must be scheduled for a future date and time" })
      }

      // Check if patient already has appointment at this exact time
      const conflictingAppointment = await SchoolProgram.findOne({
        patientid,
        date,
        time,
        status: { $ne: "cancelled" },
      })

      if (conflictingAppointment) {
        return res.status(400).json({ message: "Patient already has an appointment at this time" })
      }

      // Create new appointment
      const appointmentData = {
        patientid,
        date,
        time,
        description,
        unicValue,
        status: "not completed",
        programType: existingProgram.programType || "school_evaluation",
        programKind: existingProgram.programKind || "School",
        createdAt: new Date(),
        updatedAt: new Date(),
      }

      console.log("[v0] Creating new appointment with status:", appointmentData.status)

      const newAppointment = new SchoolProgram(appointmentData)
      await newAppointment.save()

      const verifyAppointments = await SchoolProgram.find({ unicValue })
      console.log("[v0] After creation, all appointments:", verifyAppointments.map(apt => ({ id: apt._id, status: apt.status })))

      // Populate patient data for response
      await newAppointment.populate({
        path: "patientid",
        select: "name email phone dateOfBirth address gender assignedDepartment",
        model: "Patient",
      })

      // Transform response data
      const transformedAppointment = {
        ...newAppointment.toObject(),
        patient: newAppointment.patientid,
        patientName: newAppointment.patientid?.name || "Unknown Patient",
        patientEmail: newAppointment.patientid?.email || "",
        patientPhone: newAppointment.patientid?.phone || "",
      }

      console.log("[v0] Appointment created successfully:", newAppointment._id)

      res.status(201).json({
        message: "Appointment added successfully",
        appointment: transformedAppointment,
      })
    } catch (error) {
      console.error("[v0] Error adding appointment:", error)

      if (error.code === 11000) {
        if (error.keyPattern && error.keyPattern.unicValue) {
          return res.status(400).json({
            message:
              "Database configuration error: The unicValue field has a unique constraint that needs to be removed.",
            error: "UNIQUE_CONSTRAINT_ERROR",
            solution: "Please run: db.schoolprograms.dropIndex('unicValue_1') in MongoDB shell",
          })
        }
      }

      res.status(500).json({
        message: "Error adding appointment",
        error: error.message,
        errorType: error.name || "UnknownError",
      })
    }
  },
)

// Update appointment - FIXED POPULATION
router.put(
  "/school-programs/:appointmentId",
  [
    param("appointmentId").isMongoId().withMessage("Valid appointment ID required"),
    body("date").optional().isISO8601().withMessage("Valid date is required"),
    body("time")
      .optional()
      .matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/)
      .withMessage("Valid time format required (HH:MM)"),
    body("description").optional().isLength({ min: 5 }).withMessage("Description must be at least 5 characters"),
  ],
  async (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({
        message: "Validation failed",
        errors: errors.array(),
      })
    }

    const { appointmentId } = req.params
    const updateData = req.body

    try {
      const appointment = await SchoolProgram.findById(appointmentId)
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" })
      }

      // Check if appointment is in the past
      const appointmentDateTime = new Date(`${appointment.date}T${appointment.time}`)
      const now = new Date()

      if (appointmentDateTime <= now) {
        return res.status(400).json({ message: "Cannot edit past appointments" })
      }

      // If updating date/time, validate future date
      if (updateData.date && updateData.time) {
        const newDateTime = new Date(`${updateData.date}T${updateData.time}`)
        if (newDateTime <= now) {
          return res.status(400).json({ message: "Updated appointment must be scheduled for a future date and time" })
        }
      }

      // Update appointment
      const updatedAppointment = await SchoolProgram.findByIdAndUpdate(
        appointmentId,
        { ...updateData, updatedAt: new Date() },
        { new: true },
      ).populate({
        path: "patientid",
        select: "name email phone dateOfBirth address gender assignedDepartment",
        model: "Patient",
      })

      // Transform response data
      const transformedAppointment = {
        ...updatedAppointment.toObject(),
        patient: updatedAppointment.patientid,
        patientName: updatedAppointment.patientid?.name || "Unknown Patient",
        patientEmail: updatedAppointment.patientid?.email || "",
        patientPhone: updatedAppointment.patientid?.phone || "",
      }

      res.status(200).json({
        message: "Appointment updated successfully",
        appointment: transformedAppointment,
      })
    } catch (error) {
      console.error("Error updating appointment:", error)
      res.status(500).json({ message: "Error updating appointment", error: error.message })
    }
  },
)

// Complete appointment - FIXED POPULATION
router.patch(
  "/school-programs/:appointmentId/complete",
  [param("appointmentId").isMongoId().withMessage("Valid appointment ID required")],
  async (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({
        message: "Validation failed",
        errors: errors.array(),
      })
    }

    const { appointmentId } = req.params

    try {
      const appointment = await SchoolProgram.findById(appointmentId)
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" })
      }

      if (appointment.status === "completed") {
        return res.status(400).json({ message: "Appointment is already completed" })
      }

      const updatedAppointment = await SchoolProgram.findByIdAndUpdate(
        appointmentId,
        { status: "completed", completedAt: new Date() },
        { new: true },
      ).populate({
        path: "patientid",
        select: "name email phone dateOfBirth address gender assignedDepartment",
        model: "Patient",
      })

      // Transform response data
      const transformedAppointment = {
        ...updatedAppointment.toObject(),
        patient: updatedAppointment.patientid,
        patientName: updatedAppointment.patientid?.name || "Unknown Patient",
        patientEmail: updatedAppointment.patientid?.email || "",
        patientPhone: updatedAppointment.patientid?.phone || "",
      }

      console.log("[v0] Single appointment completed successfully:", appointmentId)
      console.log("[v0] Notification will only be sent when sheet is locked via 'Save Forever' button")

      res.status(200).json({
        message: "Appointment completed successfully",
        appointment: transformedAppointment,
      })
    } catch (error) {
      console.error("Error completing appointment:", error)
      res.status(500).json({ message: "Error completing appointment", error: error.message })
    }
  },
)

// Cancel/Delete appointment
router.delete(
  "/school-programs/:appointmentId",
  [param("appointmentId").isMongoId().withMessage("Valid appointment ID required")],
  async (req, res) => {
    const { appointmentId } = req.params

    try {
      const appointment = await SchoolProgram.findById(appointmentId)
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" })
      }

      await SchoolProgram.findByIdAndDelete(appointmentId)

      res.status(200).json({ message: "Appointment cancelled successfully" })
    } catch (error) {
      console.error("Error cancelling appointment:", error)
      res.status(500).json({ message: "Error cancelling appointment", error: error.message })
    }
  },
)

// Complete all appointments for a program group
router.patch(
  "/school-programs/complete-all/:unicValue",
  [param("unicValue").notEmpty().withMessage("Program ID (unicValue) is required")],
  async (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({
        message: "Validation failed",
        errors: errors.array(),
      })
    }

    const { unicValue } = req.params

    try {
      // Find all appointments for this program group
      const appointments = await SchoolProgram.find({ unicValue })
      if (appointments.length === 0) {
        return res.status(404).json({ message: "No appointments found for this program" })
      }

      // Update all incomplete appointments to completed
      const result = await SchoolProgram.updateMany(
        { unicValue, status: { $ne: "completed" } },
        {
          status: "completed",
          completedAt: new Date(),
          updatedAt: new Date(),
        },
      )

      res.status(200).json({
        message: "All appointments completed successfully",
        updatedCount: result.modifiedCount,
        totalAppointments: appointments.length,
      })
    } catch (error) {
      console.error("Error completing all appointments:", error)
      res.status(500).json({ message: "Error completing all appointments", error: error.message })
    }
  },
)

// OPTIMIZED: Get school programs with status in single query - SOLVES N+1 PROBLEM
router.get("/school-programs-optimized", async (req, res) => {
  const { page = 1, limit = 100, search = "", doctorId } = req.query

  console.log("[v0] Backend - Received query params:", { page, limit, search, doctorId })

  try {
    const matchQuery = {}

    if (doctorId) {
      console.log("[v0] Backend - Doctor ID provided:", doctorId)
      // For doctors, we need to find programs that have at least one appointment assigned to them
      const appointmentsForDoctor = await SchoolProgram.find({
        assignedDoctor: new mongoose.Types.ObjectId(doctorId),
      }).distinct("unicValue")

      console.log("[v0] Backend - Appointments found for doctor:", appointmentsForDoctor)

      if (appointmentsForDoctor.length === 0) {
        // Doctor has no assigned appointments
        console.log("[v0] Backend - Doctor has no assigned appointments, returning empty")
        return res.status(200).json({
          programs: [],
          totalPages: 0,
          currentPage: Number.parseInt(page),
          totalPrograms: 0,
          optimized: true,
        })
      }

      matchQuery.unicValue = { $in: appointmentsForDoctor }
      console.log("[v0] Backend - Match query set to:", matchQuery)
    }

    // Search functionality
    if (search) {
      const patients = await Patient.find({
        name: { $regex: search, $options: "i" },
      }).select("_id")

      if (patients.length > 0) {
        matchQuery.$or = [
          { patientid: { $in: patients.map((p) => p._id) } },
          { unicValue: { $regex: search, $options: "i" } },
        ]
      } else {
        matchQuery.unicValue = { $regex: search, $options: "i" }
      }
    }

    console.log("[v0] Backend - Final match query:", matchQuery)

    // OPTIMIZED AGGREGATION: Get programs with completion status in single query
    const aggregationPipeline = [
      { $match: matchQuery },
      {
        $group: {
          _id: {
            patientid: "$patientid",
            unicValue: "$unicValue",
          },
          // Keep first occurrence data
          firstProgram: { $first: "$$ROOT" },
          // Count total sessions for this program
          totalSessions: { $sum: 1 },
          // Count completed sessions
          completedSessions: {
            $sum: {
              $cond: [{ $eq: ["$status", "completed"] }, 1, 0],
            },
          },
          // Get all statuses to determine overall completion
          allStatuses: { $push: "$status" },
          // Get latest status
          latestStatus: { $last: "$status" },
          // Get creation date for sorting
          createdAt: { $first: "$createdAt" },
          // Get latest appointment date for sorting
          oldestAppointmentDate: { $min: "$date" },
        },
      },
      {
        $project: {
          _id: "$firstProgram._id",
          patientid: "$firstProgram.patientid",
          unicValue: "$firstProgram.unicValue",
          description: "$firstProgram.description",
          date: "$firstProgram.date",
          time: "$firstProgram.time",
          status: "$latestStatus",
          totalSessions: "$totalSessions",
          completedSessions: "$completedSessions",
          createdAt: "$createdAt",
          oldestAppointmentDate: "$oldestAppointmentDate",
          paymentStatus: "$firstProgram.paymentStatus",
          paymentMethod: "$firstProgram.paymentMethod",
          totalAmount: "$firstProgram.totalAmount",
          paidAmount: "$firstProgram.paidAmount",
        },
      },
      { $sort: { createdAt: -1 } },
      { $skip: (Number.parseInt(page) - 1) * Number.parseInt(limit) },
      { $limit: Number.parseInt(limit) },
    ]

    const programs = await SchoolProgram.aggregate(aggregationPipeline)

    console.log("[v0] Backend - Programs after aggregation:", programs.length)

    // Get total count for pagination
    const countPipeline = [
      { $match: matchQuery },
      {
        $group: {
          _id: {
            patientid: "$patientid",
            unicValue: "$unicValue",
          },
        },
      },
      { $count: "total" },
    ]

    const countResult = await SchoolProgram.aggregate(countPipeline)
    const totalPrograms = countResult.length > 0 ? countResult[0].total : 0

    console.log("[v0] Backend - Total programs count:", totalPrograms)

    // OPTIMIZED: Populate patient information in batch
    const patientIds = [...new Set(programs.map((p) => p.patientid).filter(Boolean))]
    const patients = await Patient.find({ _id: { $in: patientIds } })
      .select("name email phone _id")
      .lean()

    // Create patient lookup map for O(1) access
    const patientMap = new Map()
    patients.forEach((patient) => {
      patientMap.set(patient._id.toString(), patient)
    })

    // OPTIMIZED: Transform programs with patient info
    const programsWithPatientInfo = await Promise.all(
      programs.map(async (program) => {
        const patientInfo = patientMap.get(program.patientid?.toString()) || {}

        // Generate program name based on patient and creation order
        const programName = generateOptimizedProgramName(program, programs, patientInfo.name)

        let planExists = false
        let isLocked = false
        let updatedAt = null
        let existingPlan = null
        if (program.patientid && program.unicValue) {
          try {
            const decodedUnicValue = decodeURIComponent(program.unicValue)
            existingPlan = await SchoolPlan.findOne({
              patient: program.patientid,
              unicValue: decodedUnicValue,
            })
            planExists = !!existingPlan
            isLocked = existingPlan?.isLocked || false
            updatedAt = existingPlan?.updatedAt || null
          } catch (error) {
            console.error(`Error checking plan existence for ${program.unicValue}:`, error)
          }
        }

        let displayStatus = program.status
        if (program.completedSessions === program.totalSessions && program.totalSessions > 0) {
          // All appointments completed, but check if evaluation is explicitly completed
          if (existingPlan?.evaluationCompleted) {
            displayStatus = "completed"
          } else {
            // All appointments done but evaluation not completed - show as active/in progress
            displayStatus = "active"
          }
        } else if (program.completedSessions > 0) {
          // Some appointments completed
          displayStatus = "active"
        }

        return {
          ...program,
          patientName: patientInfo.name || "Unknown Patient",
          patientEmail: patientInfo.email || null,
          patientPhone: patientInfo.phone || null,
          patientId: program.patientid || null,
          programName,
          planExists,
          isLocked, // Include isLocked in response
          isCompleted: existingPlan?.evaluationCompleted || false,
          status: displayStatus, // Use calculated display status
          updatedAt, // Include updatedAt in response
          sessionInfo: `${program.totalSessions} session${program.totalSessions > 1 ? "s" : ""}`,
          completionPercentage:
            program.totalSessions > 0 ? Math.round((program.completedSessions / program.totalSessions) * 100) : 0,
        }
      }),
    )

    res.status(200).json({
      programs: programsWithPatientInfo,
      totalPages: Math.ceil(totalPrograms / Number.parseInt(limit)),
      currentPage: Number.parseInt(page),
      totalPrograms,
      optimized: true, // Flag to indicate this is the optimized endpoint
    })
  } catch (error) {
    console.error("[v0] Backend - Error fetching optimized school programs:", error)
    res.status(500).json({
      message: "Error fetching school programs",
      error: error.message,
    })
  }
})

// OPTIMIZED: Generate program name without additional API calls
function generateOptimizedProgramName(program, allPrograms, patientName) {
  if (!program.patientid) {
    return "School Evaluation Program"
  }

  // Get ALL programs for this specific patient, not just the filtered ones
  const patientId = program.patientid?._id?.toString() || program.patientid?.toString()
  
  // Filter all programs for this patient
  const patientPrograms = allPrograms.filter((p) => {
    const pId = p.patientid?._id?.toString() || p.patientid?.toString()
    return pId === patientId
  })

  // Sort by creation date (earliest first)
  const sortedPatientPrograms = patientPrograms.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))

  // Find the index of current program by unicValue
  const programIndex = sortedPatientPrograms.findIndex((p) => p.unicValue === program.unicValue)
  const programNumber = programIndex >= 0 ? programIndex + 1 : 1

  // Get the year from creation date
  const year = new Date(program.createdAt).getFullYear()

  console.log(`[v0] Generated name for unicValue ${program.unicValue}: School Evaluation ${programNumber} (${year})`)

  return `School Evaluation ${programNumber} (${year})`
}

router.patch("/school-programs/:appointmentId/assign-doctor", async (req, res) => {
  const { appointmentId } = req.params
  const { doctorId } = req.body

  try {
    if (!appointmentId || !doctorId) {
      return res.status(400).json({ message: "Appointment ID and Doctor ID are required" })
    }

    // Validate appointment exists
    const appointment = await SchoolProgram.findById(appointmentId)
    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" })
    }

    // Validate doctor exists
    const Doctor = require("../models/users/Doctor")
    const doctor = await Doctor.findById(doctorId)
    if (!doctor) {
      return res.status(404).json({ message: "Doctor not found" })
    }

    // Update appointment with assigned doctor
    const updatedAppointment = await SchoolProgram.findByIdAndUpdate(
      appointmentId,
      { assignedDoctor: doctorId, updatedAt: new Date() },
      { new: true },
    )
      .populate("assignedDoctor", "username email")
      .populate("patientid", "name email phone")

    res.status(200).json({
      message: "Doctor assigned successfully",
      appointment: updatedAppointment,
    })
  } catch (error) {
    console.error("Error assigning doctor:", error)
    res.status(500).json({ message: "Error assigning doctor", error: error.message })
  }
})

router.get("/doctors-for-assignment", async (req, res) => {
  try {
    const Doctor = require("../models/users/Doctor")
    const doctors = await Doctor.find({ role: { $in: ["doctor", undefined] } })
      .select("_id username email phone departments")
      .populate("departments", "name")
      .lean()

    const doctorsWithDisplayName = doctors.map((doctor) => ({
      _id: doctor._id,
      displayName: doctor.username || doctor.email?.split("@")[0] || "Unknown Doctor",
      username: doctor.username,
      email: doctor.email,
      phone: doctor.phone,
      departments: doctor.departments,
    }))

    res.status(200).json({
      success: true,
      doctors: doctorsWithDisplayName,
    })
  } catch (error) {
    console.error("Error fetching doctors:", error)
    res.status(500).json({ message: "Error fetching doctors", error: error.message })
  }
})

// OPTIMIZED: Get program appointments with status (replaces multiple API calls)
router.get("/school-programs-with-appointments/:unicValue", async (req, res) => {
  const { unicValue } = req.params
  const { doctorId } = req.query // Optional: filter by doctor if provided

  try {
    // Single aggregation to get all appointment data with patient info
    const pipeline = [
      { $match: { unicValue } },
      ...(doctorId ? [{ $match: { assignedDoctor: new mongoose.Types.ObjectId(doctorId) } }] : []),
      {
        $lookup: {
          from: "patients",
          localField: "patientid",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "assignedDoctor",
          foreignField: "_id",
          as: "assignedDoctorInfo",
        },
      },
      {
        $unwind: {
          path: "$assignedDoctorInfo",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $project: {
          _id: 1,
          patientid: 1,
          date: 1,
          time: 1,
          description: 1,
          unicValue: 1,
          status: 1,
          createdAt: 1,
          updatedAt: 1,
          completedAt: 1,
          assignedDoctor: {
            _id: "$assignedDoctorInfo._id",
            username: "$assignedDoctorInfo.username",
            email: "$assignedDoctorInfo.email",
          },
          patient: {
            _id: "$patient._id",
            name: "$patient.name",
            email: "$patient.email",
            phone: "$patient.phone",
          },
        },
      },
      { $sort: { date: 1, time: 1 } },
    ]

    const appointments = await SchoolProgram.aggregate(pipeline)

    // Calculate program completion status
    const totalAppointments = appointments.length
    const completedAppointments = appointments.filter((apt) => apt.status === "completed").length
    
    const SchoolPlan = require("../models/School/schoolPlan")
    let isEvaluationClosed = false
    
    if (appointments.length > 0) {
      const firstAppointment = appointments[0]
      const plan = await SchoolPlan.findOne({
        patient: firstAppointment.patientid,
        unicValue: unicValue,
      })
      
      isEvaluationClosed = plan?.evaluationCompleted || false
    }

    res.status(200).json({
      appointments,
      unicValue,
      stats: {
        total: totalAppointments,
        completed: completedAppointments,
        remaining: totalAppointments - completedAppointments,
        isCompleted: isEvaluationClosed,
        completionPercentage: totalAppointments > 0 ? Math.round((completedAppointments / totalAppointments) * 100) : 0,
      },
      optimized: true,
    })
  } catch (error) {
    console.error("Error fetching optimized appointments:", error)
    res.status(500).json({
      message: "Error fetching appointments",
      error: error.message,
    })
  }
})

// Check sheet status with debug logging and fixed field name
router.get("/check-sheet-status/:programId/:unicValue", async (req, res) => {
  try {
    const { programId, unicValue } = req.params
    
    console.log("[v0] Checking sheet status for:", { programId, unicValue })

    // Check if all appointments are completed
    const appointments = await SchoolProgram.find({
      patientid: programId,
      unicValue: unicValue,
    })
    
    console.log("[v0] Found appointments:", appointments.length)

    if (appointments.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No appointments found for this evaluation",
      })
    }

    const allCompleted = appointments.every((apt) => apt.status === "completed")
    
    console.log("[v0] All appointments completed:", allCompleted)

    if (!allCompleted) {
      return res.status(400).json({
        success: false,
        message: "Not all appointments are completed yet",
      })
    }

    const plan = await SchoolPlan.findOne({
      patient: programId,
      unicValue: unicValue,
    })
    
    console.log("[v0] Found plan:", plan ? "Yes" : "No")
    if (plan) {
      console.log("[v0] Plan locked:", plan.isLocked)
      console.log("[v0] Plan evaluationCompleted:", plan.evaluationCompleted)
    }

    if (!plan) {
      return res.status(400).json({
        success: false,
        message: "Please upload the evaluation sheet first",
      })
    }

    // All checks passed - sheet exists and all appointments are completed
    return res.status(200).json({
      success: true,
      message: "Ready to complete evaluation",
      data: {
        allAppointmentsCompleted: true,
        sheetExists: true,
        sheetLocked: plan.isLocked, // Return lock status for information only
      },
    })
  } catch (error) {
    console.error("Error checking sheet status:", error)
    return res.status(500).json({
      success: false,
      message: "Error checking sheet status",
    })
  }
})

// Add new appointment endpoint
router.post("/add-appointment",  async (req, res) => {
  try {
    const { patientid, date, time, appointmentDescription, doctorId, doctorName, unicValue } = req.body

    console.log("[v0] =========================")
    console.log("[v0] Adding new appointment for unicValue:", unicValue)

    // Get existing program to inherit properties
    const existingProgram = await SchoolProgram.findOne({ unicValue }).lean()
    if (!existingProgram) {
      return res.status(404).json({ message: "School program not found" })
    }

    const allExistingAppointments = await SchoolProgram.find({ unicValue })
    console.log("[v0] Existing appointments before creation:", allExistingAppointments.map(apt => ({ 
      id: apt._id, 
      status: apt.status,
      date: apt.date 
    })))

    // Check if there are any incomplete appointments
    const hasIncomplete = allExistingAppointments.some((apt) => apt.status !== "completed")
    if (hasIncomplete) {
      const incompleteAppointment = allExistingAppointments.find((apt) => apt.status !== "completed")
      console.log("[v0] Found incomplete appointment:", incompleteAppointment._id)
      return res.status(400).json({
        message: "You have to complete the previous appointment to create a new one",
        incompleteAppointment: {
          date: incompleteAppointment.date,
          status: incompleteAppointment.status,
        },
      })
    }

    // Create new appointment
    const appointmentData = {
      ...existingProgram,
      _id: undefined, // Remove the _id so a new one is generated
      patientid: patientid || existingProgram.patientid,
      date,
      time,
      appointmentDescription,
      doctorId: doctorId || existingProgram.doctorId,
      doctorName: doctorName || existingProgram.doctorName,
      unicValue,
      status: "scheduled",
      sessionDescription: "",
      SessionNotes: "",
      patientCameInPerson: false,
      programKind: existingProgram.programKind || "School",
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    console.log("[v0] Creating new appointment with status:", appointmentData.status)

    const newAppointment = new SchoolProgram(appointmentData)
    await newAppointment.save()

    const verifyAppointments = await SchoolProgram.find({ unicValue })
    console.log("[v0] After creation, all appointments:", verifyAppointments.map(apt => ({ 
      id: apt._id, 
      status: apt.status,
      date: apt.date 
    })))

    // Check if any previously completed appointments are now incomplete
    const nowIncomplete = verifyAppointments.filter(apt => 
      allExistingAppointments.some(existing => 
        existing._id.toString() === apt._id.toString() && 
        existing.status === 'completed' && 
        apt.status !== 'completed'
      )
    )

    if (nowIncomplete.length > 0) {
      console.error("[v0] ERROR: Completed appointments became incomplete!", nowIncomplete)
    }

    // Populate patient data for response
    await newAppointment.populate({
      path: "patientid",
      select: "name email phone dateOfBirth address gender assignedDepartment",
      model: "Patient",
    })

    // Transform response data
    const transformedAppointment = {
      ...newAppointment.toObject(),
      patient: newAppointment.patientid,
      patientName: newAppointment.patientid?.name || "Unknown Patient",
      patientEmail: newAppointment.patientid?.email || "",
      patientPhone: newAppointment.patientid?.phone || "",
    }

    console.log("[v0] Appointment created successfully:", newAppointment._id)
    console.log("[v0] =========================")

    res.status(201).json({
      message: "Appointment added successfully",
      appointment: transformedAppointment,
    })
  } catch (error) {
    console.error("[v0] Error adding appointment:", error)

    if (error.code === 11000) {
      if (error.keyPattern && error.keyPattern.unicValue) {
        return res.status(400).json({
          message:
            "Database configuration error: The unicValue field has a unique constraint that needs to be removed.",
          error: "UNIQUE_CONSTRAINT_ERROR",
          solution: "Please run: db.schoolprograms.dropIndex('unicValue_1') in MongoDB shell",
        })
      }
    }

    res.status(500).json({
      message: "Error adding appointment",
      error: error.message,
      errorType: error.name || "UnknownError",
    })
  }
})

module.exports = router
