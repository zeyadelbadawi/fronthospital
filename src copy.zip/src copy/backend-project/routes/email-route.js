const nodemailer = require("nodemailer")
const express = require("express")
const emailRouter = express.Router()
const crypto = require("crypto")

// In-memory storage for email content (in production, use a database)
const emailStorage = new Map()

// Load environment variables from .env file
console.log("SMTP config:", {
  host: process.env.NODE_MAILER_HOST,
  port: process.env.NODE_MAILER_PORT,
  user: process.env.NODE_MAILER_USER,
})

// 1. Create transporter
const transporter = nodemailer.createTransport({
  host: process.env.NODE_MAILER_HOST,
  port: process.env.NODE_MAILER_PORT,
  secure: true,
  auth: {
    user: process.env.NODE_MAILER_USER,
    pass: process.env.NODE_MAILER_PASS,
  },
})

const generateEmailHTML = (content, emailId, baseUrl) => {
  const viewInBrowserUrl = `${baseUrl}/email/view/${emailId}`

  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Email</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
        }
        .view-in-browser {
          background-color: #f5f5f5;
          padding: 10px 15px;
          text-align: center;
          border-bottom: 2px solid #e0e0e0;
          margin-bottom: 20px;
        }
        .view-in-browser a {
          color: #0066cc;
          text-decoration: none;
          font-size: 14px;
        }
        .view-in-browser a:hover {
          text-decoration: underline;
        }
        .email-content {
          padding: 20px;
          background-color: #ffffff;
        }
        .footer {
          margin-top: 30px;
          padding-top: 20px;
          border-top: 1px solid #e0e0e0;
          font-size: 12px;
          color: #666;
          text-align: center;
        }
      </style>
    </head>
    <body>
      <div class="view-in-browser">
        <a href="${viewInBrowserUrl}" target="_blank">View this email in your browser</a>
      </div>
      <div class="email-content">
        ${content}
      </div>
      <div class="footer">
        <p>This email was sent from the Therapy Management System</p>
      </div>
    </body>
    </html>
  `
}

// 2. Send email with attachment and HTML support
emailRouter.post("/send-email", async (req, res) => {
  try {
    const { to, subject, text, html, filePath } = req.body
    if (!to || !subject || (!text && !html)) {
      return res.status(400).json({ error: "Missing required fields" })
    }

    // Optional: Validate filePath if provided
    if (filePath) {
      const fs = require("fs")
      if (!fs.existsSync(filePath)) {
        return res.status(400).json({ error: "Invalid or missing file path" })
      }
    }

    const emailId = crypto.randomBytes(16).toString("hex")

    const baseUrl = process.env.NEXT_PUBLIC_API_URL || `${req.protocol}://${req.get("host")}`

    const emailContent = html || text.replace(/\n/g, "<br>")
    const htmlContent = generateEmailHTML(emailContent, emailId, baseUrl)

    emailStorage.set(emailId, {
      to,
      subject,
      content: emailContent,
      html: htmlContent,
      createdAt: new Date(),
      filePath: filePath || null,
    })

    const mailOptions = {
      from: process.env.NODE_MAILER_USER,
      to,
      subject,
      html: htmlContent, // Use HTML instead of plain text
    }

    // Attach file if filePath provided
    if (filePath) {
      mailOptions.attachments = [
        {
          filename: "document.docx",
          path: filePath,
          contentType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        },
      ]
    }

    const info = await transporter.sendMail(mailOptions)
    res.status(200).json({
      message: "Email sent successfully",
      id: info.messageId,
      emailId: emailId, // Return email ID for reference
      viewUrl: `${baseUrl}/email/view/${emailId}`, // Return view URL
    })
  } catch (err) {
    res.status(500).json({ error: "Failed to send email", details: err.message })
  }
})

emailRouter.get("/view/:emailId", (req, res) => {
  const { emailId } = req.params

  const emailData = emailStorage.get(emailId)

  if (!emailData) {
    return res.status(404).send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Email Not Found</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f5f5f5;
          }
          .error-container {
            text-align: center;
            padding: 40px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
          }
          h1 { color: #d32f2f; }
          p { color: #666; }
        </style>
      </head>
      <body>
        <div class="error-container">
          <h1>Email Not Found</h1>
          <p>The email you're looking for doesn't exist or has expired.</p>
        </div>
      </body>
      </html>
    `)
  }

  // Return the stored HTML content without the "View in Browser" link
  const htmlWithoutViewLink = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${emailData.subject}</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #f5f5f5;
        }
        .email-header {
          background-color: #ffffff;
          padding: 20px;
          border-bottom: 2px solid #e0e0e0;
          margin-bottom: 20px;
        }
        .email-header h2 {
          margin: 0 0 10px 0;
          color: #0066cc;
        }
        .email-meta {
          font-size: 14px;
          color: #666;
        }
        .email-content {
          padding: 20px;
          background-color: #ffffff;
          border-radius: 4px;
        }
        .footer {
          margin-top: 30px;
          padding-top: 20px;
          border-top: 1px solid #e0e0e0;
          font-size: 12px;
          color: #666;
          text-align: center;
        }
      </style>
    </head>
    <body>
      <div class="email-header">
        <h2>${emailData.subject}</h2>
        <div class="email-meta">
          <p><strong>To:</strong> ${emailData.to}</p>
          <p><strong>Date:</strong> ${emailData.createdAt.toLocaleString()}</p>
        </div>
      </div>
      <div class="email-content">
        ${emailData.content}
      </div>
      <div class="footer">
        <p>This email was sent from the Therapy Management System</p>
      </div>
    </body>
    </html>
  `

  res.send(htmlWithoutViewLink)
})

module.exports = emailRouter
