const express = require('express');
const router = express.Router();
const Department = require('../models/department'); // Assuming the Department model is in this path

// **Create a new Department**
router.post('/create-department', async (req, res) => {
  const { name, description } = req.body;
  
  try {
    const newDepartment = new Department({ name, description });
    await newDepartment.save();
    res.status(201).json({ message: 'Department created successfully', department: newDepartment });
  } catch (err) {
    console.error("Error creating department:", err);
    res.status(500).json({ message: 'Error creating department' });
  }
});

// **Get All Departments (with pagination and search)**
router.get('/', async (req, res) => {
  const { page = 1, limit = 10, search = '' } = req.query;  // Default page=1, limit=10

  try {
    const query = {
      $or: [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
      ]
    };

    const departments = await Department.find(query)
      .skip((page - 1) * limit)  // Skip departments based on page number
      .limit(limit);             // Limit number of results per page

    const totalDepartments = await Department.countDocuments(query); // Get total count for pagination

    res.status(200).json({
      departments,
      totalPages: Math.ceil(totalDepartments / limit),  // Calculate total pages
      currentPage: page,
      totalDepartments,
    });
  } catch (err) {
    res.status(500).json({ message: 'Error fetching departments' });
  }
});

// **Get Department by ID**
router.get('/department/:id', async (req, res) => {
  const { id } = req.params;  // Get the department ID from the URL

  try {
    const department = await Department.findById(id);
    if (!department) {
      return res.status(404).json({ message: 'Department not found' });
    }
    res.status(200).json(department); // Return the department data
  } catch (err) {
    res.status(500).json({ message: 'Error fetching department' });
  }
});

// **Edit Department Information**
router.put('/edit-department/:id', async (req, res) => {
  const { name, description } = req.body;
  const departmentId = req.params.id;

  try {
    const updatedDepartment = await Department.findByIdAndUpdate(departmentId, { name, description }, { new: true });
    if (!updatedDepartment) {
      return res.status(404).json({ message: 'Department not found' });
    }
    res.status(200).json({ message: 'Department updated successfully', department: updatedDepartment });
  } catch (err) {
    res.status(500).json({ message: 'Error updating department' });
  }
});

// **Delete Department by ID**
router.delete('/delete-department/:id', async (req, res) => {
  const departmentId = req.params.id;

  try {
    const deletedDepartment = await Department.findByIdAndDelete(departmentId);
    if (!deletedDepartment) {
      return res.status(404).json({ message: 'Department not found' });
    }
    res.status(200).json({ message: 'Department deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting department' });
  }
});

module.exports = router;
