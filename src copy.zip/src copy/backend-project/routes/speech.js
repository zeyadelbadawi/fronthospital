const express = require("express")
const router = express.Router()
const formidable = require("formidable")
const fs = require("fs")
const path = require("path")
const { v4: uuidv4 } = require("uuid")
const PatientSpeechAssignment = require("../models/Speech/PatientSpeechAssignment")
const SpeechExam = require("../models/Speech/SpeechExam")
const SpeechPlan = require("../models/Speech/SpeechPlan")
const Patient = require("../models/users/Patient")

// Helper function to get next quarter (same as doctor system)
const getNextQuarterAndYear = (currentQ, currentY) => {
  if (currentQ === 4) {
    return { quarter: 1, year: currentY + 1 }
  }
  return { quarter: currentQ + 1, year: currentY }
}
// Get all speech patient assignments
router.get("/patient-assignments", async (req, res) => {
  try {
    const { page = 1, limit = 50, search = "" } = req.query
    const skip = (page - 1) * limit

    console.log("Fetching speech patient assignments with params:", { page, limit, search })

    // Build search query
    let searchQuery = {}
    if (search) {
      // First find patients that match the search criteria
      const matchingPatients = await Patient.find({
        $or: [
          { name: { $regex: search, $options: "i" } },
          { email: { $regex: search, $options: "i" } },
          { patientId: { $regex: search, $options: "i" } },
        ],
      }).select("_id")

      const patientIds = matchingPatients.map((p) => p._id)
      searchQuery = { patient: { $in: patientIds } }
    }

    // Fetch assignments with populated patient data only (no doctorId since it doesn't exist in schema)
    const assignments = await PatientSpeechAssignment.find(searchQuery)
      .populate("patient", "name email patientId phone dateOfBirth")
      .sort({ assignedDate: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await PatientSpeechAssignment.countDocuments(searchQuery)

    console.log(`Found ${assignments.length} speech patient assignments`)

    res.json({
      success: true,
      assignments,
      pagination: {
        currentPage: Number.parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalItems: total,
        itemsPerPage: Number.parseInt(limit),
      },
    })
  } catch (error) {
    console.error("Error fetching speech patient assignments:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching speech patient assignments",
      error: error.message,
    })
  }
})

// Get all speech assignments (alternative endpoint)
router.get("/speech-assignments", async (req, res) => {
  try {
    const { page = 1, limit = 50, search = "" } = req.query
    const skip = (page - 1) * limit

    console.log("Fetching speech assignments with params:", { page, limit, search })

    // Build search query
    let searchQuery = {}
    if (search) {
      const matchingPatients = await Patient.find({
        $or: [
          { name: { $regex: search, $options: "i" } },
          { email: { $regex: search, $options: "i" } },
          { patientId: { $regex: search, $options: "i" } },
        ],
      }).select("_id")

      const patientIds = matchingPatients.map((p) => p._id)
      searchQuery = { patient: { $in: patientIds } }
    }

    const assignments = await PatientSpeechAssignment.find(searchQuery)
      .populate("patient", "name email patientId phone dateOfBirth")
      .sort({ assignedDate: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await PatientSpeechAssignment.countDocuments(searchQuery)

    console.log(`Found ${assignments.length} speech assignments`)

    res.json({
      success: true,
      assignments,
      pagination: {
        currentPage: Number.parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalItems: total,
        itemsPerPage: Number.parseInt(limit),
      },
    })
  } catch (error) {
    console.error("Error fetching speech assignments:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching speech assignments",
      error: error.message,
    })
  }
})

// Add Physical Therapy Assignment
router.post("/assign-to-Speech", async (req, res) => {
  const { patientId, notes } = req.body

  if (!patientId) {
    return res.status(400).json({ message: "Invalid or missing patient ID" })
  }

  try {
    const patient = await Patient.findById(patientId)
    if (!patient) {
      return res.status(404).json({ message: "Patient not found" })
    }

    // Ensure the patient is not already assigned to speech
    const existingAssignment = await PatientSpeechAssignment.findOne({
      patient: patientId,
    })
    if (existingAssignment) {
      return res.status(400).json({ message: "Patient already assigned to speech" })
    }

    const assignment = new PatientSpeechAssignment({
      patient: patientId,
      notes: notes || "",
      status: "active",
    })

    await assignment.save()

    res.status(201).json({ message: "Patient assigned to speech successfully", assignment })
  } catch (err) {
    res.status(500).json({ message: "Error assigning patient to speech", error: err.message })
  }
})

// Unassign from speech
router.delete("/unassign-from-Speech/:patientId", async (req, res) => {
  const { patientId } = req.params

  try {
    const assignment = await PatientSpeechAssignment.findOneAndDelete({ patient: patientId })

    if (!assignment) {
      return res.status(404).json({ message: "Assignment not found" })
    }

    res.status(200).json({ message: "Patient unassigned from speech" })
  } catch (err) {
    res.status(500).json({ message: "Error unassigning patient" })
  }
})

// Get speech Plan for a patient (latest or specific quarter/year)
router.get("/plan/:patientId", async (req, res) => {
  const { patientId } = req.params
  const { year, quarter } = req.query // Optional query parameters for historical plans

  try {
    let plan
    if (year && quarter) {
      plan = await SpeechPlan.findOne({ patient: patientId, year: Number(year), quarterOfYear: Number(quarter) })
    } else {
      // Fetch the latest plan by default
      plan = await SpeechPlan.findOne({ patient: patientId }).sort({ year: -1, quarterOfYear: -1, lastModified: -1 })
    }

    if (!plan) {
      return res.status(404).json({ message: "No plan found for this patient for the specified quarter/year." })
    }
    res.status(200).json(plan)
  } catch (err) {
    console.error("Error fetching speech plan:", err)
    res.status(500).json({ message: "Error fetching speech plan" })
  }
})

// Get all speech Plans for a patient
router.get("/plans/:patientId", async (req, res) => {
  const { patientId } = req.params
  try {
    const plans = await SpeechPlan.find({ patient: patientId }).sort({ year: -1, quarterOfYear: -1, lastModified: -1 })
    res.status(200).json(plans)
  } catch (err) {
    console.error("Error fetching all speech plans:", err)
    res.status(500).json({ message: "Error fetching all speech plans" })
  }
})

// Create speech Plan (now creates a new historical entry)
router.post("/plan", async (req, res) => {
  const { patient, title, content, createdBy, quarterOfYear, year } = req.body

  try {
    // Check for duplicate plan for the same patient, quarter, and year
    const existingPlan = await SpeechPlan.findOne({ patient, quarterOfYear, year })
    if (existingPlan) {
      return res
        .status(400)
        .json({ message: "A plan already exists for this patient for the specified quarter and year." })
    }

    const plan = new SpeechPlan({
      patient,
      title,
      content,
      createdBy: createdBy || "System",
      lastModified: new Date(),
      quarterOfYear,
      year,
    })

    await plan.save()

    res.status(201).json(plan)
  } catch (err) {
    console.error("Error creating speech plan:", err)
    res.status(500).json({ message: "Error creating speech plan" })
  }
})

// Modified Update speech Plan to handle multipart/form-data
router.put("/plan/:planId", (req, res) => {
  const form = new formidable.IncomingForm()
  form.keepExtensions = true
  form.maxFileSize = 50 * 1024 * 1024 // Set max file size to 50MB

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form for speech plan update:", err)
      return res.status(500).json({ message: "Error parsing uploaded data for speech plan." })
    }

    const planId = req.params.planId

    try {
      const existingPlan = await SpeechPlan.findById(planId)
      if (!existingPlan) {
        return res.status(404).json({ message: "speech Plan not found" })
      }

      // Extract fields from formidable
      const patientId = fields.patientId?.[0]
      const quarterOfYear = Number.parseInt(fields.quarterOfYear?.[0], 10)
      const year = Number.parseInt(fields.year?.[0], 10)
      const title = fields.title?.[0] || existingPlan.title

      // Basic validation
      if (!patientId || !quarterOfYear || !year) {
        return res.status(400).json({ message: "Patient ID, quarter, and year are required for update." })
      }
      if (![1, 2, 3, 4].includes(quarterOfYear)) {
        return res.status(400).json({ message: "quarterOfYear must be 1, 2, 3, or 4" })
      }

      let fileName = existingPlan.fileName
      let uniqueFileName = existingPlan.filePath // This is the unique name on disk
      let fullPath = existingPlan.fullPath

      // Check if a new document file is provided
      const file = files.document?.[0]
      if (file) {
        const tempFilePath = file.filepath
        const originalFileName = file.originalFilename
        const newUniqueFileName = `${uuidv4()}${path.extname(originalFileName)}`

        // Determine upload directory based on patient, quarter, and year
        const uploadDir = path.join(__dirname, "../uploads", `Q${quarterOfYear}`, `${year}`, "speech", "patient-plans")

        if (!fs.existsSync(uploadDir)) {
          fs.mkdirSync(uploadDir, { recursive: true })
        }

        const finalFilePath = path.join(uploadDir, newUniqueFileName)
        fs.copyFileSync(tempFilePath, finalFilePath)
        fs.unlinkSync(tempFilePath) // Delete temp file

        // Delete old file from disk if it exists
        const oldFilePathOnDisk = path.join(
          __dirname,
          "../uploads",
          `Q${existingPlan.quarterOfYear}`,
          `${existingPlan.year}`,
          "speech",
          "patient-plans",
          existingPlan.filePath,
        )
        if (fs.existsSync(oldFilePathOnDisk)) {
          fs.unlinkSync(oldFilePathOnDisk)
        }

        fileName = originalFileName
        uniqueFileName = newUniqueFileName
        fullPath = `/uploads/Q${quarterOfYear}/${year}/speech/patient-plans/${newUniqueFileName}`
      }

      // Update SpeechPlan document in DB
      const updatedPlan = await SpeechPlan.findByIdAndUpdate(
        planId,
        {
          patient: patientId,
          title: title,
          fileName: fileName,
          filePath: uniqueFileName, // Store the unique name on disk
          fullPath: fullPath, // Store the full relative path for access
          quarterOfYear: quarterOfYear,
          year: year,
          lastModified: new Date(),
        },
        { new: true }, // Return the updated document
      )

      res.status(200).json({
        message: "speech Plan updated successfully",
        plan: { ...updatedPlan._doc },
      })
    } catch (error) {
      console.error("Error updating speech plan:", error)
      res.status(500).json({ message: "Error updating speech plan", details: error.message })
    }
  })
})

router.post("/upload-plan", (req, res) => {
  const form = new formidable.IncomingForm()
  form.keepExtensions = true
  form.maxFileSize = 10 * 1024 * 1024 // 10MB

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err)
      return res.status(500).json({ message: "Error parsing uploaded file" })
    }

    const patientId = fields.patientId && fields.patientId[0] ? fields.patientId[0] : null
    const quarterOfYear = fields.quarterOfYear && fields.quarterOfYear[0] ? Number(fields.quarterOfYear[0]) : null
    const year = fields.year && fields.year[0] ? Number(fields.year[0]) : null

    if (!patientId || !quarterOfYear || !year) {
      return res.status(400).json({ message: "Patient ID, quarter, and year are required." })
    }

    if (quarterOfYear < 1 || quarterOfYear > 4) {
      return res.status(400).json({ message: "Quarter of year must be between 1 and 4" })
    }

    // Check for duplicate plan
    const existingPlan = await SpeechPlan.findOne({ patient: patientId, quarterOfYear, year })
    if (existingPlan) {
      return res.status(400).json({
        message: "A plan already exists for this patient for the specified quarter and year.",
      })
    }

    try {
      const file = files.document[0]
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" })
      }

      const tempFilePath = file.filepath
      const originalFileName = file.originalFilename
      const uniqueFileName = `${uuidv4()}${path.extname(originalFileName)}`

      // Create organized directory structure like doctor system
      const uploadDir = path.join(__dirname, "../uploads", `Q${quarterOfYear}`, `${year}`, "speech", "patient-plans")

      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true })
      }

      const finalFilePath = path.join(uploadDir, uniqueFileName)
      fs.copyFileSync(tempFilePath, finalFilePath)
      fs.unlinkSync(tempFilePath)

      const newPlan = await SpeechPlan.create({
        patient: patientId,
        fileName: originalFileName,
        filePath: uniqueFileName,
        fullPath: `/uploads/Q${quarterOfYear}/${year}/speech/patient-plans/${uniqueFileName}`,
        title: originalFileName.replace(/\.[^/.]+$/, ""),
        quarterOfYear,
        year,
      })

      res.status(200).json({
        message: "File uploaded and saved successfully",
        plan: { ...newPlan._doc },
      })
    } catch (error) {
      console.error("Error saving speech plan:", error)
      res.status(500).json({ message: "Error saving file" })
    }
  })
})

// Get speech Exam for a patient (latest or specific quarter/year)
router.get("/exam/:patientId", async (req, res) => {
  const { patientId } = req.params
  const { year, quarter } = req.query // Optional query parameters for historical exams

  try {
    let exam
    if (year && quarter) {
      exam = await SpeechExam.findOne({ patient: patientId, year: Number(year), quarterOfYear: Number(quarter) })
    } else {
      // Fetch the latest exam by default
      exam = await SpeechExam.findOne({ patient: patientId }).sort({ year: -1, quarterOfYear: -1, lastModified: -1 })
    }

    if (!exam) {
      return res.status(404).json({ message: "No exam found for this patient for the specified quarter/year." })
    }
    res.status(200).json(exam)
  } catch (err) {
    console.error("Error fetching speech exam:", err)
    res.status(500).json({ message: "Error fetching speech exam" })
  }
})

// Get all speech Exams for a patient
router.get("/exams/:patientId", async (req, res) => {
  const { patientId } = req.params
  try {
    const exams = await SpeechExam.find({ patient: patientId }).sort({ year: -1, quarterOfYear: -1, lastModified: -1 })
    res.status(200).json(exams)
  } catch (err) {
    console.error("Error fetching all speech exams:", err)
    res.status(500).json({ message: "Error fetching all speech exams" })
  }
})

// Create speech Exam (now creates a new historical entry)
router.post("/exam", async (req, res) => {
  const { patient, title, content, createdBy, quarterOfYear, year } = req.body

  try {
    // Check for duplicate exam for the same patient, quarter, and year
    const existingExam = await SpeechExam.findOne({ patient, quarterOfYear, year })
    if (existingExam) {
      return res
        .status(400)
        .json({ message: "An exam already exists for this patient for the specified quarter and year." })
    }

    const exam = new SpeechExam({
      patient,
      title,
      content,
      createdBy: createdBy || "System",
      lastModified: new Date(),
      quarterOfYear,
      year,
    })

    await exam.save()

    res.status(201).json(exam)
  } catch (err) {
    console.error("Error creating speech Exam:", err)
    res.status(500).json({ message: "Error creating speech Exam" })
  }
})

// Modified Update speech Exam to handle multipart/form-data, mirroring speech Plan update
router.put("/exam/:examId", (req, res) => {
  const form = new formidable.IncomingForm()
  form.keepExtensions = true
  form.maxFileSize = 50 * 1024 * 1024 // Set max file size to 50MB

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form for speech exam update:", err)
      return res.status(500).json({ message: "Error parsing uploaded data for speech exam." })
    }

    const examId = req.params.examId

    try {
      const existingExam = await SpeechExam.findById(examId)
      if (!existingExam) {
        return res.status(404).json({ message: "speech Exam not found" })
      }

      // Extract fields from formidable, using existing values as fallback
      const patientId = fields.patientId?.[0] || existingExam.patient.toString()
      const quarterOfYear = Number.parseInt(fields.quarterOfYear?.[0], 10) || existingExam.quarterOfYear
      const year = Number.parseInt(fields.year?.[0], 10) || existingExam.year
      const title = fields.title?.[0] || existingExam.title
      const content = fields.content?.[0] || existingExam.content // Allow updating SFDT content directly

      // Basic validation for quarterOfYear
      if (![1, 2, 3, 4].includes(quarterOfYear)) {
        return res.status(400).json({ message: "quarterOfYear must be 1, 2, 3, or 4" })
      }

      let fileName = existingExam.fileName
      let uniqueFileName = existingExam.filePath // This is the unique name on disk
      let fullPath = existingExam.fullPath

      // Check if a new document file is provided
      const file = files.document?.[0]
      if (file) {
        const tempFilePath = file.filepath
        const originalFileName = file.originalFilename
        const newUniqueFileName = `${uuidv4()}${path.extname(originalFileName)}`

        // Determine upload directory for exams (consistent with upload-exam route)
        // CORRECTED PATH HERE
        const uploadDir = path.join(__dirname, "../uploads", `Q${quarterOfYear}`, `${year}`, "speech", "patient-exams")

        if (!fs.existsSync(uploadDir)) {
          fs.mkdirSync(uploadDir, { recursive: true })
        }

        const finalFilePath = path.join(uploadDir, newUniqueFileName)
        fs.copyFileSync(tempFilePath, finalFilePath)
        fs.unlinkSync(tempFilePath) // Delete temp file

        // Delete old file from disk if it exists
        // CORRECTED OLD FILE PATH HERE
        const oldFilePathOnDisk = path.join(
          __dirname,
          "../uploads",
          `Q${existingExam.quarterOfYear}`,
          `${existingExam.year}`,
          "speech",
          "patient-exams",
          existingExam.filePath,
        )
        if (existingExam.filePath && fs.existsSync(oldFilePathOnDisk)) {
          fs.unlinkSync(oldFilePathOnDisk)
          console.log(`Deleted associated exam file: ${oldFilePathOnDisk}`)
        } else {
          console.warn(`File not found for deletion (exam ID: ${examId}): ${oldFilePathOnDisk}`)
        }

        fileName = originalFileName
        uniqueFileName = newUniqueFileName
        // CORRECTED FULL PATH HERE
        fullPath = `/uploads/Q${quarterOfYear}/${year}/speech/patient-exams/${newUniqueFileName}`
      }

      // Check for unique constraint violation if patient, quarter, or year are changed
      if (
        (quarterOfYear !== existingExam.quarterOfYear ||
          year !== existingExam.year ||
          patientId !== existingExam.patient.toString()) &&
        (await SpeechExam.findOne({ patient: patientId, quarterOfYear, year, _id: { $ne: examId } }))
      ) {
        return res.status(400).json({
          message: "An exam already exists for this patient for the specified quarter and year.",
        })
      }

      // Update SpeechExam document in DB
      const updatedExam = await SpeechExam.findByIdAndUpdate(
        examId,
        {
          patient: patientId,
          title: title,
          content: content, // Update content field
          fileName: fileName,
          filePath: uniqueFileName, // Store the unique name on disk
          fullPath: fullPath, // Store the full relative path for access
          quarterOfYear: quarterOfYear,
          year: year,
          lastModified: new Date(),
        },
        { new: true }, // Return the updated document
      )

      res.status(200).json({
        message: "speech Exam updated successfully",
        exam: { ...updatedExam._doc },
      })
    } catch (error) {
      console.error("Error updating speech exam:", error)
      res.status(500).json({ message: "Error updating speech exam", details: error.message })
    }
  })
})

router.post("/upload-exam", (req, res) => {
  const form = new formidable.IncomingForm()
  form.keepExtensions = true
  form.maxFileSize = 10 * 1024 * 1024 // 10MB

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err)
      return res.status(500).json({ message: "Error parsing uploaded file" })
    }

    const patientId = fields.patientId && fields.patientId[0] ? fields.patientId[0] : null
    const quarterOfYear = fields.quarterOfYear && fields.quarterOfYear[0] ? Number(fields.quarterOfYear[0]) : null
    const year = fields.year && fields.year[0] ? Number(fields.year[0]) : null

    if (!patientId || !quarterOfYear || !year) {
      console.log("Missing required fields for exam upload: patientId, quarterOfYear, or year.")
      return res.status(400).json({ message: "Patient ID, quarter, and year are required." })
    }

    if (quarterOfYear < 1 || quarterOfYear > 4) {
      return res.status(400).json({ message: "Quarter of year must be between 1 and 4" })
    }

    // Check for duplicate exam for the same patient, quarter, and year
    const existingExam = await SpeechExam.findOne({ patient: patientId, quarterOfYear, year })
    if (existingExam) {
      return res.status(400).json({
        message:
          "An exam already exists for this patient for the specified quarter and year. Please edit the existing exam or choose a different quarter/year.",
      })
    }

    const file = files.document[0]
    if (!file) {
      return res.status(400).json({ message: "No file uploaded" })
    }

    const tempFilePath = file.filepath
    const originalFileName = file.originalFilename

    const uniqueFileName = `${uuidv4()}${path.extname(originalFileName)}`
    // CORRECTED PATH HERE
    const uploadDir = path.join(__dirname, "../uploads", `Q${quarterOfYear}`, `${year}`, "speech", "patient-exams")
    if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

    const finalFilePath = path.join(uploadDir, uniqueFileName)

    // Use copyFileSync and unlinkSync instead of renameSync for cross-device compatibility
    fs.copyFileSync(tempFilePath, finalFilePath)
    fs.unlinkSync(tempFilePath) // Delete the temporary file

    try {
      const exam = new SpeechExam({
        patient: patientId,
        filePath: uniqueFileName,
        fileName: originalFileName,
        title: originalFileName.replace(/\.[^/.]+$/, ""),
        quarterOfYear,
        year,
        lastModified: new Date(),
        // CORRECTED FULL PATH HERE
        fullPath: `/uploads/Q${quarterOfYear}/${year}/speech/patient-exams/${uniqueFileName}`,
      })

      await exam.save()

      console.log("Uploaded Exam Record:", exam)

      res.status(200).json({
        title: originalFileName.replace(/\.[^/.]+$/, ""),
        fileName: originalFileName,
        filePath: uniqueFileName,
        quarterOfYear,
        year,
        message: "Exam document uploaded and linked successfully!",
      })
    } catch (error) {
      console.error("Error linking document to exam:", error)
      res.status(500).json({ message: "Error linking document to exam" })
    }
  })
})

router.post("/close-and-generate-next-plan", async (req, res) => {
  const { patientId, quarterToClose, yearToClose } = req.body

  if (!patientId || !quarterToClose || !yearToClose) {
    return res.status(400).json({ message: "Missing required fields for closing quarter" })
  }

  try {
    const { quarter: nextQuarter, year: nextYear } = getNextQuarterAndYear(quarterToClose, yearToClose)

    // Mark current quarter as closed
    await SpeechPlan.updateOne(
      { patient: patientId, quarterOfYear: quarterToClose, year: yearToClose },
      { isClosed: true }
    )

    // Check if a plan already exists for the next quarter
    const existingNextPlan = await SpeechPlan.findOne({
      patient: patientId,
      quarterOfYear: nextQuarter,
      year: nextYear,
    })

    if (existingNextPlan) {
      return res.status(409).json({
        message: `A plan already exists for Q${nextQuarter}/${nextYear}. No new plan generated.`,
        plan: existingNextPlan,
      })
    }

    // Get template
    const templateFileName = "speech-Plantemplate-patient.docx"
    const templatePath = path.join(__dirname, "../uploads/templates", templateFileName)

    if (!fs.existsSync(templatePath)) {
      return res.status(404).json({
        message: "Default template for speech department not found. Please upload one.",
      })
    }

    // Generate unique filename for the new plan
    const uniqueFileName = `${uuidv4()}.docx`
    const uploadDir = path.join(__dirname, "../uploads", `Q${nextQuarter}`, `${nextYear}`, "speech", "patient-plans")

    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true })
    }

    const finalFilePath = path.join(uploadDir, uniqueFileName)
    fs.copyFileSync(templatePath, finalFilePath)

    // Create new SpeechPlan entry
    const newPlan = await SpeechPlan.create({
      patient: patientId,
      title: `speech Plan Q${nextQuarter} ${nextYear}`,
      fileName: `Default Plan for Q${nextQuarter} ${nextYear}`,
      filePath: uniqueFileName,
      fullPath: `/uploads/Q${nextQuarter}/${nextYear}/speech/patient-plans/${uniqueFileName}`,
      quarterOfYear: nextQuarter,
      year: nextYear,
      isClosed: false, // New plan is open by default
    })

    res.status(200).json({
      message: `Quarter ${quarterToClose}/${yearToClose} closed. New plan for Q${nextQuarter}/${nextYear} generated from template.`,
      plan: { ...newPlan._doc },
    })
  } catch (error) {
    console.error("Error closing quarter and generating next plan:", error)
    res.status(500).json({ message: "Error processing quarter closure and plan generation" })
  }
})

router.post("/close-and-generate-next-exam", async (req, res) => {
  const { patientId, quarterToClose, yearToClose } = req.body

  if (!patientId || !quarterToClose || !yearToClose) {
    return res.status(400).json({ message: "Missing required fields for closing quarter" })
  }

  try {
    const { quarter: nextQuarter, year: nextYear } = getNextQuarterAndYear(quarterToClose, yearToClose)

    // Mark current quarter as closed
    await SpeechExam.updateOne(
      { patient: patientId, quarterOfYear: quarterToClose, year: yearToClose },
      { isClosed: true }
    )

    // Check if a exam already exists for the next quarter
    const existingNextExam = await SpeechExam.findOne({
      patient: patientId,
      quarterOfYear: nextQuarter,
      year: nextYear,
    })

    if (existingNextExam) {
      return res.status(409).json({
        message: `A exam already exists for Q${nextQuarter}/${nextYear}. No new exam generated.`,
        exam: existingNextExam,
      })
    }

    // Get template
    const templateFileName = "speech-Examtemplate-patient.docx"
    const templatePath = path.join(__dirname, "../uploads/templates", templateFileName)

    if (!fs.existsSync(templatePath)) {
      return res.status(404).json({
        message: "Default template for speech department not found. Please upload one.",
      })
    }

    // Generate unique filename for the new Exam
    const uniqueFileName = `${uuidv4()}.docx`
    const uploadDir = path.join(__dirname, "../uploads", `Q${nextQuarter}`, `${nextYear}`, "speech", "patient-exams")

    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true })
    }

    const finalFilePath = path.join(uploadDir, uniqueFileName)
    fs.copyFileSync(templatePath, finalFilePath)

    // Create new SpeechExam entry
    const newExam = await SpeechExam.create({
      patient: patientId,
      title: `speech Exam Q${nextQuarter} ${nextYear}`,
      fileName: `Default Exam for Q${nextQuarter} ${nextYear}`,
      filePath: uniqueFileName,
      fullPath: `/uploads/Q${nextQuarter}/${nextYear}/speech/patient-exams/${uniqueFileName}`,
      quarterOfYear: nextQuarter,
      year: nextYear,
      isClosed: false, // New exam is open by default
    })

    res.status(200).json({
      message: `Quarter ${quarterToClose}/${yearToClose} closed. New exam for Q${nextQuarter}/${nextYear} generated from template.`,
      exam: { ...newExam._doc },
    })
  } catch (error) {
    console.error("Error closing quarter and generating next exam:", error)
    res.status(500).json({ message: "Error processing quarter closure and exam generation" })
  }
})

router.get("/view-plans/:patientId", async (req, res) => {
  const { patientId } = req.params
  const { last, quarter, year, startDate, endDate } = req.query

  try {
    if (!patientId) {
      return res.status(400).json({ message: "Missing required patient ID" })
    }

    // Get all closed quarters plus the latest open quarter
    const closedPlans = await SpeechPlan.find({ patient: patientId, isClosed: true })
      .sort({ year: -1, quarterOfYear: -1 })

    const latestOpenPlan = await SpeechPlan.findOne({ patient: patientId, isClosed: false })
      .sort({ year: -1, quarterOfYear: -1 })

    // Combine results
    let visiblePlans = closedPlans
    if (latestOpenPlan) {
      visiblePlans.unshift(latestOpenPlan)
    }

    // Apply optional filters
    if (quarter || year) {
      visiblePlans = visiblePlans.filter(plan => {
        if (quarter && plan.quarterOfYear !== Number.parseInt(quarter)) return false
        if (year && plan.year !== Number.parseInt(year)) return false
        return true
      })
    }

    if (startDate && endDate) {
      const start = new Date(startDate)
      const end = new Date(endDate)
      visiblePlans = visiblePlans.filter(plan =>
        (plan.createdAt >= start && plan.createdAt <= end) ||
        (plan.lastModified >= start && plan.lastModified <= end)
      )
    }

    res.status(200).json({
      message: "speech plans retrieved successfully",
      plans: last === "true" ? visiblePlans[0] || null : visiblePlans,
    })
  } catch (error) {
    console.error("Error retrieving speech plans:", error)
    res.status(500).json({ message: "Error retrieving speech plans" })
  }
})

router.get("/view-exams/:patientId", async (req, res) => {
  const { patientId } = req.params
  const { last, quarter, year, startDate, endDate } = req.query

  try {
    if (!patientId) {
      return res.status(400).json({ message: "Missing required patient ID" })
    }

    // Get all closed quarters plus the latest open quarter
    const closedExams = await SpeechExam.find({ patient: patientId, isClosed: true })
      .sort({ year: -1, quarterOfYear: -1 })

    const latestOpenExam = await SpeechExam.findOne({ patient: patientId, isClosed: false })
      .sort({ year: -1, quarterOfYear: -1 })

    // Combine results
    let visibleExams = closedExams
    if (latestOpenExam) {
      visibleExams.unshift(latestOpenExam)
    }

    // Apply optional filters
    if (quarter || year) {
      visibleExams = visibleExams.filter(exam => {
        if (quarter && exam.quarterOfYear !== Number.parseInt(quarter)) return false
        if (year && exam.year !== Number.parseInt(year)) return false
        return true
      })
    }

    if (startDate && endDate) {
      const start = new Date(startDate)
      const end = new Date(endDate)
      visibleExams = visibleExams.filter(exam =>
        (exam.createdAt >= start && exam.createdAt <= end) ||
        (exam.lastModified >= start && exam.lastModified <= end)
      )
    }

    res.status(200).json({
      message: "speech exams retrieved successfully",
      exams: last === "true" ? visibleExams[0] || null : visibleExams,
    })
  } catch (error) {
    console.error("Error retrieving speech exams:", error)
    res.status(500).json({ message: "Error retrieving speech exams" })
  }
})

router.delete("/delete-exam/:id", async (req, res) => {
  try {
    const { id } = req.params
    const deletedExam = await SpeechExam.findByIdAndDelete(id)

    if (!deletedExam) {
      return res.status(404).json({ message: "speech Exam not found." })
    }

    // Delete the associated file from the file system
    if (deletedExam.fullPath) {
      const filePathOnDisk = path.join(__dirname, "..", deletedExam.fullPath)
      if (fs.existsSync(filePathOnDisk)) {
        fs.unlinkSync(filePathOnDisk)
        console.log(`Deleted associated exam file: ${filePathOnDisk}`)
      } else {
        console.warn(`File not found for deletion (exam ID: ${id}): ${filePathOnDisk}`)
      }
    }

    res.status(200).json({ message: "speech Exam and associated file deleted successfully!" })
  } catch (error) {
    console.error("Error deleting speech exam and file:", error)
    res.status(500).json({ message: "Server error during exam deletion." })
  }
})

router.delete("/delete-plan/:id", async (req, res) => {
  try {
    const { id } = req.params
    const deletedPlan = await SpeechPlan.findByIdAndDelete(id)

    if (!deletedPlan) {
      return res.status(404).json({ message: "speech Plan not found." })
    }

    // Delete the associated file from the file system
    if (deletedPlan.fullPath) {
      const filePathOnDisk = path.join(__dirname, "..", deletedPlan.fullPath)
      if (fs.existsSync(filePathOnDisk)) {
        fs.unlinkSync(filePathOnDisk)
        console.log(`Deleted associated plan file: ${filePathOnDisk}`)
      } else {
        console.warn(`File not found for deletion (plan ID: ${id}): ${filePathOnDisk}`)
      }
    }

    res.status(200).json({ message: "speech Plan and associated file deleted successfully!" })
  } catch (error) {
    console.error("Error deleting speech plan and file:", error)
    res.status(500).json({ message: "Server error during plan deletion." })
  }
})

// Get speech Plans for a patient (latest or specific quarter/year)
router.get("/get-plans/:patientId", async (req, res) => {
  const { patientId } = req.params
  const { last, quarter, year } = req.query

  try {
    if (!patientId) {
      return res.status(400).json({ message: "Missing required patient ID" })
    }

    const query = { patient: patientId }

    // Add quarter and year filters if provided
    if (quarter) query.quarterOfYear = Number.parseInt(quarter)
    if (year) query.year = Number.parseInt(year)

    let plans
    if (last === "true") {
      // Return only the latest plan
      plans = await SpeechPlan.findOne(query).sort({ createdAt: -1 })
    } else {
      // Return all plans matching the query
      plans = await SpeechPlan.find(query).sort({ year: -1, quarterOfYear: -1, createdAt: -1 })
    }

    res.status(200).json({
      message: "speech plans retrieved successfully",
      plans,
    })
  } catch (error) {
    res.status(500).json({ message: "Error retrieving speech plans" })
  }
})

// Get speech Exams for a patient (latest or specific quarter/year)
router.get("/get-exams/:patientId", async (req, res) => {
  const { patientId } = req.params
  const { last, quarter, year } = req.query

  try {
    if (!patientId) {
      return res.status(400).json({ message: "Missing required patient ID" })
    }

    const query = { patient: patientId }

    // Add quarter and year filters if provided
    if (quarter) query.quarterOfYear = Number.parseInt(quarter)
    if (year) query.year = Number.parseInt(year)

    let exams
    if (last === "true") {
      // Return only the latest exam
      exams = await SpeechExam.findOne(query).sort({ createdAt: -1 })
    } else {
      // Return all exams matching the query
      exams = await SpeechExam.find(query).sort({ year: -1, quarterOfYear: -1, createdAt: -1 })
    }

    res.status(200).json({
      message: "speech exams retrieved successfully",
      exams,
    })
  } catch (error) {
    res.status(500).json({ message: "Error retrieving speech exams" })
  }
})

module.exports = router
