const express = require("express")
const router = express.Router()
const FullProgram = require("../models/FullProgram")
const SingleProgram = require("../models/SingleProgram")
const SchoolProgram = require("../models/SchoolProgram")

// Helper function to normalize date for comparison
const normalizeDate = (dateString) => {
  const date = new Date(dateString)
  // Set to start of day in local timezone
  date.setHours(0, 0, 0, 0)
  return date
}

// Helper function to format date for database query
const getDateRange = (dateString) => {
  // Parse the date string as UTC to ensure consistent date range calculation
  // This creates a Date object representing midnight UTC of the given date.
  const inputDate = new Date(dateString)

  const startOfDay = new Date(inputDate) // Already UTC midnight
  const endOfDay = new Date(inputDate)
  endOfDay.setUTCHours(23, 59, 59, 999) // Set to end of day in UTC

  console.log("Date range calculation (UTC):", {
    inputDate: dateString,
    startOfDay: startOfDay.toISOString(),
    endOfDay: endOfDay.toISOString(),
  })

  return { startOfDay, endOfDay }
}

// Get booked time slots for a specific date and program type
router.get("/booked-slots/:programType/:date", async (req, res) => {
  try {
    const { programType, date } = req.params

    console.log("=== BOOKED SLOTS REQUEST ===")
    console.log("Program Type:", programType)
    console.log("Date:", date)

    const { startOfDay, endOfDay } = getDateRange(date)

    let bookedSlots = []
    let Model

    // Select the appropriate model based on program type
    switch (programType) {
      case "full_package_evaluation":
      case "full_program":
        Model = FullProgram
        break
      case "single_session":
        Model = SingleProgram
        break
      case "school_evaluation":
        Model = SchoolProgram
        break
      default:
        return res.status(400).json({
          message: "Invalid program type",
          validTypes: ["full_package_evaluation", "single_session", "school_evaluation"],
        })
    }

    console.log("Using model:", Model.modelName)
    console.log("Query date range:", { startOfDay, endOfDay })
    console.log("Executing find query for booked slots:", {
      date: { $gte: startOfDay, $lte: endOfDay },
      status: { $ne: "cancelled" },
    })

    // Query for appointments on the target date
    const appointments = await Model.find({
      date: {
        $gte: startOfDay,
        $lte: endOfDay,
      },
      // Only consider active appointments (not cancelled)
      status: { $ne: "cancelled" },
    }).select("time date status patientid description")

    console.log("Found appointments:", appointments.length)
    appointments.forEach((apt, index) => {
      console.log(`Appointment ${index + 1}:`, {
        id: apt._id,
        date: apt.date,
        time: apt.time,
        status: apt.status,
        patientid: apt.patientid,
      })
    })

    // Extract time slots
    bookedSlots = appointments.map((appointment) => ({
      time: appointment.time,
      date: appointment.date,
      status: appointment.status,
      id: appointment._id,
    }))

    console.log("Booked slots result:", bookedSlots)

    res.status(200).json({
      success: true,
      date: date,
      programType: programType,
      bookedSlots: bookedSlots,
      totalBooked: bookedSlots.length,
    })
  } catch (error) {
    console.error("Error fetching booked slots:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching booked slots",
      error: error.message,
    })
  }
})

// Get all booked slots for a program type within a date range
router.get("/booked-slots-range/:programType", async (req, res) => {
  try {
    const { programType } = req.params
    const { startDate, endDate } = req.query

    if (!startDate || !endDate) {
      return res.status(400).json({
        message: "startDate and endDate query parameters are required",
      })
    }

    const start = new Date(startDate)
    const end = new Date(endDate)

    let Model

    // Select the appropriate model based on program type
    switch (programType) {
      case "full_package_evaluation":
      case "full_program":
        Model = FullProgram
        break
      case "single_session":
        Model = SingleProgram
        break
      case "school_evaluation":
        Model = SchoolProgram
        break
      default:
        return res.status(400).json({
          message: "Invalid program type",
          validTypes: ["full_package_evaluation", "single_session", "school_evaluation"],
        })
    }

    // Query for appointments in the date range
    const appointments = await Model.find({
      date: {
        $gte: start,
        $lte: end,
      },
      // Only consider active appointments (not cancelled)
      status: { $ne: "cancelled" },
    })
      .select("time date status")
      .sort({ date: 1, time: 1 })

    // Group by date for easier frontend processing
    const bookedSlotsByDate = {}
    appointments.forEach((appointment) => {
      const dateKey = appointment.date.toISOString().split("T")[0]
      if (!bookedSlotsByDate[dateKey]) {
        bookedSlotsByDate[dateKey] = []
      }
      bookedSlotsByDate[dateKey].push({
        time: appointment.time,
        status: appointment.status,
      })
    })

    res.status(200).json({
      success: true,
      programType: programType,
      dateRange: { startDate, endDate },
      bookedSlotsByDate: bookedSlotsByDate,
      totalAppointments: appointments.length,
    })
  } catch (error) {
    console.error("Error fetching booked slots range:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching booked slots range",
      error: error.message,
    })
  }
})

// Check if a specific time slot is available
router.post("/check-availability", async (req, res) => {
  try {
    const { programType, date, time } = req.body

    console.log("=== CHECK AVAILABILITY REQUEST ===")
    console.log("Program Type:", programType)
    console.log("Date:", date)
    console.log("Time:", time)

    if (!programType || !date || !time) {
      return res.status(400).json({
        message: "programType, date, and time are required",
      })
    }

    const { startOfDay, endOfDay } = getDateRange(date)

    let Model

    // Select the appropriate model based on program type
    switch (programType) {
      case "full_package_evaluation":
      case "full_program":
        Model = FullProgram
        break
      case "single_session":
        Model = SingleProgram
        break
      case "school_evaluation":
        Model = SchoolProgram
        break
      default:
        return res.status(400).json({
          message: "Invalid program type",
        })
    }

    console.log("Using model:", Model.modelName)
    console.log("Query:", {
      date: { $gte: startOfDay, $lte: endOfDay },
      time: time,
      status: { $ne: "cancelled" },
    })

    // Check if the time slot is already booked
    const existingAppointment = await Model.findOne({
      date: {
        $gte: startOfDay,
        $lte: endOfDay,
      },
      time: time,
      status: { $ne: "cancelled" },
    })

    console.log(
      "Existing appointment found:",
      existingAppointment
        ? {
            id: existingAppointment._id,
            date: existingAppointment.date,
            time: existingAppointment.time,
            status: existingAppointment.status,
          }
        : "None",
    )

    const isAvailable = !existingAppointment

    res.status(200).json({
      success: true,
      available: isAvailable,
      programType: programType,
      date: date,
      time: time,
      conflictingAppointment: existingAppointment
        ? {
            id: existingAppointment._id,
            status: existingAppointment.status,
            date: existingAppointment.date,
            time: existingAppointment.time,
          }
        : null,
    })
  } catch (error) {
    console.error("Error checking availability:", error)
    res.status(500).json({
      success: false,
      message: "Error checking availability",
      error: error.message,
    })
  }
})

// Double-check availability before booking (used by frontend before payment)
router.post("/verify-booking-availability", async (req, res) => {
  try {
    const { programType, date, time, excludeId } = req.body

    console.log("=== VERIFY BOOKING AVAILABILITY ===")
    console.log("Program Type:", programType)
    console.log("Date:", date)
    console.log("Time:", time)
    console.log("Exclude ID:", excludeId)

    if (!programType || !date || !time) {
      return res.status(400).json({
        message: "programType, date, and time are required",
      })
    }

    const { startOfDay, endOfDay } = getDateRange(date)

    let Model

    // Select the appropriate model based on program type
    switch (programType) {
      case "full_package_evaluation":
      case "full_program":
        Model = FullProgram
        break
      case "single_session":
        Model = SingleProgram
        break
      case "school_evaluation":
        Model = SchoolProgram
        break
      default:
        return res.status(400).json({
          message: "Invalid program type",
        })
    }

    // Build query to check for conflicts
    const query = {
      date: {
        $gte: startOfDay,
        $lte: endOfDay,
      },
      time: time,
      status: { $ne: "cancelled" },
    }

    // Exclude a specific ID if provided (useful for updates)
    if (excludeId) {
      query._id = { $ne: excludeId }
    }

    console.log("Verification query:", query)

    // Check if the time slot is already booked
    const existingAppointment = await Model.findOne(query)

    console.log(
      "Conflicting appointment:",
      existingAppointment
        ? {
            id: existingAppointment._id,
            date: existingAppointment.date,
            time: existingAppointment.time,
            status: existingAppointment.status,
            patientid: existingAppointment.patientid,
          }
        : "None found",
    )

    const isAvailable = !existingAppointment

    if (!isAvailable) {
      console.log("❌ BOOKING VERIFICATION FAILED - slot already booked")
    } else {
      console.log("✅ BOOKING VERIFICATION PASSED - slot is available")
    }

    res.status(200).json({
      success: true,
      available: isAvailable,
      programType: programType,
      date: date,
      time: time,
      conflictingAppointment: existingAppointment
        ? {
            id: existingAppointment._id,
            status: existingAppointment.status,
            patientId: existingAppointment.patientid || existingAppointment.patientId,
            description: existingAppointment.description,
            date: existingAppointment.date,
            time: existingAppointment.time,
          }
        : null,
    })
  } catch (error) {
    console.error("Error verifying booking availability:", error)
    res.status(500).json({
      success: false,
      message: "Error verifying booking availability",
      error: error.message,
    })
  }
})

module.exports = router
