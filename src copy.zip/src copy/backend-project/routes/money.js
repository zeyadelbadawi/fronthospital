// routes/money.js
const express = require("express")
const router = express.Router()
const Money = require("../models/Money")

// POST route to create a new money record
router.post("/", async (req, res) => {
  try {
    const { patientId, programId, price, status, invoiceId, programType, comment } = req.body

    // Validate required fields
    if (!patientId || !programId || !price || !invoiceId || !programType || !comment) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields",
      })
    }

    // Create new money record
    const newMoneyRecord = new Money({
      patientId,
      programId,
      price,
      status: status || "completed",
      invoiceId,
      programType,
      comment,
    })

    // Save to database
    const savedRecord = await newMoneyRecord.save()

    res.status(201).json({
      success: true,
      message: "Payment record created successfully",
      data: savedRecord,
    })
  } catch (error) {
    console.error("Error creating money record:", error)

    // Handle duplicate invoice ID error
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: "Invoice ID already exists",
      })
    }

    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    })
  }
})

// GET route to fetch money records by patient ID
router.get("/patient/:patientId", async (req, res) => {
  try {
    const { patientId } = req.params

    const moneyRecords = await Money.find({ patientId })
      .populate("patientId", "name email phone")
      .sort({ createdAt: -1 })

    res.status(200).json({
      success: true,
      data: moneyRecords,
    })
  } catch (error) {
    console.error("Error fetching money records:", error)
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    })
  }
})

// GET route to fetch all money records
router.get("/", async (req, res) => {
  try {
    const moneyRecords = await Money.find().populate("patientId", "name email phone").sort({ createdAt: -1 })

    res.status(200).json({
      success: true,
      data: moneyRecords,
    })
  } catch (error) {
    console.error("Error fetching money records:", error)
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    })
  }
})

module.exports = router
