// Import required modules
const express = require("express");

// Create a router
const router = express.Router();

const authentication = require("./authentication");
const physicalTherapy = require("./physicalTherapy");
const DrastHala = require("./DrastHala");
const school = require("./school");
const aba = require("./aba");
const OccupationalTherapy = require("./OccupationalTherapy");
const SpecialEducation = require("./SpecialEducation");
const speech = require("./speech");
const full = require("./full");
const appointmentRouter = require("./appointment-route");
const studentsAppointmentDepartmentRouter = require("./studentsAppointmentDepartment-route");
const moneyRoutes = require("./money")
const Checks = require("./checks")
const abaS = require("./abaS");
const OccupationalTherapyS = require("./OccupationalTherapyS");
const SpecialEducationS = require("./SpecialEducationS");
const speechS = require("./speechS");
const physicalTherapyS = require("./physicalTherapyS");
const schoolhandling = require("./schoolhandling");
const appointmentManagement = require("./appointmentManagement");
const emailRouter = require("./email-route");
const notificationRouter = require("./notification-router");
const departments = require("./departments");
const DoctorStudentAssignment = require("./doctor-student-assignment");
const doctorFileRouter = require("./doctor-file-route");
const manualSubscriptionChecker = require('./manualSubscriptionChecker');
const single = require('./single');
const availability = require('./availability');







router.use("/authentication", authentication);
router.use("/physicalTherapy", physicalTherapy);
router.use("/DrastHala", DrastHala);
router.use("/school", school);
router.use("/aba", aba);
router.use("/OccupationalTherapy", OccupationalTherapy);
router.use("/SpecialEducation", SpecialEducation);
router.use("/speech", speech);
router.use("/full", full);
router.use("/appointments", appointmentRouter);
router.use("/students-appointment", studentsAppointmentDepartmentRouter);
router.use("/money", moneyRoutes);
router.use("/checks", Checks);
router.use("/schoolhandling", schoolhandling);
router.use("/physicalTherapyS", physicalTherapyS);
router.use("/abaS", abaS);
router.use("/OccupationalTherapyS", OccupationalTherapyS);
router.use("/SpecialEducationS", SpecialEducationS);
router.use("/speechS", speechS);
router.use("/appointmentManagement", appointmentManagement);
router.use("/email", emailRouter);
router.use("/notification", notificationRouter);
router.use("/departments", departments);
router.use("/doctor-student-assignment", DoctorStudentAssignment);
router.use("/doctorFile", doctorFileRouter);
router.use("/single", single);

router.use('/manualSubscriptionChecker', manualSubscriptionChecker );
router.use('/availability', availability );




// Export the router
module.exports = function (app) {
  app.use("/", router);
};
