const express = require("express")
const { v4: uuidv4 } = require("uuid") // For generating unique file names
const router = express.Router() // For creating tokens
const formidable = require("formidable")
const fs = require("fs")
const path = require("path")
const { param } = require("express-validator")
const { validationResult } = require("express-validator")
const SchoolPlan = require("../models/School/schoolPlan")
const PatientSchoolAssignment = require("../models/School/patientSchoolAssignment")
const SchoolProgram = require("../models/SchoolProgram")
const Patient = require("../models/users/Patient")

// Helper function to generate program name (reused from optimized endpoint in schoolhandling.js)
// MOVED TO TOP TO ENSURE IT'S DEFINED BEFORE USE
function generateOptimizedProgramName(program, allPrograms, patientName) {
  if (!program.patientid) {
    return "School Evaluation Program"
  }

  // Get all programs for this specific patient from the already loaded data
  const patientPrograms = allPrograms.filter((p) => p.patientid?.toString() === program.patientid?.toString())

  // Sort by creation date (earliest first)
  const sortedPatientPrograms = patientPrograms.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))

  // Find the index of current program in the sorted list
  const programIndex = sortedPatientPrograms.findIndex((p) => p.unicValue === program.unicValue)
  const programNumber = programIndex >= 0 ? programIndex + 1 : 1

  // Get the year from creation date
  const year = new Date(program.createdAt).getFullYear()

  return `School Evaluation ${programNumber} (${year})`
}

// Get all school programs GROUPED BY UNIQUE VALUES - UPDATED TO SHOW EACH PROGRAM ONCE
router.get("/school-programs", async (req, res) => {
  const { page = 1, limit = 10, search = "", status = "all" } = req.query

  try {
    const matchQuery = {}

    // Search functionality
    if (search) {
      matchQuery.$or = [
        { description: { $regex: search, $options: "i" } },
        { unicValue: { $regex: search, $options: "i" } },
      ]
    }

    // Status filter
    if (status !== "all") {
      matchQuery.status = status
    }

    // Aggregate to group by patientid + unicValue combination
    const aggregationPipeline = [
      { $match: matchQuery },
      {
        $group: {
          _id: {
            patientid: "$patientid",
            unicValue: "$unicValue",
          },
          firstProgram: { $first: "$$ROOT" },
          totalSessions: { $sum: 1 },
          allDates: { $push: "$date" },
          allTimes: { $push: "$time" },
          latestStatus: { $last: "$status" },
        },
      },
      {
        $project: {
          _id: "$firstProgram._id",
          patientid: "$firstProgram.patientid",
          unicValue: "$firstProgram.unicValue",
          description: "$firstProgram.description",
          date: "$firstProgram.date",
          time: "$firstProgram.time",
          status: "$latestStatus",
          totalSessions: "$totalSessions",
          allDates: "$allDates",
          allTimes: "$allTimes",
          createdAt: "$firstProgram.createdAt",
        },
      },
      { $sort: { createdAt: -1 } },
      { $skip: (Number.parseInt(page) - 1) * Number.parseInt(limit) },
      { $limit: Number.parseInt(limit) },
    ]

    const programs = await SchoolProgram.aggregate(aggregationPipeline)

    // Get total count for pagination
    const countPipeline = [
      { $match: matchQuery },
      {
        $group: {
          _id: {
            patientid: "$patientid",
            unicValue: "$unicValue",
          },
        },
      },
      { $count: "total" },
    ]

    const countResult = await SchoolProgram.aggregate(countPipeline)
    const totalPrograms = countResult.length > 0 ? countResult[0].total : 0

    // Populate patient information for each program
    const programsWithPatientInfo = await Promise.all(
      programs.map(async (program) => {
        let patientInfo = null
        if (program.patientid) {
          try {
            patientInfo = await Patient.findById(program.patientid).select("name email phone _id")
          } catch (error) {
            console.error(`Error fetching patient ${program.patientid}:`, error)
          }
        }

        console.log(`[v0] Checking plan for patient: ${program.patientid}, unicValue: ${program.unicValue}`)

        let planExists = false
        if (program.patientid && program.unicValue) {
          try {
            const decodedUnicValue = decodeURIComponent(program.unicValue)
            console.log(`[v0] Decoded unicValue: ${decodedUnicValue}`)

            const existingPlan = await SchoolPlan.findOne({
              patient: program.patientid,
              unicValue: decodedUnicValue,
            })
            planExists = !!existingPlan
            console.log(`[v0] Plan check result: ${planExists}, Plan ID: ${existingPlan?._id || "none"}`)
          } catch (error) {
            console.error(`Error checking plan existence:`, error)
          }
        }

        return {
          ...program,
          patientName: patientInfo?.name || "Unknown Patient",
          patientEmail: patientInfo?.email || null,
          patientPhone: patientInfo?.phone || null,
          patientId: program.patientid || null,
          planExists,
          sessionInfo: `${program.totalSessions} session${program.totalSessions > 1 ? "s" : ""}`,
          dateRange:
            program.allDates.length > 1
              ? `${new Date(Math.min(...program.allDates.map((d) => new Date(d)))).toLocaleDateString()} - ${new Date(Math.max(...program.allDates.map((d) => new Date(d)))).toLocaleDateString()}`
              : new Date(program.date).toLocaleDateString(),
        }
      }),
    )

    res.status(200).json({
      programs: programsWithPatientInfo,
      totalPages: Math.ceil(totalPrograms / Number.parseInt(limit)),
      currentPage: Number.parseInt(page),
      totalPrograms,
    })
  } catch (error) {
    console.error("Error fetching school programs:", error)
    res.status(500).json({
      message: "Error fetching school programs",
      error: error.message,
    })
  }
})

// Create/Update school Plan for specific program - UPDATED FOR UNIQUE PROGRAMS
router.post("/plan", async (req, res) => {
  try {
    const { patient, unicValue, title, filePath, fileName, programDescription, planContent } = req.body

    console.log("Saving plan with data:", { patient, unicValue, title, fileName })

    if (!patient || !unicValue) {
      return res.status(400).json({
        message: "Patient ID and unicValue are required",
      })
    }

    const decodedUnicValue = decodeURIComponent(unicValue)

    // Check if plan already exists
    const existingPlan = await SchoolPlan.findOne({
      patient: patient,
      unicValue: decodedUnicValue,
    })

    if (existingPlan) {
      // Update existing plan
      existingPlan.title = title || existingPlan.title
      existingPlan.filePath = filePath || existingPlan.filePath
      existingPlan.fileName = fileName || existingPlan.fileName
      existingPlan.programDescription = programDescription || existingPlan.programDescription
      existingPlan.planContent = planContent || existingPlan.planContent
      existingPlan.lastModified = new Date()
      existingPlan.updatedAt = new Date()

      const savedPlan = await existingPlan.save()
      console.log("Plan updated successfully:", savedPlan._id)

      res.json({
        message: "Plan updated successfully",
        plan: savedPlan,
        fullPath: savedPlan.filePath ? `/uploads/school-plan/plan/${savedPlan.filePath}` : null,
      })
    } else {
      // Create new plan
      const newPlan = new SchoolPlan({
        patient: patient,
        unicValue: decodedUnicValue,
        title: title || "School Program Plan",
        filePath: filePath || "",
        fileName: fileName || "",
        programDescription: programDescription || "",
        planContent: planContent || "",
        status: "draft",
      })

      const savedPlan = await newPlan.save()
      console.log("New plan created successfully:", savedPlan._id)

      res.json({
        message: "Plan created successfully",
        plan: savedPlan,
        fullPath: savedPlan.filePath ? `/uploads/school-plan/plan/${savedPlan.filePath}` : null,
      })
    }
  } catch (error) {
    console.error("Error saving plan:", error)
    res.status(500).json({
      message: "Error saving plan",
      error: error.message,
    })
  }
})

// Get school Plan for a patient and specific program - UPDATED FOR UNIQUE PROGRAMS
router.get("/plan/:patientId/:unicValue", async (req, res) => {
  try {
    const { patientId, unicValue } = req.params
    const decodedUnicValue = decodeURIComponent(unicValue)

    console.log("Fetching plan for:", { patientId, unicValue: decodedUnicValue })

    const plan = await SchoolPlan.findOne({
      patient: patientId,
      unicValue: decodedUnicValue,
    }).populate("patient", "name email")

    if (!plan) {
      console.log("No plan found, returning default structure")
      return res.json({
        title: "School Program Plan",
        filePath: "",
        fileName: "",
        programDescription: "",
        planContent: "",
        patient: patientId,
        unicValue: decodedUnicValue,
      })
    }

    console.log("Plan found:", plan)
    res.json(plan)
  } catch (error) {
    console.error("Error fetching plan:", error)
    res.status(500).json({
      message: "Error fetching plan",
      error: error.message,
    })
  }
})

// Upload school Plan for specific program - FIXED FOR SYNCFUSION SAVE
router.post("/upload-plan/:patientId/:unicValue", (req, res) => {
  const { patientId, unicValue } = req.params

  console.log("Upload plan endpoint called with:", { patientId, unicValue })

  const form = new formidable.IncomingForm()
  form.uploadDir = path.join(__dirname, "../uploads/school-plan/plan")
  form.keepExtensions = true
  form.maxFileSize = 10 * 1024 * 1024 // 10MB limit

  // Ensure upload directory exists
  if (!fs.existsSync(form.uploadDir)) {
    fs.mkdirSync(form.uploadDir, { recursive: true })
  }

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err)
      return res.status(500).json({ message: "Error parsing form data", error: err.message })
    }

    console.log("Form parsed successfully")
    console.log("Fields:", fields)
    console.log("Files keys:", Object.keys(files))

    // Try to get the document file from different possible field names
    const file = files.document || files.file || files.planFile || Object.values(files)[0]

    if (!file) {
      console.error("No file found in upload")
      return res.status(400).json({ message: "No document uploaded" })
    }

    // Handle both single file and array of files
    const fileObj = Array.isArray(file) ? file[0] : file

    console.log("File object structure:", {
      filepath: fileObj.filepath,
      newFilename: fileObj.newFilename,
      originalFilename: fileObj.originalFilename,
      mimetype: fileObj.mimetype,
      size: fileObj.size,
    })

    // Check if file has valid path
    if (!fileObj.filepath && !fileObj.newFilename) {
      console.error("File object missing filepath")
      return res.status(400).json({ message: "Invalid file upload" })
    }

    try {
      const decodedUnicValue = decodeURIComponent(unicValue)

      // Generate unique filename
      const originalName = fileObj.originalFilename || fileObj.name || "school-plan.docx"
      const fileExtension = path.extname(originalName) || ".docx"
      const uniqueFilename = `school-plan-${patientId}-${Date.now()}${fileExtension}`
      const newPath = path.join(form.uploadDir, uniqueFilename)

      // Get the source file path
      const sourcePath = fileObj.filepath || fileObj.newFilename

      console.log("Moving file from:", sourcePath, "to:", newPath)

      // Check if source file exists
      if (!fs.existsSync(sourcePath)) {
        console.error("Source file does not exist:", sourcePath)
        return res.status(400).json({ message: "Source file not found" })
      }

      // Move file to new location
      fs.renameSync(sourcePath, newPath)
      console.log("File moved successfully to:", newPath)

      // Check if plan already exists for this patient + unicValue combination
      let plan = await SchoolPlan.findOne({
        patient: patientId,
        unicValue: decodedUnicValue,
      })

      if (plan) {
        if (plan.filePath) {
          const oldFilePath = path.join(form.uploadDir, plan.filePath)
          if (fs.existsSync(oldFilePath)) {
            fs.unlinkSync(oldFilePath)
            console.log("[v0] OLD FILE DELETED - Path:", oldFilePath, "- Filename:", plan.filePath)
          } else {
            console.log("[v0] OLD FILE NOT FOUND - Path:", oldFilePath)
          }
        }

        // Update existing plan
        plan.fileName = originalName
        plan.filePath = uniqueFilename
        plan.title = fields.title || plan.title || "School Program Plan"
        plan.lastModified = new Date()
        plan.updatedAt = new Date()
        await plan.save()
        console.log("[v0] PLAN UPDATED - Plan ID:", plan._id, "- New File:", uniqueFilename)
      } else {
        // Get program description from SchoolProgram
        let programDescription = ""
        try {
          const program = await SchoolProgram.findOne({
            patientid: patientId,
            unicValue: decodedUnicValue,
          })
          programDescription = program?.description || ""
        } catch (error) {
          console.error("Error fetching program description:", error)
        }

        // Create new plan
        plan = new SchoolPlan({
          patient: patientId,
          unicValue: decodedUnicValue,
          fileName: originalName,
          filePath: uniqueFilename,
          title: fields.title || "School Program Plan",
          programDescription: programDescription,
          lastModified: new Date(),
        })
        await plan.save()
        console.log("[v0] NEW PLAN CREATED - Plan ID:", plan._id, "- File:", uniqueFilename)
      }

      res.status(200).json({
        message: "School plan saved successfully",
        plan,
        fullPath: `/uploads/school-plan/plan/${uniqueFilename}`,
      })
    } catch (error) {
      console.error("Error saving school plan:", error)
      res.status(500).json({
        message: "Error saving school plan",
        error: error.message,
      })
    }
  })
})

// Save document content for specific program - UPDATED FOR SYNCFUSION SAVE
router.post("/save-plan/:patientId/:unicValue", (req, res) => {
  const { patientId, unicValue } = req.params

  const form = new formidable.IncomingForm()
  form.uploadDir = path.join(__dirname, "../uploads/school-plan/plan")
  form.keepExtensions = true
  form.maxFileSize = 10 * 1024 * 1024 // 10MB limit

  // Ensure upload directory exists
  if (!fs.existsSync(form.uploadDir)) {
    fs.mkdirSync(form.uploadDir, { recursive: true })
  }

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err)
      return res.status(500).json({ message: "Error parsing form data" })
    }

    const file = files.document
    if (!file) {
      return res.status(400).json({ message: "No document uploaded" })
    }

    try {
      const decodedUnicValue = decodeURIComponent(unicValue)

      // Generate unique filename
      const fileExtension = path.extname(file.originalFilename || file.name || ".docx")
      const uniqueFilename = `school-plan-${patientId}-${Date.now()}${fileExtension}`
      const newPath = path.join(form.uploadDir, uniqueFilename)

      // Move file to new location
      fs.renameSync(file.filepath, newPath)

      // Check if plan already exists for this patient + unicValue combination
      let plan = await SchoolPlan.findOne({
        patient: patientId,
        unicValue: decodedUnicValue,
      })

      if (plan) {
        // Delete old file if it exists
        if (plan.filePath && fs.existsSync(path.join(form.uploadDir, plan.filePath))) {
          fs.unlinkSync(path.join(form.uploadDir, plan.filePath))
        }

        // Update existing plan
        plan.fileName = file.originalFilename || file.name || "school-plan.docx"
        plan.filePath = uniqueFilename
        plan.title = fields.title || plan.title || "School Program Plan"
        plan.lastModified = new Date()
        await plan.save()
      } else {
        // Get program description from SchoolProgram
        let programDescription = ""
        try {
          const program = await SchoolProgram.findOne({
            patientid: patientId,
            unicValue: decodedUnicValue,
          })
          programDescription = program?.description || ""
        } catch (error) {
          console.error("Error fetching program description:", error)
        }

        // Create new plan
        plan = new SchoolPlan({
          patient: patientId,
          unicValue: decodedUnicValue,
          fileName: file.originalFilename || file.name || "school-plan.docx",
          filePath: uniqueFilename,
          title: fields.title || "School Program Plan",
          programDescription: programDescription,
          lastModified: new Date(),
        })
        await plan.save()
      }

      res.status(200).json({
        message: "School plan saved successfully",
        plan,
        fullPath: `/uploads/school-plan/plan/${uniqueFilename}`,
      })
    } catch (error) {
      console.error("Error saving school plan:", error)
      res.status(500).json({
        message: "Error saving school plan",
        error: error.message,
      })
    }
  })
})

// Get all school plans with pagination and search - UPDATED TO SHOW PROGRAM INFO
router.get("/all-plans", async (req, res) => {
  const { page = 1, limit = 10, search = "", status = "all" } = req.query

  try {
    const query = {}

    // Search functionality
    if (search) {
      const patients = await Patient.find({
        name: { $regex: search, $options: "i" },
      }).select("_id")

      if (patients.length > 0) {
        query.$or = [
          { patient: { $in: patients.map((p) => p._id) } },
          { title: { $regex: search, $options: "i" } },
          { fileName: { $regex: search, $options: "i" } },
          { unicValue: { $regex: search, $options: "i" } },
        ]
      } else {
        query.$or = [
          { title: { $regex: search, $options: "i" } },
          { fileName: { $regex: search, $options: "i" } },
          { unicValue: { $regex: search, $options: "i" } },
        ]
      }
    }

    // Status filter
    if (status === "recent") {
      const oneWeekAgo = new Date()
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7)
      query.lastModified = { $gte: oneWeekAgo }
    } else if (status === "older") {
      const oneWeekAgo = new Date()
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7)
      query.lastModified = { $lt: oneWeekAgo }
    }

    const plans = await SchoolPlan.find(query)
      .populate({
        path: "patient",
        select: "name email phone dateOfBirth address",
        model: "Patient",
      })
      .skip((Number.parseInt(page) - 1) * Number.parseInt(limit))
      .limit(Number.parseInt(limit))
      .sort({ lastModified: -1, createdAt: -1 })

    const totalPlans = await SchoolPlan.countDocuments(query)

    res.status(200).json({
      plans,
      totalPages: Math.ceil(totalPlans / Number.parseInt(limit)),
      currentPage: Number.parseInt(page),
      totalPlans,
    })
  } catch (error) {
    console.error("Error fetching all school plans:", error)
    res.status(500).json({
      message: "Error fetching school plans",
      error: error.message,
    })
  }
})

// Complete patient school assignment
router.patch(
  "/complete-assignment/:patientId",
  [param("patientId").isMongoId().withMessage("Valid patient ID required")],
  async (req, res) => {
    const { patientId } = req.params

    try {
      const assignment = await PatientSchoolAssignment.findOneAndUpdate(
        { patient: patientId },
        {
          appointmentsCompleted: true,
          status: "completed",
          completedAt: new Date(),
          updatedAt: new Date(),
        },
        { new: true },
      ).populate({
        path: "patient",
        select: "name email phone",
        model: "Patient",
      })

      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" })
      }

      res.status(200).json({
        message: "Assignment completed successfully",
        assignment,
      })
    } catch (error) {
      console.error("Error completing assignment:", error)
      res.status(500).json({ message: "Error completing assignment", error: error.message })
    }
  },
)

// Add school Assignment
router.post("/assign-to-school", async (req, res) => {
  const { patientId, notes } = req.body

  if (!patientId) {
    return res.status(400).json({ message: "Invalid or missing patient ID" })
  }

  try {
    const patient = await Patient.findById(patientId)
    if (!patient) {
      return res.status(404).json({ message: "Patient not found" })
    }

    // Ensure the patient is not already assigned to school
    const existingAssignment = await PatientSchoolAssignment.findOne({
      patient: patientId,
    })
    if (existingAssignment) {
      return res.status(400).json({ message: "Patient already assigned to school" })
    }

    const assignment = new PatientSchoolAssignment({
      patient: patientId,
      notes: notes || "",
      status: "active",
    })

    await assignment.save()

    res.status(201).json({ message: "Patient assigned to school successfully", assignment })
  } catch (err) {
    res.status(500).json({ message: "Error assigning patient to school", error: err.message })
  }
})

// Get school Assignments
router.get("/school-assignments", async (req, res) => {
  const { page = 1, limit = 10, search = "" } = req.query

  try {
    const query = {}
    if (search) {
      const patients = await Patient.find({
        name: { $regex: search, $options: "i" },
      }).select("_id")

      if (patients.length > 0) {
        query.patient = { $in: patients.map((p) => p._id) }
      } else {
        return res.status(200).json({
          assignments: [],
          totalPages: 0,
          currentPage: Number.parseInt(page),
          totalAssignments: 0,
        })
      }
    }

    const assignments = await PatientSchoolAssignment.find(query)
      .populate({
        path: "patient",
        select: "name email phone",
        model: "Patient",
      })
      .skip((Number.parseInt(page) - 1) * Number.parseInt(limit))
      .limit(Number.parseInt(limit))
      .sort({ assignedDate: -1 })

    const totalAssignments = await PatientSchoolAssignment.countDocuments(query)

    res.status(200).json({
      assignments,
      totalPages: Math.ceil(totalAssignments / Number.parseInt(limit)),
      currentPage: Number.parseInt(page),
      totalAssignments,
    })
  } catch (err) {
    res.status(500).json({ message: "Error fetching school assignments" })
  }
})

// Unassign from school
router.delete("/unassign-from-school/:patientId", async (req, res) => {
  const { patientId } = req.params

  try {
    const assignment = await PatientSchoolAssignment.findOneAndDelete({ patient: patientId })

    if (!assignment) {
      return res.status(404).json({ message: "Assignment not found" })
    }

    res.status(200).json({ message: "Patient unassigned from school" })
  } catch (err) {
    res.status(500).json({ message: "Error unassigning patient" })
  }
})

// Delete school Plan for specific program - UPDATED FOR UNIQUE PROGRAMS
router.delete("/plan/:patientId/:unicValue", async (req, res) => {
  try {
    const { patientId, unicValue } = req.params
    const decodedUnicValue = decodeURIComponent(unicValue)

    const deletedPlan = await SchoolPlan.findOneAndDelete({
      patient: patientId,
      unicValue: decodedUnicValue,
    })

    if (!deletedPlan) {
      return res.status(404).json({ message: "Plan not found" })
    }

    // Delete associated file if exists
    if (deletedPlan.filePath) {
      const filePath = path.join(__dirname, "../uploads/school-plan/plan", deletedPlan.filePath)
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath)
      }
    }

    res.json({ message: "Plan deleted successfully" })
  } catch (error) {
    console.error("Error deleting plan:", error)
    res.status(500).json({
      message: "Error deleting plan",
      error: error.message,
    })
  }
})

// Get program info for specific patient and unicValue - NEW ENDPOINT
router.get("/program-info/:patientId/:unicValue", async (req, res) => {
  try {
    const { patientId, unicValue } = req.params
    const decodedUnicValue = decodeURIComponent(unicValue)

    console.log(`[Backend Log] Fetching program info for Patient ID: ${patientId}, UnicValue: ${decodedUnicValue}`)

    // 1. Get all programs for this patient to determine the sequential program name
    const patientPrograms = await SchoolProgram.find({ patientid: patientId })
      .sort({ createdAt: 1 }) // Sort by creation date to determine order
      .lean()

    console.log(`[Backend Log] Found ${patientPrograms.length} programs for patient ${patientId}.`)

    const programIndex = patientPrograms.findIndex((p) => p.unicValue === decodedUnicValue)
    const programEntry = programIndex >= 0 ? patientPrograms[programIndex] : null

    if (!programEntry) {
      console.log(`[Backend Log] Program entry not found for unicValue: ${decodedUnicValue}`)
      return res.status(404).json({ message: "Program not found" })
    }

    console.log(`[Backend Log] Found program entry: ${JSON.stringify(programEntry._id)}`)

    const programName = generateOptimizedProgramName(programEntry, patientPrograms, null) // patientName is not needed here for generation
    console.log(`[Backend Log] Generated program name: ${programName}`)

    // 2. Get all appointments for this unicValue and sort to find the latest date/time
    const appointmentsForUnicValue = await SchoolProgram.find({ unicValue: decodedUnicValue })
      .sort({ date: -1, time: -1 }) // Sort by date descending, then time descending
      .lean()

    console.log(
      `[Backend Log] Found ${appointmentsForUnicValue.length} appointments for unicValue: ${decodedUnicValue}`,
    )

    let latestAppointmentDate = null
    let latestAppointmentTime = null
    if (appointmentsForUnicValue.length > 0) {
      latestAppointmentDate = appointmentsForUnicValue[0].date
      latestAppointmentTime = appointmentsForUnicValue[0].time
      console.log(`[Backend Log] Latest appointment: Date=${latestAppointmentDate}, Time=${latestAppointmentTime}`)
    } else {
      console.log(`[Backend Log] No appointments found for unicValue: ${decodedUnicValue}`)
    }

    // 3. Get the patient details
    const patient = await Patient.findById(patientId).select("name email phone").lean()
    console.log(`[Backend Log] Found patient details: ${patient?.name || "N/A"}`)

    res.status(200).json({
      program: {
        ...programEntry, // Include existing program details
        programName: programName, // The calculated sequential name
        latestAppointmentDate: latestAppointmentDate, // The latest date
        latestAppointmentTime: latestAppointmentTime, // The latest time
      },
      patientName: patient?.name || "Unknown Patient",
      patientEmail: patient?.email || "",
      patientPhone: patient?.phone || "",
    })
  } catch (error) {
    console.error("[Backend Error] Error fetching program info:", error)
    res.status(500).json({ message: "Error fetching program info", error: error.message })
  }
})

router.patch("/lock-plan/:patientId/:unicValue", async (req, res) => {
  try {
    const { patientId, unicValue } = req.params
    const decodedUnicValue = decodeURIComponent(unicValue)

    console.log("[v0] Locking plan for:", { patientId, unicValue: decodedUnicValue })

    const plan = await SchoolPlan.findOne({
      patient: patientId,
      unicValue: decodedUnicValue,
    })

    if (!plan) {
      return res.status(404).json({ message: "Plan not found" })
    }

    plan.isLocked = true
    plan.lockedAt = new Date()
    await plan.save()

    console.log("[v0] Plan locked successfully:", plan._id)

    const allAppointments = await SchoolProgram.find({ unicValue: decodedUnicValue })
    const allCompleted = allAppointments.length > 0 && allAppointments.every((apt) => apt.status === "completed")

    console.log("[v0] Checking appointments - Total:", allAppointments.length, "All Completed:", allCompleted)

    if (allCompleted && allAppointments.length > 0) {
      try {
        const Notification = require("../models/notifications")
        const Patient = require("../models/users/Patient")

        // Get patient details
        const patient = await Patient.findById(patientId).select("name email")
        console.log("[v0] Patient found:", patient?.name)

        // Get program info for notification
        const latestAppointment = allAppointments.sort((a, b) => new Date(b.date) - new Date(a.date))[0]
        const programName = `School Evaluation - ${new Date(latestAppointment.date).getFullYear()}`

        console.log("[v0] Creating notification with data:", {
          patientId,
          programName,
          studentName: patient?.name,
        })

        // Create notification in both English and Arabic
        const notificationData = {
          receiverId: patientId,
          rule: "Patient", // Notification for patient/student role
          isRead: false,
          title: "School Evaluation Sheet Ready",
          titleAr: "ورقة التقييم المدرسي جاهزة",
          message: `Your school evaluation sheet is now ready and you can view it in your profile. Program: ${programName}`,
          messageAr: `ورقة التقييم المدرسي الخاصة بك جاهزة الآن ويمكنك عرضها في ملفك الشخصي. البرنامج: ${programName}`,
          type: "school_evaluation_ready",
          relatedData: {
            patientId,
            unicValue: decodedUnicValue,
            programName,
            studentName: patient?.name || "Student",
            appointmentDate: latestAppointment.date,
            appointmentTime: latestAppointment.time,
          },
          createdAt: new Date(),
        }

        const notification = new Notification(notificationData)
        const savedNotification = await notification.save()

        console.log("[v0] Notification created successfully:", savedNotification._id)
      } catch (notificationError) {
        console.error("[v0] Error creating notification:", notificationError.message)
        // Don't fail the lock operation if notification fails
      }
    } else {
      console.log(
        "[v0] Notification NOT sent - Conditions not met. Sheet locked but appointments not all completed or no appointments found",
      )
    }

    res.status(200).json({
      message: "Plan marked as done and locked successfully",
      plan,
      notificationSent: allCompleted && allAppointments.length > 0,
    })
  } catch (error) {
    console.error("Error locking plan:", error)
    res.status(500).json({
      message: "Error locking plan",
      error: error.message,
    })
  }
})

module.exports = router
