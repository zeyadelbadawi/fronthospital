const express = require("express")
const router = express.Router()
const DoctorStudentAssignment = require("../models/DoctorStudentAssignment")
const Patient = require("../models/users/Patient")
const ABAPlan = require("../models/ABA/ABAPlan")
const ABAExam = require("../models/ABA/ABAExam")
const SpeechPlan = require("../models/Speech/SpeechPlan")
const SpeechExam = require("../models/Speech/SpeechExam")
const OccupationalTherapyPlan = require("../models/Occupational-therapy/OccupationalTherapyPlan")
const OccupationalTherapyExam = require("../models/Occupational-therapy/OccupationalTherapyExam")
const SpecialEducationPlan = require("../models/Special-Education/SpecialEducationPlan")
const SpecialEducationExam = require("../models/Special-Education/SpecialEducationExam")
const PhysicalTherapyPlan = require("../models/physicalTherapy/PhysicalTherapyPlan")
const PhysicalTherapyExam = require("../models/physicalTherapy/PhysicalTherapyExam")
const PsychotherapyPlan = require("../models/psychotherapy/PsychotherapyPlan")

// GET /api/doctor-student-plans/:doctorId
// Returns all students' plans and exams for a specific doctor, organized by department, year, quarter, and student
router.get("/:doctorId", async (req, res) => {
  try {
    const { doctorId } = req.params

    // Get all assignments for this doctor (including historical ones)
    const assignments = await DoctorStudentAssignment.find({
      doctor: doctorId,
    })
      .populate("patient", "name email")
      .lean()

    if (!assignments || assignments.length === 0) {
      return res.json({ success: true, data: {} })
    }

    // Organize by department
    const departmentData = {}

    // Department model mappings
    const departmentModels = {
      ABA: { Plan: ABAPlan, Exam: ABAExam },
      speech: { Plan: SpeechPlan, Exam: SpeechExam },
      OccupationalTherapy: {
        Plan: OccupationalTherapyPlan,
        Exam: OccupationalTherapyExam,
      },
      SpecialEducation: {
        Plan: SpecialEducationPlan,
        Exam: SpecialEducationExam,
      },
      physicalTherapy: {
        Plan: PhysicalTherapyPlan,
        Exam: PhysicalTherapyExam,
      },
        psychotherapy: {
            Plan: PsychotherapyPlan,
            Exam: null, // Psychotherapy has no exams
        },
    }

    const convertToUrlPath = (filePath) => {
      if (!filePath) return null


      // If already starts with /uploads/, return as is
      if (filePath.startsWith("/uploads/")) {
        return filePath
      }

      // Find the uploads directory in the path
      const uploadsIndex = filePath.indexOf("/uploads/")
      if (uploadsIndex !== -1) {
        const result = filePath.substring(uploadsIndex)
        return result
      }

      // If it's just a filename, we need to determine the correct subdirectory
      // For now, return as is and let it fail so we can see what's happening
      return filePath
    }

    // Process each assignment
    for (const assignment of assignments) {
      const { department, patient, assignedDate, status } = assignment

      if (!patient) continue // Skip if patient not found

      // Get the models for this department
      const models = departmentModels[department]
      if (!models) continue

      // Find all plans and exams for this patient that were created during this doctor's assignment
      const [plans, exams] = await Promise.all([
        models.Plan.find({
          patient: patient._id,
          createdAt: { $gte: assignedDate },
        }).lean(),
        models.Exam.find({
          patient: patient._id,
          createdAt: { $gte: assignedDate },
        }).lean(),
      ])

      // If there are no plans or exams, skip this assignment
      if (plans.length === 0 && exams.length === 0) continue

      // Initialize department if not exists
      if (!departmentData[department]) {
        departmentData[department] = {}
      }

      // Organize plans and exams by year and quarter
      const organizePlansExams = (items, type) => {
        items.forEach((item) => {
          const year = item.year
          const quarter = `Q${item.quarterOfYear}`
          const studentName = patient.name

          // Initialize year if not exists
          if (!departmentData[department][year]) {
            departmentData[department][year] = {}
          }

          // Initialize quarter if not exists
          if (!departmentData[department][year][quarter]) {
            departmentData[department][year][quarter] = {}
          }

          // Initialize student if not exists
          if (!departmentData[department][year][quarter][studentName]) {
            departmentData[department][year][quarter][studentName] = {
              patientId: patient._id,
              patientEmail: patient.email,
              plan: null,
              exam: null,
            }
          }

          // Add plan or exam
          if (type === "plan") {
            departmentData[department][year][quarter][studentName].plan = {
              _id: item._id,
              title: item.title,
              fileName: item.fileName,
              filePath: convertToUrlPath(item.filePath),
              fullPath: convertToUrlPath(item.fullPath),
              createdAt: item.createdAt,
              isClosed: item.isClosed,
            }
          } else {
            departmentData[department][year][quarter][studentName].exam = {
              _id: item._id,
              title: item.title,
              fileName: item.fileName,
              filePath: convertToUrlPath(item.filePath),
              fullPath: convertToUrlPath(item.fullPath),
              createdAt: item.createdAt,
              isClosed: item.isClosed,
            }
          }
        })
      }

      organizePlansExams(plans, "plan")
      organizePlansExams(exams, "exam")
    }

    res.json({ success: true, data: departmentData })
  } catch (error) {
    console.error("Error fetching doctor student plans:", error)
    res.status(500).json({ success: false, message: "Server error", error: error.message })
  }
})

module.exports = router
