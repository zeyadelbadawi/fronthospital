const express = require("express")
const router = express.Router()
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")
const Patient = require("../models/users/Patient")
const Admin = require("../models/users/Admin")
const Accountant = require("../models/users/Accountant")
const HeadDoctor = require("../models/users/HeadDoctor")
const Department = require("../models/department")
const Doctor = require("../models/users/Doctor")
const cookieParser = require("cookie-parser")
const authenticateUser = require("../authMiddleware")
const FullProgram = require("../models/FullProgram")
const SingleProgram = require("../models/SingleProgram")
const SchoolProgram = require("../models/SchoolProgram")
const Money = require("../models/Money")
const Checks = require("../models/Checks")
const { v4: uuidv4 } = require("uuid")
const AssignmentService = require("../services/assignmentService")
const DrastHalaPlan = require("../models/drasthala/DrastHalaPlans")
const mongoose = require("mongoose")
const { calculateAcademicYearEndDate } = require("../utils/academicYearHelper")
const multer = require("multer")
const fs = require("fs")
const path = require("path")
const LoginAttempt = require("../models/LoginAttempt")
const PasswordReset = require("../models/PasswordReset")
const { strictLoginLimiter, loginLimiter, passwordResetLimiter } = require("../middleware/rateLimiter")
const crypto = require("crypto")
const nodemailer = require("nodemailer")
const { isValidEmail, sanitizeInput } = require("../utils/securityHelpers")
const Notification = require("../models/notifications")

router.use(cookieParser())

const bankTransferStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, "../uploads/bank-transfers")
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true })
    }
    cb(null, uploadDir)
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9)
    const ext = path.extname(file.originalname)
    cb(null, `bank-transfer-${uniqueSuffix}${ext}`)
  },
})

const bankTransferUpload = multer({
  storage: bankTransferStorage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    // Only allow image files
    const allowedTypes = /jpeg|jpg|png/
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase())
    const mimetype = allowedTypes.test(file.mimetype)

    if (mimetype && extname) {
      return cb(null, true)
    } else {
      cb(new Error("Only PNG, JPG, and JPEG images are allowed"))
    }
  },
})

const transporter = nodemailer.createTransport({
  host: process.env.NODE_MAILER_HOST,
  port: process.env.NODE_MAILER_PORT,
  secure: true,
  auth: {
    user: process.env.NODE_MAILER_USER,
    pass: process.env.NODE_MAILER_PASS,
  },
})

// Helper function to normalize date for comparison
const normalizeDate = (dateString) => {
  const date = new Date(dateString)
  // Set to start of day in local timezone
  date.setHours(0, 0, 0, 0)
  return date
}

// Helper function to format date for database query
const getDateRange = (dateString) => {
  const inputDate = new Date(dateString)
  const startOfDay = new Date(inputDate.getFullYear(), inputDate.getMonth(), inputDate.getDate(), 0, 0, 0, 0)
  const endOfDay = new Date(inputDate.getFullYear(), inputDate.getMonth(), inputDate.getDate(), 23, 59, 59, 999)

  return { startOfDay, endOfDay }
}

// Register patient
router.post("/signup/patient", async (req, res) => {
  const { name, email, phone, dateOfBirth, address, password, gender } = req.body

  try {
    const hashedPassword = await bcrypt.hash(password, 10)
    const newPatient = new Patient({
      name,
      email,
      phone,
      dateOfBirth,
      address,
      password: hashedPassword,
    })
    await newPatient.save()
    res.status(201).json({ message: "Patient registered successfully" })
  } catch (err) {
    console.error("Error during patient registration:", err)
    res.status(500).json({ message: "Error registering patient" })
  }
})

router.post("/check-email", async (req, res) => {
  try {
    const { email } = req.body

    if (!email) {
      return res.status(400).json({ message: "Email is required" })
    }

    const existingPatient = await Patient.findOne({ email: email.toLowerCase() })

    res.json({ available: !existingPatient })
  } catch (err) {
    console.error("Error checking email:", err)
    res.status(500).json({ message: "Error checking email availability" })
  }
})

router.post("/check-phone", async (req, res) => {
  try {
    const { phone } = req.body

    if (!phone) {
      return res.status(400).json({ message: "Phone number is required" })
    }

    const existingPatient = await Patient.findOne({ phone })

    res.json({ available: !existingPatient })
  } catch (err) {
    console.error("Error checking phone:", err)
    res.status(500).json({ message: "Error checking phone availability" })
  }
})

router.post("/check-username", async (req, res) => {
  try {
    const { username } = req.body

    if (!username) {
      return res.status(400).json({ message: "Username is required" })
    }

    // Check if username exists in Patient model (stored in 'name' field)
    const existingPatient = await Patient.findOne({ name: username })

    res.json({ available: !existingPatient })
  } catch (err) {
    console.error("Error checking username:", err)
    res.status(500).json({ message: "Error checking username availability" })
  }
})

// Endpoint to get all patients
// Endpoint to fetch patients with pagination and search
router.get("/patients", async (req, res) => {
  const { page = 1, limit = 10, search = "" } = req.query // Default page=1, limit=10

  try {
    // Search query (to find patients by name, email, or other fields)
    const query = {
      $or: [{ name: { $regex: search, $options: "i" } }, { email: { $regex: search, $options: "i" } }],
    }

    const patients = await Patient.find(query)
      .skip((page - 1) * limit) // Skip patients based on page number
      .limit(limit) // Limit number of results per page

    const totalPatients = await Patient.countDocuments(query) // Get total count for pagination

    res.status(200).json({
      patients: patients.map((patient) => ({
        ...patient.toObject(),
      })),
      totalPages: Math.ceil(totalPatients / limit), // Calculate total pages
      currentPage: page,
      totalPatients,
    })
  } catch (err) {
    res.status(500).json({ message: "Error fetching patients" })
  }
})

// Register Admin
router.post("/signup/admin", async (req, res) => {
  const { username, email, password } = req.body

  try {
    const hashedPassword = await bcrypt.hash(password, 10)
    const newAdmin = new Admin({
      username,
      email,
      password: hashedPassword,
    })

    await newAdmin.save()
    res.status(201).json({ message: "Admin registered successfully" })
  } catch (err) {
    console.error("Error during admin registration:", err)
    res.status(500).json({ message: "Error registering admin" })
  }
})

//all accountant
router.get("/accountants", async (req, res) => {
  const { page = 1, limit = 10, search = "" } = req.query // Default page=1, limit=10

  try {
    // Search query (to find accountants by name, email, or other fields)
    const query = {
      $or: [{ name: { $regex: search, $options: "i" } }, { email: { $regex: search, $options: "i" } }],
    }

    const accountants = await Accountant.find(query)
      .skip((page - 1) * limit) // Skip accountants based on page number
      .limit(limit) // Limit number of results per page

    const totalAccountants = await Accountant.countDocuments(query) // Get total count for pagination

    res.status(200).json({
      accountants: accountants.map((accountant) => ({
        ...accountant.toObject(),
      })),
      totalPages: Math.ceil(totalAccountants / limit), // Calculate total pages
      currentPage: page,
      totalAccountants,
    })
  } catch (err) {
    res.status(500).json({ message: "Error fetching accountants" })
  }
})

// Register accountants
router.post("/signup/accountant", async (req, res) => {
  const { name, email, password } = req.body

  try {
    const hashedPassword = await bcrypt.hash(password, 10)
    const newAccountant = new Accountant({
      name,
      email,
      password: hashedPassword,
    })

    await newAccountant.save()
    res.status(201).json({ message: "Accountant registered successfully" })
  } catch (err) {
    console.error("Error during Accountant registration:", err)
    res.status(500).json({ message: "Error registering Accountant" })
  }
})

// login accountants
router.post("/signin/accountant", async (req, res) => {
  const { email, password } = req.body
  try {
    const accountant = await Accountant.findOne({ email })
    if (!accountant) {
      return res.status(404).json({ message: "Accountant not found" })
    }
    const isMatch = await bcrypt.compare(password, accountant.password)
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" })
    }

    // Create access token
    const accessToken = jwt.sign({ id: accountant._id, role: "accountant" }, "accessTokenSecret", { expiresIn: "1h" })

    // Create refresh token
    const refreshToken = jwt.sign({ id: accountant._id, role: "accountant" }, "refreshTokenSecret", { expiresIn: "7d" })

    // Store refresh token in an HTTP-only cookie
    res.cookie("refreshToken", refreshToken, {
      httpOnly: true, // Only accessible by the web server
      secure: process.env.NODE_ENV === "production", // Only set cookie over HTTPS in production
      sameSite: "Strict", // Strict SameSite policy
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days expiry
    })

    // Send the access token in the response body
    res.json({ accessToken })
  } catch (err) {
    console.error("Error during accountant login:", err)
    res.status(500).json({ message: "Error logging in accountant" })
  }
})

// **Edit Accountant Information**
router.put("/edit-accountant/:id", async (req, res) => {
  const { name, email, password } = req.body
  const accountantId = req.params.id

  try {
    const updatedData = { name, email }

    if (password) {
      updatedData.password = await bcrypt.hash(password, 10) // If password is provided, hash it
    }

    const updatedAccountant = await Accountant.findByIdAndUpdate(accountantId, updatedData, { new: true })

    if (!updatedAccountant) {
      return res.status(404).json({ message: "Accountant not found" })
    }

    res.status(200).json({ message: "Accountant updated successfully", accountant: updatedAccountant })
  } catch (err) {
    res.status(500).json({ message: "Error updating Accountant" })
  }
})

// **Delete Accountant by ID**
router.delete("/delete-accountant/:id", async (req, res) => {
  const accountantId = req.params.id

  try {
    const deletedAccountant = await Accountant.findByIdAndDelete(accountantId)

    if (!deletedAccountant) {
      return res.status(404).json({ message: "Accountant not found" })
    }

    res.status(200).json({ message: "Accountant deleted successfully" })
  } catch (err) {
    res.status(500).json({ message: "Error deleting Accountant" })
  }
})

// **Get Accountant by ID**
router.get("/accountant/:id", async (req, res) => {
  const { id } = req.params // Get the accountant ID from the URL

  try {
    const accountant = await Accountant.findById(id)
    if (!accountant) {
      return res.status(404).json({ message: "Accountant not found" })
    }
    res.status(200).json(accountant) // Return the accountant data
  } catch (err) {
    res.status(500).json({ message: "Error fetching Accountant data" })
  }
})

router.put("/accountant-password/:id", async (req, res) => {
  const { password } = req.body
  const accountantId = req.params.id
  try {
    const updatedAccountant = await Accountant.findById(accountantId)
    updatedAccountant.password = await bcrypt.hash(password, 10)
    await updatedAccountant.save()
    res.status(200).json({ message: "Password updated successfully" })
  } catch (err) {
    res.status(500).json({ message: "Error updating password" })
  }
})

// Admin Login Route
router.post("/signin/admin", strictLoginLimiter, async (req, res) => {
  let { email, password } = req.body

  // Get IP and user agent for logging
  const ipAddress = req.headers["x-forwarded-for"]?.split(",")[0] || req.ip || req.connection.remoteAddress
  const userAgent = req.headers["user-agent"]

  try {
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" })
    }

    email = sanitizeInput(email.toLowerCase())

    if (!isValidEmail(email)) {
      return res.status(400).json({ message: "Invalid email format" })
    }

    const isLocked = await LoginAttempt.shouldLockAccount(email, "admin")
    if (isLocked) {
      await LoginAttempt.create({
        email,
        role: "admin",
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Account locked due to multiple failed attempts",
        blocked: true,
      })

      return res.status(429).json({
        message: "Account temporarily locked due to multiple failed login attempts. Please try again after 15 minutes.",
      })
    }

    const isSuspicious = await LoginAttempt.isSuspiciousIP(ipAddress)
    if (isSuspicious) {
      await LoginAttempt.create({
        email,
        role: "admin",
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Suspicious IP activity detected",
        blocked: true,
      })

      return res.status(429).json({
        message: "Suspicious activity detected. Please try again later.",
      })
    }

    const admin = await Admin.findOne({ email })

    if (!admin) {
      await LoginAttempt.create({
        email,
        role: "admin",
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Invalid credentials",
      })

      return res.status(401).json({ message: "Invalid email or password" })
    }

    const isMatch = await bcrypt.compare(password, admin.password)

    if (!isMatch) {
      await LoginAttempt.create({
        email,
        role: "admin",
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Invalid credentials",
      })

      return res.status(401).json({ message: "Invalid email or password" })
    }

    await LoginAttempt.create({
      email,
      role: "admin",
      ipAddress,
      userAgent,
      success: true,
    })

    // Create access token with environment variable secret
    const accessToken = jwt.sign(
      { id: admin._id, role: "admin" },
      process.env.JWT_ACCESS_SECRET || "accessTokenSecret",
      { expiresIn: "1h" },
    )

    // Create refresh token
    const refreshToken = jwt.sign(
      { id: admin._id, role: "admin" },
      process.env.JWT_REFRESH_SECRET || "refreshTokenSecret",
      { expiresIn: "7d" },
    )

    // Store refresh token in an HTTP-only cookie
    res.cookie("refreshToken", refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "Strict",
      maxAge: 7 * 24 * 60 * 60 * 1000,
    })

    // Send the access token in the response body
    res.json({ accessToken })
  } catch (err) {
    console.error("Error during admin login:", err)
    res.status(500).json({ message: "Error logging in. Please try again later." })
  }
})

// Admin Login Route
router.post("/signin/HeadDoctor", strictLoginLimiter, async (req, res) => {
  let { email, password } = req.body

  const ipAddress = req.headers["x-forwarded-for"]?.split(",")[0] || req.ip || req.connection.remoteAddress
  const userAgent = req.headers["user-agent"]

  try {
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" })
    }

    email = sanitizeInput(email.toLowerCase())

    if (!isValidEmail(email)) {
      return res.status(400).json({ message: "Invalid email format" })
    }

    const isLocked = await LoginAttempt.shouldLockAccount(email, "HeadDoctor")
    if (isLocked) {
      await LoginAttempt.create({
        email,
        role: "HeadDoctor",
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Account locked due to multiple failed attempts",
        blocked: true,
      })

      return res.status(429).json({
        message: "Account temporarily locked due to multiple failed login attempts. Please try again after 15 minutes.",
      })
    }

    const isSuspicious = await LoginAttempt.isSuspiciousIP(ipAddress)
    if (isSuspicious) {
      await LoginAttempt.create({
        email,
        role: "HeadDoctor",
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Suspicious IP activity detected",
        blocked: true,
      })

      return res.status(429).json({
        message: "Suspicious activity detected. Please try again later.",
      })
    }

    const head = await HeadDoctor.findOne({ email })

    if (!head) {
      await LoginAttempt.create({
        email,
        role: "HeadDoctor",
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Invalid credentials",
      })

      return res.status(401).json({ message: "Invalid email or password" })
    }

    const isMatch = await bcrypt.compare(password, head.password)

    if (!isMatch) {
      await LoginAttempt.create({
        email,
        role: "HeadDoctor",
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Invalid credentials",
      })

      return res.status(401).json({ message: "Invalid email or password" })
    }

    await LoginAttempt.create({
      email,
      role: "HeadDoctor",
      ipAddress,
      userAgent,
      success: true,
    })

    const accessToken = jwt.sign(
      { id: head._id, role: "HeadDoctor" },
      process.env.JWT_ACCESS_SECRET || "accessTokenSecret",
      { expiresIn: "1h" },
    )

    const refreshToken = jwt.sign(
      { id: head._id, role: "HeadDoctor" },
      process.env.JWT_REFRESH_SECRET || "refreshTokenSecret",
      { expiresIn: "7d" },
    )

    res.cookie("refreshToken", refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "Strict",
      maxAge: 7 * 24 * 60 * 60 * 1000,
    })

    res.json({ accessToken })
  } catch (err) {
    console.error("Error during Head Doctor login:", err)
    res.status(500).json({ message: "Error logging in. Please try again later." })
  }
})

// Register Admin
router.post("/signup/head", async (req, res) => {
  const { username, email, password } = req.body

  try {
    const hashedPassword = await bcrypt.hash(password, 10)
    const newHead = new HeadDoctor({
      username,
      email,
      password: hashedPassword,
    })

    await newHead.save()
    res.status(201).json({ message: "Head Doctor registered successfully" })
  } catch (err) {
    console.error("Error during Head Doctor registration:", err)
    res.status(500).json({ message: "Error registering Head Doctor" })
  }
})

router.post("/signin/patient", loginLimiter, async (req, res) => {
  const { email, password } = req.body

  // Get IP address (works with or without proxy)
  const ipAddress = req.headers["x-forwarded-for"]?.split(",")[0] || req.ip || req.connection.remoteAddress
  const userAgent = req.headers["user-agent"]

  try {
    const patient = await Patient.findOne({ email })

    if (!patient) {
      // Log failed attempt - user not found
      await LoginAttempt.create({
        email,
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Patient not found",
      })

      return res.status(404).json({ message: "Patient not found" })
    }

    const isMatch = await bcrypt.compare(password, patient.password)

    if (!isMatch) {
      // Log failed attempt - invalid password
      await LoginAttempt.create({
        email,
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Invalid password",
      })

      return res.status(400).json({ message: "Invalid credentials" })
    }

    await LoginAttempt.create({
      email,
      ipAddress,
      userAgent,
      success: true,
    })

    // Create access token
    const accessToken = jwt.sign({ id: patient._id, role: "patient" }, "accessTokenSecret", { expiresIn: "1h" })

    // Create refresh token
    const refreshToken = jwt.sign({ id: patient._id, role: "patient" }, "refreshTokenSecret", { expiresIn: "7d" })

    // Store refresh token in an HTTP-only cookie
    res.cookie("refreshToken", refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "Strict",
      maxAge: 7 * 24 * 60 * 60 * 1000,
    })

    // Send the access token in the response body
    res.json({ accessToken })
  } catch (err) {
    console.error("Error during patient login:", err)
    res.status(500).json({ message: "Error logging in patient" })
  }
})

// Edit Patient Route
router.put("/edit-patient/:id", async (req, res) => {
  const { name, email, phone, dateOfBirth, address, gender } = req.body
  const patientId = req.params.id // Get the patient's ID from the URL

  try {
    const updatedPatient = await Patient.findByIdAndUpdate(
      patientId,
      {
        name,
        email,
        phone,
        dateOfBirth,
        address,
        gender,
      },
      { new: true },
    ) // `{ new: true }` ensures the updated document is returned

    if (!updatedPatient) {
      return res.status(404).json({ message: "Patient not found" })
    }

    res.status(200).json({ message: "Patient updated successfully", patient: updatedPatient })
  } catch (err) {
    res.status(500).json({ message: "Error updating patient" })
  }
})

// Delete Patient Route
router.delete("/delete-patient/:id", async (req, res) => {
  const patientId = req.params.id // Get the patient's ID from the URL

  try {
    const deletedPatient = await Patient.findByIdAndDelete(patientId)

    if (!deletedPatient) {
      return res.status(404).json({ message: "Patient not found" })
    }

    res.status(200).json({ message: "Patient deleted successfully" })
  } catch (err) {
    res.status(500).json({ message: "Error deleting patient" })
  }
})

// Get patient by ID
router.get("/patient/:id", async (req, res) => {
  const { id } = req.params // Get the patient ID from the URL
  try {
    const patient = await Patient.findById(id)
    if (!patient) {
      return res.status(404).json({ message: "Patient not found" })
    }
    res.status(200).json(patient) // Return the patient data
  } catch (err) {
    console.error("Error fetching patient data:", err)
    res.status(500).json({ message: "Error fetching patient data" })
  }
})

router.put("/patient-password/:id", async (req, res) => {
  const { password } = req.body
  const patientId = req.params.id
  try {
    const updatedPatient = await Patient.findById(patientId)
    updatedPatient.password = await bcrypt.hash(password, 10)
    await updatedPatient.save()
    res.status(200).json({ message: "Password updated successfully" })
  } catch (err) {
    res.status(500).json({ message: "Error updating password" })
  }
})

// Route to get a specific patient's profile by ID
router.get("/view-profile/:id", async (req, res) => {
  const patientId = req.params.id // Get patient ID from URL parameters

  try {
    const patient = await Patient.findById(patientId)
    if (!patient) {
      return res.status(404).json({ message: "Patient not found" })
    }

    // Return patient data
    res.status(200).json(patient)
  } catch (err) {
    console.error("Error fetching patient data:", err)
    res.status(500).json({ message: "Error fetching patient data" })
  }
})

// Get patient's full program appointments
router.get("/patient-full-programs/:patientId", async (req, res) => {
  try {
    const { patientId } = req.params

    // Find all full program appointments for this patient that are assigned and have subscription dates
    const fullPrograms = await FullProgram.find({
      patientid: patientId,
      assignmentDate: { $exists: true },
    }).sort({ assignmentDate: -1 }) // Sort by newest first

    res.status(200).json(fullPrograms)
  } catch (error) {
    console.error("Error fetching patient full programs:", error)
    res.status(500).json({
      message: "Error fetching patient full programs",
      error: error.message,
    })
  }
})

// **Register Doctor (with multiple Department Links)**
router.post("/signup/doctor", async (req, res) => {
  const { username, email, password, phone, title, availability, departmentIds } = req.body

  try {
    // Check if all departments exist
    const departments = await Department.find({ _id: { $in: departmentIds } })

    if (departments.length !== departmentIds.length) {
      return res.status(400).json({ message: "One or more departments do not exist" })
    }

    const hashedPassword = await bcrypt.hash(password, 10)
    const newDoctor = new Doctor({
      username,
      email,
      phone,
      password: hashedPassword,
      title,
      availability,
      departments: departmentIds,
    })

    await newDoctor.save()
    res.status(201).json({ message: "Doctor registered successfully", doctor: newDoctor })
  } catch (err) {
    console.error("Error during doctor registration:", err)
    res.status(500).json({ message: "Error registering doctor" })
  }
})

// **Doctor Login Route with refresh token handling**
router.post("/signin/doctor", strictLoginLimiter, async (req, res) => {
  let { email, password } = req.body

  const ipAddress = req.headers["x-forwarded-for"]?.split(",")[0] || req.ip || req.connection.remoteAddress
  const userAgent = req.headers["user-agent"]

  try {
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" })
    }

    email = sanitizeInput(email.toLowerCase())

    if (!isValidEmail(email)) {
      return res.status(400).json({ message: "Invalid email format" })
    }

    const isLocked = await LoginAttempt.shouldLockAccount(email, "doctor")
    if (isLocked) {
      await LoginAttempt.create({
        email,
        role: "doctor",
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Account locked due to multiple failed attempts",
        blocked: true,
      })

      return res.status(429).json({
        message: "Account temporarily locked due to multiple failed login attempts. Please try again after 15 minutes.",
      })
    }

    const isSuspicious = await LoginAttempt.isSuspiciousIP(ipAddress)
    if (isSuspicious) {
      await LoginAttempt.create({
        email,
        role: "doctor",
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Suspicious IP activity detected",
        blocked: true,
      })

      return res.status(429).json({
        message: "Suspicious activity detected. Please try again later.",
      })
    }

    const doctor = await Doctor.findOne({ email })

    if (!doctor) {
      await LoginAttempt.create({
        email,
        role: "doctor",
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Invalid credentials",
      })

      return res.status(401).json({ message: "Invalid email or password" })
    }

    const isMatch = await bcrypt.compare(password, doctor.password)

    if (!isMatch) {
      await LoginAttempt.create({
        email,
        role: "doctor",
        ipAddress,
        userAgent,
        success: false,
        failureReason: "Invalid credentials",
      })

      return res.status(401).json({ message: "Invalid email or password" })
    }

    await LoginAttempt.create({
      email,
      role: "doctor",
      ipAddress,
      userAgent,
      success: true,
    })

    const accessToken = jwt.sign(
      { id: doctor._id, role: "doctor" },
      process.env.JWT_ACCESS_SECRET || "accessTokenSecret",
      { expiresIn: "1h" },
    )

    const refreshToken = jwt.sign(
      { id: doctor._id, role: "doctor" },
      process.env.JWT_REFRESH_SECRET || "refreshTokenSecret",
      { expiresIn: "7d" },
    )

    res.cookie("refreshToken", refreshToken, {
      httpOnly: true, // Only accessible by the web server
      secure: process.env.NODE_ENV === "production", // Only set cookie over HTTPS in production
      sameSite: "Strict", // Strict SameSite policy
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days expiry
    })

    // Send the access token in the response body
    res.json({ accessToken })
  } catch (err) {
    console.error("Error during doctor login:", err)
    res.status(500).json({ message: "Error logging in. Please try again later." })
  }
})

// **Get all Doctors (with populated Department data)**
router.get("/doctors", async (req, res) => {
  const { page = 1, limit = 10, search = "" } = req.query

  try {
    const query = {
      $or: [{ username: { $regex: search, $options: "i" } }, { email: { $regex: search, $options: "i" } }],
    }

    const doctors = await Doctor.find(query)
      .populate("departments", "name") // Populate departments with their names
      .skip((page - 1) * limit)
      .limit(limit)

    const totalDoctors = await Doctor.countDocuments(query)

    res.status(200).json({
      doctors,
      totalPages: Math.ceil(totalDoctors / limit),
      currentPage: page,
      totalDoctors,
    })
  } catch (err) {
    res.status(500).json({ message: "Error fetching doctors" })
  }
})

// **Get Doctor by ID (with populated Department data)**
router.get("/doctor/:id", async (req, res) => {
  const { id } = req.params

  try {
    const doctor = await Doctor.findById(id).populate("departments", "name description")
    if (!doctor) {
      return res.status(404).json({ message: "Doctor not found" })
    }
    res.status(200).json(doctor)
  } catch (err) {
    res.status(500).json({ message: "Error fetching doctor data" })
  }
})

// **Edit Doctor Information (with multiple departments)**
router.put("/edit-doctor/:id", async (req, res) => {
  const { username, email, phone, password, title, availability, departmentIds } = req.body
  const doctorId = req.params.id

  try {
    // Check if all departments exist
    const departments = await Department.find({ _id: { $in: departmentIds } })

    if (departments.length !== departmentIds.length) {
      return res.status(400).json({ message: "One or more departments do not exist" })
    }

    const updatedData = { username, email, phone, title, availability, departments: departmentIds }

    if (password) {
      updatedData.password = await bcrypt.hash(password, 10)
    }

    const updatedDoctor = await Doctor.findByIdAndUpdate(doctorId, updatedData, { new: true })

    if (!updatedDoctor) {
      return res.status(404).json({ message: "Doctor not found" })
    }

    res.status(200).json({ message: "Doctor updated successfully", doctor: updatedDoctor })
  } catch (err) {
    res.status(500).json({ message: "Error updating doctor" })
  }
})

// **Delete Doctor by ID**
router.delete("/delete-doctor/:id", async (req, res) => {
  const doctorId = req.params.id

  try {
    const deletedDoctor = await Doctor.findByIdAndDelete(doctorId)
    if (!deletedDoctor) {
      return res.status(404).json({ message: "Doctor not found" })
    }
    res.status(200).json({ message: "Doctor deleted successfully" })
  } catch (err) {
    res.status(500).json({ message: "Error deleting doctor" })
  }
})

// **Get all Doctors (with Department data)** - Duplicate Route: This route is identical to the one above. It will be overwritten.
router.get("/doctors", async (req, res) => {
  const { page = 1, limit = 10, search = "" } = req.query

  try {
    const query = {
      $or: [{ username: { $regex: search, $options: "i" } }, { email: { $regex: search, $options: "i" } }],
    }

    const doctors = await Doctor.find(query)
      .populate("department", "name") // Include department name in the doctor response - NOTE: This implies 'department' is a single field, not 'departments' array.
      .skip((page - 1) * limit)
      .limit(limit)

    const totalDoctors = await Doctor.countDocuments(query)

    res.status(200).json({
      doctors,
      totalPages: Math.ceil(totalDoctors / limit),
      currentPage: page,
      totalDoctors,
    })
  } catch (err) {
    res.status(500).json({ message: "Error fetching doctors" })
  }
})

// **Get Doctor by ID (with Department data)** - Duplicate Route: This route is identical to the one above. It will be overwritten.
router.get("/doctor/:id", async (req, res) => {
  const { id } = req.params

  try {
    const doctor = await Doctor.findById(id).populate("department", "name") // NOTE: This implies 'department' is a single field, not 'departments' array.
    if (!doctor) {
      return res.status(404).json({ message: "Doctor not found" })
    }
    res.status(200).json(doctor)
  } catch (err) {
    res.status(500).json({ message: "Error fetching doctor data" })
  }
})

// **Edit Doctor Information (with department update)** - Duplicate Route: This route is identical to the one above. It will be overwritten.
router.put("/edit-doctor/:id", async (req, res) => {
  const { username, email, phone, password, title, availability, departmentId } = req.body
  const doctorId = req.params.id

  try {
    const department = await Department.findById(departmentId)
    if (!department) {
      return res.status(400).json({ message: "Department not found" })
    }

    const updatedData = { username, email, phone, title, availability, department: departmentId }

    if (password) {
      updatedData.password = await bcrypt.hash(password, 10)
    }

    const updatedDoctor = await Doctor.findByIdAndUpdate(doctorId, updatedData, { new: true })

    if (!updatedDoctor) {
      return res.status(404).json({ message: "Doctor not found" })
    }

    res.status(200).json({ message: "Doctor updated successfully", doctor: updatedDoctor })
  } catch (err) {
    res.status(500).json({ message: "Error updating doctor" })
  }
})

// **Delete Doctor by ID** - Duplicate Route: This route is identical to the one above. It will be overwritten.
router.delete("/delete-doctor/:id", async (req, res) => {
  const doctorId = req.params.id

  try {
    const deletedDoctor = await Doctor.findByIdAndDelete(doctorId)
    if (!deletedDoctor) {
      return res.status(404).json({ message: "Doctor not found" })
    }
    res.status(200).json({ message: "Doctor deleted successfully" })
  } catch (err) {
    res.status(500).json({ message: "Error deleting doctor" })
  }
})

router.post("/refresh", async (req, res) => {
  const refreshToken = req.cookies.refreshToken // Extract refresh token from cookies

  if (!refreshToken) {
    return res.status(403).json({ message: "Refresh token missing, please log in again" })
  }

  try {
    const decoded = jwt.verify(refreshToken, "refreshTokenSecret") // Verify the refresh token
    let user // To store user details

    // Get user based on the decoded token ID and role
    if (decoded.role === "admin") {
      user = await Admin.findById(decoded.id)
    } else if (decoded.role === "doctor") {
      user = await Doctor.findById(decoded.id)
    } else if (decoded.role === "patient") {
      user = await Patient.findById(decoded.id)
    } else if (decoded.role === "accountant") {
      user = await Accountant.findById(decoded.id)
    } else if (decoded.role === "HeadDoctor") {
      user = await HeadDoctor.findById(decoded.id)
    }

    if (!user) {
      return res.status(403).json({ message: "User not found or invalid refresh token" })
    }

    // Create a new access token
    const accessToken = jwt.sign({ id: user._id, role: decoded.role }, "accessTokenSecret", { expiresIn: "1h" })

    // Send the new access token
    res.json({ accessToken })
  } catch (err) {
    console.error("Error verifying refresh token:", err)
    res.status(403).json({ message: "Invalid or expired refresh token" })
  }
})

// Get Profile Information (based on the logged-in user)
router.get(
  "/profile",
  authenticateUser(["admin", "doctor", "patient", "accountant", "HeadDoctor"]),
  async (req, res) => {
    const userId = req.user.id // Get the user ID from the decoded token
    const userRole = req.user.role // Get the user role (admin, doctor, or patient or accountant)
    try {
      let user
      // Dynamically select the model based on user role
      if (userRole === "admin") {
        user = await Admin.findById(userId)
      } else if (userRole === "doctor") {
        user = await Doctor.findById(userId)
      } else if (userRole === "patient") {
        user = await Patient.findById(userId)
      } else if (userRole === "accountant") {
        user = await Accountant.findById(userId)
      } else if (userRole === "HeadDoctor") {
        user = await HeadDoctor.findById(userId)
      }

      if (!user) {
        return res.status(404).json({ message: "User not found" })
      }

      // Respond with the user's data - UPDATED LOGIC
      const responseData = {
        id: user._id,
        role: userRole,
      }

      // Send username for admin and doctor, name for patient and accountant
      if (userRole === "admin" || userRole === "doctor" || userRole === "HeadDoctor") {
        responseData.username = user.username
      } else if (userRole === "patient" || userRole === "accountant") {
        responseData.name = user.name
      }
      res.status(200).json(responseData)
    } catch (err) {
      console.error("Error fetching user data:", err)
      res.status(403).json({ message: "Unauthorized. Please log in again" }) // Unauthorized response
    }
  },
)

router.post("/logout", (req, res) => {
  res.clearCookie("refreshToken") // Clear the refresh token cookie
  res.status(200).json({ message: "Logged out successfully" })
})

router.get("/doctors/count", async (req, res) => {
  try {
    const totalDoctors = await Doctor.countDocuments()
    const joinedThisWeek = await Doctor.countDocuments({
      createdAt: { $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000) },
    }) // Count Doctors joined this week

    res.status(200).json({
      totalDoctors,
      joinedThisWeek,
    })
  } catch (err) {
    res.status(500).json({ message: "Error fetching doctor data" })
  }
})

router.get("/accountants/count", async (req, res) => {
  try {
    const totalAccountants = await Accountant.countDocuments()
    const joinedThisWeek = await Accountant.countDocuments({
      createdAt: { $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000) },
    }) // Count Accountant joined this week

    res.status(200).json({
      totalAccountants,
      joinedThisWeek,
    })
  } catch (err) {
    res.status(500).json({ message: "Error fetching Accountant data" })
  }
})

router.get("/patients/count", async (req, res) => {
  try {
    const totalPatients = await Patient.countDocuments()
    const joinedThisWeek = await Patient.countDocuments({
      createdAt: { $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000) },
    }) // Count Patients joined this week

    res.status(200).json({
      totalPatients,
      joinedThisWeek,
    })
  } catch (err) {
    res.status(500).json({ message: "Error fetching patient data" })
  }
})

// Function to generate a unique unicValue (UUID)
const generateUniqueUnicValue = async () => {
  let uniqueValue
  let exists = true

  while (exists) {
    uniqueValue = uuidv4()
    const existingProgram = await SchoolProgram.findOne({ unicValue: uniqueValue })
    if (!existingProgram) {
      exists = false
    }
  }
  return uniqueValue
}

router.post("/saveProgram", async (req, res) => {
  try {
    console.log("=== SAVE PROGRAM REQUEST ===")
    console.log("Received request to save program data:", req.body)

    const {
      patientId,
      date,
      time,
      description,
      programType,
      programKind,
      totalAmount,
      paidAmount,
      remainingAmount,
      paymentStatus,
      paymentMethod,
      unicValue,
      transferScreenshot, // Added transferScreenshot field
    } = req.body

    if (!patientId || !date || !time || !description || !programType) {
      return res.status(400).json({
        message: "Missing required fields",
        required: ["patientId", "date", "time", "description", "programType"],
      })
    }

    if (programType === "single_session" && (!programKind || !Array.isArray(programKind) || programKind.length === 0)) {
      return res.status(400).json({
        message: "Program kind is required for single session and must be a non-empty array",
      })
    }

    // ENHANCED AVAILABILITY CHECK with better date handling
    const { startOfDay, endOfDay } = getDateRange(date)

    console.log("Checking availability for:", {
      programType,
      date,
      time,
      dateRange: { startOfDay, endOfDay },
    })

    let Model
    switch (programType) {
      case "full_program":
        Model = FullProgram
        break
      case "single_session":
        Model = SingleProgram
        break
      case "school_evaluation":
        Model = SchoolProgram
        break
      default:
        return res.status(400).json({
          message: "Invalid program type",
        })
    }

    // Check for existing appointment at the same time with improved query
    const conflictingAppointment = await Model.findOne({
      date: {
        $gte: startOfDay,
        $lte: endOfDay,
      },
      time: time,
      status: { $ne: "cancelled" }, // Don't consider cancelled appointments
    })

    if (conflictingAppointment) {
      console.log("❌ APPOINTMENT CONFLICT DETECTED:", {
        existingId: conflictingAppointment._id,
        existingDate: conflictingAppointment.date,
        existingTime: conflictingAppointment.time,
        existingStatus: conflictingAppointment.status,
        existingPatient: conflictingAppointment.patientid || conflictingAppointment.patientId,
        requestedDate: date,
        requestedTime: time,
        programType: programType,
      })

      return res.status(409).json({
        message: "Time slot is already booked",
        error: "APPOINTMENT_CONFLICT",
        conflictingAppointment: {
          id: conflictingAppointment._id,
          date: conflictingAppointment.date,
          time: conflictingAppointment.time,
          description: conflictingAppointment.description,
          patientId: conflictingAppointment.patientid || conflictingAppointment.patientId,
          status: conflictingAppointment.status,
        },
      })
    }

    console.log("✅ NO CONFLICTS FOUND - Proceeding with appointment creation")

    // Generate unicValue for school evaluation
    let finalUnicValue = unicValue
    if (programType === "school_evaluation" && !finalUnicValue) {
      finalUnicValue = await generateUniqueUnicValue()
    }

    let newProgram
    let assignmentResults = null

    // Create the appointment with normalized date
    const appointmentDate = new Date(date)

    if (programType === "full_program") {
      newProgram = new FullProgram({
        patientid: patientId,
        date: appointmentDate,
        time: time,
        description: description,
        programType: programType,
        status: "not active",
        totalAmount: totalAmount || 0,
        paidAmount: paidAmount || 0,
        remainingAmount: remainingAmount || totalAmount || 0,
        paymentStatus: paymentStatus || "PENDING",
        paymentMethod: paymentMethod || "CASH",
        transferScreenshot: transferScreenshot || null, // Added transferScreenshot
        isAssigned: false,
        assignmentDate: null,
      })
    } else if (programType === "single_session") {
      newProgram = new SingleProgram({
        patientid: patientId,
        date: appointmentDate,
        time: time,
        description: description,
        programkind: programKind,
        status: "upcoming", // <--- UPDATED: Set initial status to "upcoming"
        totalAmount: totalAmount || 0,
        paidAmount: paidAmount || 0,
        remainingAmount: remainingAmount || totalAmount || 0,
        paymentStatus: paymentStatus || "PENDING",
        paymentMethod: paymentMethod || "CASH",
        transferScreenshot: transferScreenshot || null, // Added transferScreenshot
        isAssigned: true,
        assignmentDate: new Date(),
      })
    } else if (programType === "school_evaluation") {
      newProgram = new SchoolProgram({
        patientid: patientId,
        date: appointmentDate,
        time: time,
        description: description,
        unicValue: finalUnicValue,
        status: "active",
        totalAmount: totalAmount || 0,
        paidAmount: paidAmount || 0,
        remainingAmount: remainingAmount || totalAmount || 0,
        paymentStatus: paymentStatus || "PENDING",
        paymentMethod: paymentMethod || "CASH",
        transferScreenshot: transferScreenshot || null, // Added transferScreenshot
        isAssigned: true,
        assignmentDate: new Date(),
      })
    }

    if (newProgram.updatePaymentStatus) {
      newProgram.updatePaymentStatus()
    }

    const savedProgram = await newProgram.save()
    console.log("✅ PROGRAM SAVED SUCCESSFULLY:", {
      id: savedProgram._id,
      date: savedProgram.date,
      time: savedProgram.time,
      programType: savedProgram.programType || programType,
    })

    if (programType === "single_session" && programKind && programKind.length > 0) {
      const assignmentNotes = `Single session assignment - ${description}`
      assignmentResults = await AssignmentService.createMultipleAssignments(
        programKind,
        patientId,
        assignmentNotes,
        savedProgram._id,
      )
      console.log("Assignment results:", assignmentResults)
    }

    const response = {
      message: "Program saved successfully",
      program: savedProgram,
    }

    // Include assignment results if applicable
    if (assignmentResults) {
      response.assignments = {
        totalAssigned: assignmentResults.totalAssigned,
        totalFailed: assignmentResults.totalFailed,
        details: assignmentResults.results,
        errors: assignmentResults.errors,
      }
      if (assignmentResults.totalFailed > 0) {
        response.warning = `Program saved but ${assignmentResults.totalFailed} service assignments failed`
      }
    }

    res.status(200).json(response)
  } catch (error) {
    console.error("❌ ERROR SAVING PROGRAM:", error)

    // Handle MongoDB duplicate key error
    if (error.code === 11000) {
      return res.status(409).json({
        message: "Appointment conflict - this time slot may already be booked",
        error: "DUPLICATE_APPOINTMENT",
      })
    }

    res.status(500).json({
      message: "Error saving program",
      error: error.message,
    })
  }
})

// Save Money Record Route - Fixed
router.post("/saveMoneyRecord", async (req, res) => {
  try {
    console.log("Received request to save money record:", req.body)

    const { patientId, programId, price, status, invoiceId, programType, comment, patientName } = req.body

    // Validate required fields
    if (!patientId || !programId || !programType || !price) {
      return res.status(400).json({
        message: "Missing required fields: patientId, programId, price, programType",
      })
    }

    // Create new money record with programType
    const newMoneyRecord = new Money({
      patientId: patientId,
      programId: programId,
      price: price,
      status: status || "completed",
      invoiceId: invoiceId || `INV-${Date.now()}`,
      programType: programType, // This was missing before
      comment: comment || `Payment for ${programType} - ${patientName}`,
    })

    const savedMoneyRecord = await newMoneyRecord.save()
    console.log("Money record saved successfully:", savedMoneyRecord)

    //bug """ Update the program's payment status
    //  await updateProgramPaymentStatus(programId)

    res.status(200).json({
      message: "Money record saved successfully",
      moneyRecord: savedMoneyRecord,
    })
  } catch (error) {
    console.error("Error saving money record:", error)
    res.status(500).json({
      message: "Error saving money record",
      error: error.message,
    })
  }
})

// Helper function to update program payment status
const updateProgramPaymentStatus = async (programId) => {
  try {
    const program = await FullProgram.findById(programId)
    if (!program) return

    // Calculate total paid amount from Money and Checks
    const moneyRecords = await Money.find({ programId: programId })
    const totalMoneyPaid = moneyRecords.reduce((sum, record) => sum + record.price, 0)

    const clearedChecks = await Checks.find({
      programId: programId,
      status: "cleared",
      isActive: true,
    })
    const totalChecksPaid = clearedChecks.reduce((sum, check) => sum + check.amount, 0)

    const totalPaid = totalMoneyPaid + totalChecksPaid

    // Update program payment status
    program.paidAmount = totalPaid
    program.remainingAmount = Math.max(0, program.totalAmount - totalPaid)

    if (totalPaid >= program.totalAmount) {
      program.paymentStatus = "FULLY_PAID"
      program.remainingAmount = 0
    } else if (totalPaid > 0) {
      program.paymentStatus = "PARTIALLY_PAID"
    } else {
      program.paymentStatus = "PENDING"
    }

    await program.save()
    console.log("Program payment status updated:", program.paymentStatus)
  } catch (error) {
    console.error("Error updating program payment status:", error)
  }
}

// Get patient by ID
router.get("/patient/:id", async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id)
    if (!patient) {
      return res.status(404).json({ message: "Patient not found" })
    }
    res.json(patient)
  } catch (error) {
    console.error("Error fetching patient:", error)
    res.status(500).json({ message: "Error fetching patient" })
  }
})

// Complete Payment Route for Accountant (Full Program remaining payment)
router.post("/completeFullProgramPayment", async (req, res) => {
  try {
    console.log("Received request to complete full program payment:", req.body)

    const { appointmentId, paymentMethod, amount, patientId, patientName, checkDetails } = req.body

    // Validate required fields
    if (!appointmentId || !paymentMethod || !amount) {
      return res.status(400).json({
        message: "Missing required fields: appointmentId, paymentMethod, amount",
      })
    }

    const program = await FullProgram.findById(appointmentId)
    if (!program) {
      return res.status(404).json({ message: "Appointment not found" })
    }

    if (program.programType !== "full_program") {
      return res.status(400).json({ message: "This endpoint is only for full program payments" })
    }

    let paymentRecord = null

    if (paymentMethod === "cash") {
      // Save cash payment
      paymentRecord = new Money({
        patientId: patientId,
        programId: appointmentId,
        price: amount,
        status: "completed",
        invoiceId: `INV-${Date.now()}`,
        programType: "full_program",
        comment: `Full Program remaining payment (Cash) - ${patientName}`,
      })
      await paymentRecord.save()

      // Update program payment status immediately for cash
      const currentPaidAmount = program.paidAmount || 1000 // Initial payment
      const newPaidAmount = currentPaidAmount + amount

      program.paidAmount = newPaidAmount
      program.remainingAmount = Math.max(0, program.totalAmount - newPaidAmount)

      if (newPaidAmount >= program.totalAmount) {
        program.paymentStatus = "FULLY_PAID"
        program.remainingAmount = 0
      } else {
        program.paymentStatus = "PARTIALLY_PAID"
      }

      // Set assignment details and subscription end date
      program.isAssigned = true
      program.assignmentDate = new Date()
      // Calculate subscription end date based on academic year (Aug 15 - Jun 15)
      program.subscriptionEndDate = calculateAcademicYearEndDate()

      await program.save()
    } else if (paymentMethod === "installment" && checkDetails) {
      // First create a Money record for installment tracking
      const installmentMoneyRecord = new Money({
        patientId: patientId,
        programId: appointmentId,
        price: amount,
        status: "pending", // Will be updated when checks are cleared
        invoiceId: `INV-${Date.now()}`,
        programType: "full_program",
        comment: `Full Program installment payment - ${patientName}`,
      })
      const savedMoneyRecord = await installmentMoneyRecord.save()

      // Save installment payments as checks with moneyId reference
      const checkRecords = []
      for (const check of checkDetails) {
        const newCheck = new Checks({
          patientId: patientId,
          programId: appointmentId,
          moneyId: savedMoneyRecord._id,
          amount: Number.parseFloat(check.amount),
          checkNumber: check.checkNumber,
          bankName: check.bankName || "",
          dueDate: new Date(check.dueDate),
          status: "pending",
          isActive: true,
          notes: `Full Program installment payment - ${patientName}`,
        })
        const savedCheck = await newCheck.save()
        checkRecords.push(savedCheck)
      }

      // For installment, update the program status but keep it as PARTIALLY_PAID until checks are cleared
      const currentPaidAmount = program.paidAmount || 1000
      program.paidAmount = currentPaidAmount // Don't add check amount until cleared
      program.remainingAmount = program.totalAmount - currentPaidAmount
      program.paymentStatus = "PARTIALLY_PAID"

      // Set assignment details and subscription end date for installment too
      program.isAssigned = true
      program.assignmentDate = new Date()
      // Calculate subscription end date based on academic year (Aug 15 - Jun 15)
      program.subscriptionEndDate = calculateAcademicYearEndDate()

      await program.save()

      paymentRecord = { moneyRecord: savedMoneyRecord, checks: checkRecords }
    }

    res.status(200).json({
      message: "Full program payment completed successfully",
      paymentRecord: paymentRecord,
      shouldAssignToDepartments: program.isAssigned, // This will be true for both cash and installment now
      patientId: patientId,
      programDescription: program.description,
    })
  } catch (error) {
    console.error("Error completing full program payment:", error)
    res.status(500).json({
      message: "Error completing payment",
      error: error.message,
    })
  }
})

// New route to get appointments from SingleProgram
router.get("/appointments", async (req, res) => {
  const { page = 1, limit = 10, search = "", department = "" } = req.query

  try {
    const query = {}

    // Filter by department if specified
    if (department) {
      query.programkind = { $in: [department] }
    }

    // Search functionality
    if (search) {
      const patients = await Patient.find({
        name: { $regex: search, $options: "i" },
      }).select("_id")

      if (patients.length > 0) {
        query.patientid = { $in: patients.map((p) => p._id) }
      } else {
        return res.status(200).json({
          appointments: [],
          totalPages: 0,
          currentPage: Number.parseInt(page),
          totalAppointments: 0,
        })
      }
    }

    const appointments = await SingleProgram.find(query)
      .populate({
        path: "patientid",
        select: "name email phone",
        model: "Patient",
      })
      .skip((Number.parseInt(page) - 1) * Number.parseInt(limit))
      .limit(Number.parseInt(limit))
      .sort({ date: -1, createdAt: -1 })

    const totalAppointments = await SingleProgram.countDocuments(query)

    res.status(200).json({
      appointments,
      totalPages: Math.ceil(totalAppointments / Number.parseInt(limit)),
      currentPage: Number.parseInt(page),
      totalAppointments,
    })
  } catch (error) {
    console.error("Error fetching appointments:", error)
    res.status(500).json({
      message: "Error fetching appointments",
      error: error.message,
    })
  }
})

// Get patient's single program appointments with department details
router.get("/patient-single-programs/:patientId", async (req, res) => {
  try {
    const { patientId } = req.params

    // Find all single program appointments for this patient
    const singlePrograms = await SingleProgram.find({
      patientid: patientId,
    }).sort({ date: -1, createdAt: -1 }) // Sort by newest first

    res.status(200).json(singlePrograms)
  } catch (error) {
    console.error("Error fetching patient single programs:", error)
    res.status(500).json({
      message: "Error fetching patient single programs",
      error: error.message,
    })
  }
})

// New route to check if a patient has an active Full Program
router.get("/check-active-full-program/:patientId", async (req, res) => {
  try {
    const { patientId } = req.params
    const now = new Date()

    const activeProgram = await FullProgram.findOne({
      patientid: patientId,
      subscriptionEndDate: { $gte: now }, // Check if subscriptionEndDate is in the future or today
      status: { $ne: "complete" }, // Ensure it's not already marked as complete
    })

    if (activeProgram) {
      return res.status(200).json({ hasActiveFullProgram: true, program: activeProgram })
    } else {
      return res.status(200).json({ hasActiveFullProgram: false })
    }
  } catch (error) {
    console.error("Error checking active full program:", error)
    res.status(500).json({ message: "Error checking active full program", error: error.message })
  }
})

// Get patient's case study file - Updated to use DrastHalaPlan model
router.get("/patient-case-study/:patientId", async (req, res) => {
  try {
    const { patientId } = req.params

    // Find the patient first
    const patient = await Patient.findById(patientId)
    if (!patient) {
      return res.status(404).json({ message: "Patient not found" })
    }

    // Find the case study plan for this patient
    const caseStudyPlan = await DrastHalaPlan.findOne({ patient: patientId }).sort({ lastModified: -1 })

    if (!caseStudyPlan || !caseStudyPlan.filePath) {
      return res.status(404).json({
        message: "لم يتم إنشاء ملف دراسة الحالة بعد",
        hasCaseStudy: false,
      })
    }

    // Construct the file URL
    const fileUrl = `${process.env.NEXT_PUBLIC_API_URL || "http://localhost:8070"}/uploads/DRAST-7ALA/plan/${caseStudyPlan.filePath}`

    // Return case study file information
    res.status(200).json({
      hasCaseStudy: true,
      caseStudyFile: {
        filename: caseStudyPlan.fileName || caseStudyPlan.title,
        url: fileUrl,
        uploadDate: caseStudyPlan.lastModified,
        title: caseStudyPlan.title,
      },
      patientName: patient.name,
      patientId: patient._id,
    })
  } catch (error) {
    console.error("Error fetching patient case study:", error)
    res.status(500).json({
      message: "Error fetching patient case study",
      error: error.message,
    })
  }
})

// Get patient's money records
router.get("/money/patient/:patientId", async (req, res) => {
  try {
    const { patientId } = req.params
    const { page = 1, limit = 10, programType = "", status = "" } = req.query

    console.log("Fetching money records for patient:", patientId)

    // Build query
    const query = { patientId: patientId }

    if (programType) {
      query.programType = programType
    }

    if (status) {
      query.status = status
    }

    // Get money records with pagination
    const moneyRecords = await Money.find(query)
      .populate({
        path: "patientId",
        select: "name email",
      })
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number.parseInt(limit))

    const totalRecords = await Money.countDocuments(query)

    // Calculate summary statistics using proper ObjectId conversion
    const patientObjectId = new mongoose.Types.ObjectId(patientId)

    const totalPaid = await Money.aggregate([
      { $match: { patientId: patientObjectId, status: "completed" } },
      { $group: { _id: null, total: { $sum: "$price" } } },
    ])

    const pendingAmount = await Money.aggregate([
      { $match: { patientId: patientObjectId, status: "pending" } },
      { $group: { _id: null, total: { $sum: "$price" } } },
    ])

    res.status(200).json({
      success: true,
      data: {
        records: moneyRecords,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(totalRecords / limit),
          totalRecords: totalRecords,
          hasNext: page * limit < totalRecords,
          hasPrev: page > 1,
        },
        summary: {
          totalPaid: totalPaid[0]?.total || 0,
          pendingAmount: pendingAmount[0]?.total || 0,
          totalRecords: totalRecords,
        },
      },
    })
  } catch (error) {
    console.error("Error fetching patient money records:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching money records",
      error: error.message,
    })
  }
})

// Get patient's check records
router.get("/checks/patient/:patientId", async (req, res) => {
  try {
    const { patientId } = req.params
    const { page = 1, limit = 10, status = "" } = req.query

    console.log("Fetching check records for patient:", patientId)

    // Build query
    const query = { patientId: patientId, isActive: true }

    if (status) {
      query.status = status
    }

    // Get check records with pagination
    const checkRecords = await Checks.find(query)
      .populate({
        path: "patientId",
        select: "name email",
      })
      .populate({
        path: "moneyId",
        select: "invoiceId programType",
      })
      .sort({ dueDate: 1, createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number.parseInt(limit))

    const totalRecords = await Checks.countDocuments(query)

    // Calculate summary statistics using proper ObjectId conversion
    const currentDate = new Date()
    const patientObjectId = new mongoose.Types.ObjectId(patientId)

    const statusSummary = await Checks.aggregate([
      { $match: { patientId: patientObjectId, isActive: true } },
      {
        $group: {
          _id: "$status",
          count: { $sum: 1 },
          totalAmount: { $sum: "$amount" },
        },
      },
      { $sort: { _id: 1 } }, // Sort statuses alphabetically for consistency
    ])

    const overdueSummary = await Checks.aggregate([
      {
        $match: {
          patientId: patientObjectId,
          isActive: true,
          dueDate: { $lt: currentDate },
          status: { $in: ["pending", "deposited"] },
        },
      },
      {
        $group: {
          _id: null,
          count: { $sum: 1 },
          totalAmount: { $sum: "$amount" },
        },
      },
    ])

    res.status(200).json({
      success: true,
      data: {
        records: checkRecords,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(totalRecords / limit),
          totalRecords: totalRecords,
          hasNext: page * limit < totalRecords,
          hasPrev: page > 1,
        },
        summary: {
          statusBreakdown: statusSummary,
          overdue: overdueSummary[0] || { count: 0, totalAmount: 0 },
          totalRecords: totalRecords,
        },
      },
    })
  } catch (error) {
    console.error("Error fetching patient check records:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching check records",
      error: error.message,
    })
  }
})

// Get patient's financial summary
router.get("/financial-summary/:patientId", async (req, res) => {
  try {
    const { patientId } = req.params

    console.log("Fetching financial summary for patient:", patientId)

    // Get all programs for this patient
    const [fullPrograms, singlePrograms, schoolPrograms] = await Promise.all([
      FullProgram.find({ patientid: patientId }),
      SingleProgram.find({ patientid: patientId }),
      SchoolProgram.find({ patientid: patientId }),
    ])

    // Get money records
    const moneyRecords = await Money.find({ patientId: patientId })

    // Get active checks
    const activeChecks = await Checks.find({ patientId: patientId, isActive: true })

    // Calculate totals
    const totalProgramValue = [
      ...fullPrograms.map((p) => p.totalAmount || 0),
      ...singlePrograms.map((p) => p.totalAmount || 0),
      ...schoolPrograms.map((p) => p.totalAmount || 0),
    ].reduce((sum, amount) => sum + amount, 0)

    const totalPaid = moneyRecords
      .filter((record) => record.status === "completed")
      .reduce((sum, record) => sum + record.price, 0)

    const totalPending = moneyRecords
      .filter((record) => record.status === "pending")
      .reduce((sum, record) => sum + record.price, 0)

    const clearedChecks = activeChecks
      .filter((check) => check.status === "cleared")
      .reduce((sum, check) => sum + check.amount, 0)

    const pendingChecks = activeChecks
      .filter((check) => ["pending", "deposited"].includes(check.status))
      .reduce((sum, check) => sum + check.amount, 0)

    const currentDate = new Date()
    const overdueChecks = activeChecks
      .filter((check) => check.dueDate < currentDate && ["pending", "deposited"].includes(check.status))
      .reduce((sum, check) => sum + check.amount, 0)

    // Active programs count
    const activePrograms = {
      fullPrograms: fullPrograms.filter((p) => p.subscriptionEndDate && p.subscriptionEndDate > currentDate).length,
      totalPrograms: fullPrograms.length + singlePrograms.length + schoolPrograms.length,
    }

    res.status(200).json({
      success: true,
      data: {
        programSummary: {
          totalValue: totalProgramValue,
          activePrograms: activePrograms.fullPrograms, // Corrected to reflect the number of active full programs
          totalPrograms: activePrograms.totalPrograms,
        },
        paymentSummary: {
          totalPaid: totalPaid + clearedChecks,
          cashPaid: totalPaid,
          checksPaid: clearedChecks,
          pendingAmount: totalPending + pendingChecks,
          overdueAmount: overdueChecks,
        },
        checksSummary: {
          totalChecks: activeChecks.length,
          pendingChecks: activeChecks.filter((c) => c.status === "pending").length,
          clearedChecks: activeChecks.filter((c) => c.status === "cleared").length,
          overdueChecks: activeChecks.filter(
            (c) => c.dueDate < currentDate && ["pending", "deposited"].includes(c.status),
          ).length,
        },
      },
    })
  } catch (error) {
    console.error("Error fetching financial summary:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching financial summary",
      error: error.message,
    })
  }
})

// Income trend endpoint for dashboard statistics
router.get("/income-trend", async (req, res) => {
  try {
    const { period = "week" } = req.query
    console.log(`Fetching income trend data for period: ${period}`)

    let labels = []
    let paidSeries = []
    let pendingSeries = []
    let matchStage = {}
    let groupStage = {}
    let sortStage = {}

    const now = new Date()

    if (period === "week") {
      // Get data for the last 7 days
      const startOfWeek = new Date(now)
      startOfWeek.setDate(now.getDate() - 6)
      startOfWeek.setHours(0, 0, 0, 0)

      const endOfWeek = new Date(now)
      endOfWeek.setHours(23, 59, 59, 999)

      matchStage = {
        createdAt: {
          $gte: startOfWeek,
          $lte: endOfWeek,
        },
      }

      groupStage = {
        _id: {
          year: { $year: "$createdAt" },
          month: { $month: "$createdAt" },
          day: { $dayOfMonth: "$createdAt" },
          status: "$status",
        },
        totalAmount: { $sum: "$price" },
        count: { $sum: 1 },
      }

      sortStage = { "_id.year": 1, "_id.month": 1, "_id.day": 1 }

      // Generate labels for the last 7 days
      labels = []
      for (let i = 6; i >= 0; i--) {
        const date = new Date(now)
        date.setDate(now.getDate() - i)
        labels.push(date.toLocaleDateString("en-US", { weekday: "short" }))
      }
    } else if (period === "month") {
      // Get data for the last 6 months
      const startOfPeriod = new Date(now.getFullYear(), now.getMonth() - 5, 1)
      const endOfPeriod = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999)

      matchStage = {
        createdAt: {
          $gte: startOfPeriod,
          $lte: endOfPeriod,
        },
      }

      groupStage = {
        _id: {
          year: { $year: "$createdAt" },
          month: { $month: "$createdAt" },
          status: "$status",
        },
        totalAmount: { $sum: "$price" },
        count: { $sum: 1 },
      }

      sortStage = { "_id.year": 1, "_id.month": 1 }

      // Generate labels for the last 6 months
      labels = []
      for (let i = 5; i >= 0; i--) {
        const date = new Date(now.getFullYear(), now.getMonth() - i, 1)
        labels.push(date.toLocaleDateString("en-US", { month: "short" }))
      }
    }

    // Aggregate data from Money collection
    const aggregationPipeline = [{ $match: matchStage }, { $group: groupStage }, { $sort: sortStage }]

    const results = await Money.aggregate(aggregationPipeline)
    console.log("Aggregation results:", results)

    // Initialize arrays with zeros
    paidSeries = new Array(labels.length).fill(0)
    pendingSeries = new Array(labels.length).fill(0)

    // Process results and map to the correct time slots
    results.forEach((result) => {
      let index = -1

      if (period === "week") {
        // Find the index based on the day
        const resultDate = new Date(result._id.year, result._id.month - 1, result._id.day)
        const daysDiff = Math.floor(
          (resultDate - new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6)) / (1000 * 60 * 60 * 24),
        )
        index = daysDiff >= 0 && daysDiff < 7 ? daysDiff : -1
      } else if (period === "month") {
        // Find the index based on the month
        const monthsDiff = (result._id.year - now.getFullYear()) * 12 + (result._id.month - 1) - (now.getMonth() - 5)
        index = monthsDiff >= 0 && monthsDiff < 6 ? monthsDiff : -1
      }

      if (index >= 0) {
        if (result._id.status === "completed") {
          paidSeries[index] = result.totalAmount
        } else if (result._id.status === "pending") {
          pendingSeries[index] = result.totalAmount
        }
      }
    })

    // Calculate totals
    const totalPaid = await Money.aggregate([
      { $match: { status: "completed" } },
      { $group: { _id: null, total: { $sum: "$price" } } },
    ])

    const totalPending = await Money.aggregate([
      { $match: { status: "pending" } },
      { $group: { _id: null, total: { $sum: "$price" } } },
    ])

    const responseData = {
      labels,
      paidSeries,
      pendingSeries,
      totalPaid: totalPaid[0]?.total || 0,
      totalPending: totalPending[0]?.total || 0,
      period,
      summary: {
        totalTransactions: await Money.countDocuments(),
        completedTransactions: await Money.countDocuments({ status: "completed" }),
        pendingTransactions: await Money.countDocuments({ status: "pending" }),
      },
    }

    console.log("Sending response:", responseData)
    res.status(200).json(responseData)
  } catch (error) {
    console.error("Error fetching income trend data:", error)
    res.status(500).json({
      message: "Error fetching income trend data",
      error: error.message,
    })
  }
})

// Income summary endpoint for donut chart
router.get("/income-summary", async (req, res) => {
  try {
    console.log("Fetching income summary data...")

    // Get current date for filtering (optional - you can modify this for different periods)
    const now = new Date()
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999)

    // You can uncomment the date filter below if you want monthly data only
    // const dateFilter = {
    //   createdAt: {
    //     $gte: startOfMonth,
    //     $lte: endOfMonth,
    //   },
    // }

    // For now, let's get all-time data (remove dateFilter from match stages)
    const dateFilter = {} // Empty filter for all-time data

    // Aggregate completed payments (Net Income)
    const completedPayments = await Money.aggregate([
      {
        $match: {
          status: "completed",
          ...dateFilter,
        },
      },
      {
        $group: {
          _id: null,
          totalAmount: { $sum: "$price" },
          count: { $sum: 1 },
        },
      },
    ])

    // Aggregate pending payments (Pending Money)
    const pendingPayments = await Money.aggregate([
      {
        $match: {
          status: "pending",
          ...dateFilter,
        },
      },
      {
        $group: {
          _id: null,
          totalAmount: { $sum: "$price" },
          count: { $sum: 1 },
        },
      },
    ])

    // Calculate totals
    const netIncome = completedPayments[0]?.totalAmount || 0
    const pendingMoney = pendingPayments[0]?.totalAmount || 0
    const totalIncome = netIncome + pendingMoney

    // Get additional statistics
    const totalTransactions = await Money.countDocuments(dateFilter)
    const completedCount = completedPayments[0]?.count || 0
    const pendingCount = pendingPayments[0]?.count || 0

    // Calculate percentages for better insights
    const netIncomePercentage = totalIncome > 0 ? Math.round((netIncome / totalIncome) * 100) : 0
    const pendingPercentage = totalIncome > 0 ? Math.round((pendingMoney / totalIncome) * 100) : 0

    // Get program type breakdown for additional insights
    const programTypeBreakdown = await Money.aggregate([
      { $match: { status: "completed", ...dateFilter } },
      {
        $group: {
          _id: "$programType",
          totalAmount: { $sum: "$price" },
          count: { $sum: 1 },
        },
      },
      { $sort: { totalAmount: -1 } },
    ])

    const responseData = {
      netIncome,
      pendingMoney,
      totalIncome,
      statistics: {
        totalTransactions,
        completedTransactions: completedCount,
        pendingTransactions: pendingCount,
        netIncomePercentage,
        pendingPercentage,
      },
      programTypeBreakdown,
      period: "all-time", // You can modify this based on your filtering needs
      lastUpdated: new Date().toISOString(),
    }

    console.log("Income summary data:", responseData)
    res.status(200).json(responseData)
  } catch (error) {
    console.error("Error fetching income summary data:", error)
    res.status(500).json({
      message: "Error fetching income summary data",
      error: error.message,
    })
  }
})

// Monthly income summary endpoint with period filtering
router.get("/income-summary-monthly", async (req, res) => {
  try {
    const { period = "current" } = req.query // current, last, or specific month
    console.log(`Fetching monthly income summary for period: ${period}`)

    let startDate, endDate

    const now = new Date()

    if (period === "current") {
      // Current month
      startDate = new Date(now.getFullYear(), now.getMonth(), 1)
      endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999)
    } else if (period === "last") {
      // Last month
      startDate = new Date(now.getFullYear(), now.getMonth() - 1, 1)
      endDate = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999)
    } else {
      // All time (default)
      startDate = new Date(2020, 0, 1) // Far back date
      endDate = now
    }

    const dateFilter = {
      createdAt: {
        $gte: startDate,
        $lte: endDate,
      },
    }

    // Aggregate completed payments
    const completedPayments = await Money.aggregate([
      { $match: { status: "completed", ...dateFilter } },
      {
        $group: {
          _id: null,
          totalAmount: { $sum: "$price" },
          count: { $sum: 1 },
        },
      },
    ])

    // Aggregate pending payments
    const pendingPayments = await Money.aggregate([
      { $match: { status: "pending", ...dateFilter } },
      {
        $group: {
          _id: null,
          totalAmount: { $sum: "$price" },
          count: { $sum: 1 },
        },
      },
    ])

    const netIncome = completedPayments[0]?.totalAmount || 0
    const pendingMoney = pendingPayments[0]?.totalAmount || 0
    const totalIncome = netIncome + pendingMoney

    // Get daily breakdown for the period
    const dailyBreakdown = await Money.aggregate([
      { $match: dateFilter },
      {
        $group: {
          _id: {
            year: { $year: "$createdAt" },
            month: { $month: "$createdAt" },
            day: { $dayOfMonth: "$createdAt" },
            status: "$status",
          },
          totalAmount: { $sum: "$price" },
          count: { $sum: 1 },
        },
      },
      { $sort: { "_id.year": 1, "_id.month": 1, "_id.day": 1 } },
    ])

    const responseData = {
      netIncome,
      pendingMoney,
      totalIncome,
      period: period,
      periodRange: {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
      },
      statistics: {
        completedTransactions: completedPayments[0]?.count || 0,
        pendingTransactions: pendingPayments[0]?.count || 0,
        totalTransactions: (completedPayments[0]?.count || 0) + (pendingPayments[0]?.count || 0),
      },
      dailyBreakdown,
      lastUpdated: new Date().toISOString(),
    }

    console.log("Monthly income summary data:", responseData)
    res.status(200).json(responseData)
  } catch (error) {
    console.error("Error fetching monthly income summary:", error)
    res.status(500).json({
      message: "Error fetching monthly income summary",
      error: error.message,
    })
  }
})

// Dashboard doctors endpoint - optimized for dashboard display

// Dashboard doctors endpoint - optimized for dashboard display
router.get("/doctors-dashboard", async (req, res) => {
  try {
    console.log("Fetching doctors for dashboard...")

    // Get doctors with populated department information, limited for dashboard
    const doctors = await Doctor.find({})
      .populate({
        path: "departments",
        select: "name description",
        model: "Department",
      })
      .select("username email title departments createdAt")
      .sort({ createdAt: -1 }) // Show newest doctors first
      .limit(6) // Limit to 6 doctors for dashboard display

    // Calculate some statistics
    const totalDoctors = await Doctor.countDocuments()

    // Get department distribution
    const departmentStats = await Doctor.aggregate([
      { $unwind: "$departments" },
      {
        $lookup: {
          from: "departments",
          localField: "departments",
          foreignField: "_id",
          as: "departmentInfo",
        },
      },
      { $unwind: "$departmentInfo" },
      {
        $group: {
          _id: "$departmentInfo.name",
          count: { $sum: 1 },
        },
      },
      { $sort: { count: -1 } },
      { $limit: 5 }, // Top 5 departments
    ])

    const responseData = {
      doctors: doctors.map((doctor) => ({
        _id: doctor._id,
        username: doctor.username,
        email: doctor.email,
        title: doctor.title,
        departments: doctor.departments || [],
        createdAt: doctor.createdAt,
      })),
      statistics: {
        totalDoctors,
        departmentDistribution: departmentStats,
      },
      lastUpdated: new Date().toISOString(),
    }

    console.log(`Fetched ${doctors.length} doctors for dashboard`)
    res.status(200).json(responseData)
  } catch (error) {
    console.error("Error fetching doctors for dashboard:", error)
    res.status(500).json({
      message: "Error fetching doctors for dashboard",
      error: error.message,
      doctors: [], // Return empty array as fallback
      statistics: {
        totalDoctors: 0,
        departmentDistribution: [],
      },
    })
  }
})

// NEW ENDPOINT: Get latest completed appointments from all program types
router.get("/latest-completed-appointments", async (req, res) => {
  try {
    const { limit = 10 } = req.query
    console.log("Fetching latest completed appointments...")

    // Get completed appointments from all three program types
    const [fullProgramAppointments, singleProgramAppointments, schoolProgramAppointments] = await Promise.all([
      // Full Program completed appointments - Check subscriptionEndDate instead of status
      FullProgram.find({
        subscriptionEndDate: { $lt: new Date() }, // Past subscription end date
        isAssigned: true, // Only assigned programs
      })
        .populate({
          path: "patientid",
          select: "name phone",
          model: "Patient",
        })
        .select("patientid date time description subscriptionEndDate updatedAt programType")
        .sort({ subscriptionEndDate: -1 }) // Sort by subscription end date
        .limit(Number.parseInt(limit))
        .lean(),

      // Single Program completed appointments
      SingleProgram.find({ status: "completed" })
        .populate({
          path: "patientid",
          select: "name phone",
          model: "Patient",
        })
        .select("patientid date time description status updatedAt programkind")
        .sort({ updatedAt: -1 })
        .limit(Number.parseInt(limit))
        .lean(),

      // School Program completed appointments
      SchoolProgram.find({ status: "completed" })
        .populate({
          path: "patientid",
          select: "name phone",
          model: "Patient",
        })
        .select("patientid date time description status updatedAt unicValue")
        .sort({ updatedAt: -1 })
        .limit(Number.parseInt(limit))
        .lean(),
    ])

    // Transform and combine all appointments
    const allAppointments = []

    // Add Full Program appointments - Use subscriptionEndDate as completion date
    fullProgramAppointments.forEach((appointment) => {
      allAppointments.push({
        id: appointment._id,
        patientId: appointment.patientid?._id,
        patientName: appointment.patientid?.name || "Unknown Patient",
        patientPhone: appointment.patientid?.phone || "N/A",
        programType: "Full Program",
        description: appointment.description,
        appointmentDate: appointment.date,
        appointmentTime: appointment.time,
        completedDate: appointment.subscriptionEndDate, // Use subscription end date as completion
        status: "Completed",
        programDetails: {
          type: "full_program",
          originalType: appointment.programType || "full_program",
          subscriptionEndDate: appointment.subscriptionEndDate,
        },
      })
    })

    // Add Single Program appointments
    singleProgramAppointments.forEach((appointment) => {
      allAppointments.push({
        id: appointment._id,
        patientId: appointment.patientid?._id,
        patientName: appointment.patientid?.name || "Unknown Patient",
        patientPhone: appointment.patientid?.phone || "N/A",
        programType: "Single Session",
        description: appointment.description,
        appointmentDate: appointment.date,
        appointmentTime: appointment.time,
        completedDate: appointment.updatedAt,
        status: "Completed",
        programDetails: {
          type: "single_session",
          services: appointment.programkind || [],
        },
      })
    })

    // Add School Program appointments
    schoolProgramAppointments.forEach((appointment) => {
      allAppointments.push({
        id: appointment._id,
        patientId: appointment.patientid?._id,
        patientName: appointment.patientid?.name || "Unknown Patient",
        patientPhone: appointment.patientid?.phone || "N/A",
        programType: "School Evaluation",
        description: appointment.description,
        appointmentDate: appointment.date,
        appointmentTime: appointment.time,
        completedDate: appointment.updatedAt,
        status: "Completed",
        programDetails: {
          type: "school_evaluation",
          unicValue: appointment.unicValue,
        },
      })
    })

    // Sort all appointments by completion date (most recent first)
    allAppointments.sort((a, b) => new Date(b.completedDate) - new Date(a.completedDate))

    // Limit to requested number
    const limitedAppointments = allAppointments.slice(0, Number.parseInt(limit))

    // Calculate summary statistics
    const summary = {
      totalCompleted: allAppointments.length,
      fullProgramCount: fullProgramAppointments.length,
      singleSessionCount: singleProgramAppointments.length,
      schoolEvaluationCount: schoolProgramAppointments.length,
      uniquePatients: new Set(allAppointments.map((apt) => apt.patientId?.toString()).filter(Boolean)).size,
    }

    console.log(`Found ${allAppointments.length} completed appointments across all program types`)

    res.status(200).json({
      success: true,
      appointments: limitedAppointments,
      summary,
      lastUpdated: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Error fetching latest completed appointments:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching completed appointments",
      error: error.message,
      appointments: [],
      summary: {
        totalCompleted: 0,
        fullProgramCount: 0,
        singleSessionCount: 0,
        schoolEvaluationCount: 0,
        uniquePatients: 0,
      },
    })
  }
})

// NEW ENDPOINT: Get dashboard statistics (total students, doctors, accountants)
router.get("/dashboard-statistics", async (req, res) => {
  try {
    const [totalStudents, totalDoctors, totalAccountants] = await Promise.all([
      Patient.countDocuments(),
      Doctor.countDocuments(),
      Accountant.countDocuments(),
    ])

    res.status(200).json({
      success: true,
      statistics: {
        totalStudents,
        totalDoctors,
        totalAccountants,
      },
    })
  } catch (error) {
    console.error("Error fetching dashboard statistics:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching dashboard statistics",
      error: error.message,
      statistics: {
        totalStudents: 0,
        totalDoctors: 0,
        totalAccountants: 0,
      },
    })
  }
})

// Get all cash on delivery records
router.get("/cash-on-delivery-records", async (req, res) => {
  try {
    console.log("Fetching cash on delivery records...")

    const cashOnDeliveryRecords = []

    // Search in all program types for cash on delivery records
    const fullPrograms = await FullProgram.find({
      paymentStatus: { $in: ["CASH_ON_DELIVERY", "FULLY_PAID"] }, // Include fully paid if it was COD
      paymentMethod: "CASH_ON_DELIVERY",
    }).populate("patientid", "name email")

    const singlePrograms = await SingleProgram.find({
      paymentStatus: { $in: ["CASH_ON_DELIVERY", "FULLY_PAID"] }, // Include fully paid if it was COD
      paymentMethod: "CASH_ON_DELIVERY",
    }).populate("patientid", "name email")

    const schoolPrograms = await SchoolProgram.find({
      paymentStatus: { $in: ["CASH_ON_DELIVERY", "FULLY_PAID"] }, // Include fully paid if it was COD
      paymentMethod: "CASH_ON_DELIVERY",
    }).populate("patientid", "name email")

    // Format full programs
    fullPrograms.forEach((program) => {
      cashOnDeliveryRecords.push({
        _id: program._id,
        programType: "full_program",
        patientId: program.patientid?._id,
        patientName: program.patientid?.name || "Unknown Patient",
        patientEmail: program.patientid?.email,
        date: program.date,
        time: program.time,
        totalAmount: program.totalAmount || 5000,
        paidAmount: program.paidAmount || 0,
        remainingAmount: program.remainingAmount || program.totalAmount,
        paymentStatus: program.paymentStatus,
        paymentMethod: program.paymentMethod,
        createdAt: program.createdAt || program.date,
      })
    })

    // Format single programs
    singlePrograms.forEach((program) => {
      cashOnDeliveryRecords.push({
        _id: program._id,
        programType: "single_session",
        patientId: program.patientid?._id,
        patientName: program.patientid?.name || "Unknown Patient",
        patientEmail: program.patientid?.email,
        date: program.date,
        time: program.time,
        totalAmount: program.totalAmount || 100,
        paidAmount: program.paidAmount || 0,
        remainingAmount: program.remainingAmount || program.totalAmount,
        paymentStatus: program.paymentStatus,
        paymentMethod: program.paymentMethod,
        programKind: program.programkind,
        createdAt: program.createdAt || program.date,
      })
    })

    // Format school programs
    schoolPrograms.forEach((program) => {
      cashOnDeliveryRecords.push({
        _id: program._id,
        programType: "school_evaluation",
        patientId: program.patientid?._id,
        patientName: program.patientid?.name || "Unknown Patient",
        patientEmail: program.patientid?.email,
        date: program.date,
        time: program.time,
        totalAmount: program.totalAmount || 400,
        paidAmount: program.paidAmount || 0,
        remainingAmount: program.remainingAmount || program.totalAmount,
        paymentStatus: program.paymentStatus,
        paymentMethod: program.paymentMethod,
        unicValue: program.unicValue,
        createdAt: program.createdAt || program.date,
      })
    })

    // Sort by creation date (newest first)
    cashOnDeliveryRecords.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))

    console.log(`Found ${cashOnDeliveryRecords.length} cash on delivery records`)

    res.status(200).json({
      message: "Cash on delivery records fetched successfully",
      records: cashOnDeliveryRecords,
      total: cashOnDeliveryRecords.length,
    })
  } catch (error) {
    console.error("Error fetching cash on delivery records:", error)
    res.status(500).json({
      message: "Error fetching cash on delivery records",
      error: error.message,
    })
  }
})

// Complete cash on delivery payment
router.post("/complete-cash-on-delivery-payment", async (req, res) => {
  try {
    console.log("Completing cash on delivery payment:", req.body)

    const { programId, programType, totalAmount } = req.body

    if (!programId || !programType || !totalAmount) {
      return res.status(400).json({
        message: "Missing required fields: programId, programType, totalAmount",
      })
    }

    let Model
    switch (programType) {
      case "full_program":
        Model = FullProgram
        break
      case "single_session":
        Model = SingleProgram
        break
      case "school_evaluation":
        Model = SchoolProgram
        break
      default:
        return res.status(400).json({
          message: "Invalid program type",
        })
    }

    // Find the program
    const program = await Model.findById(programId).populate("patientid", "name email")

    if (!program) {
      return res.status(404).json({
        message: "Program not found",
      })
    }

    // If it was previously marked as pending COD, we can now complete it.
    if (program.paymentStatus !== "CASH_ON_DELIVERY" && program.paymentStatus !== "PENDING") {
      return res.status(400).json({
        message: `Cannot complete payment. Current status is: ${program.paymentStatus}`,
      })
    }

    // Update program payment status
    program.paidAmount = totalAmount
    program.remainingAmount = 0
    program.paymentStatus = "FULLY_PAID"
    program.paymentMethod = "CASH" // Change from CASH_ON_DELIVERY to CASH

    await program.save()

    // Create money record for the completed payment
    const moneyRecord = new Money({
      patientId: program.patientid._id,
      programId: programId,
      price: totalAmount,
      status: "completed",
      invoiceId: `COD-${Date.now()}`,
      programType: programType,
      comment: `Cash on delivery payment completed for ${programType} - ${program.patientid.name}`,
    })

    await moneyRecord.save()

    console.log("Cash on delivery payment completed successfully:", {
      programId,
      programType,
      totalAmount,
      patientName: program.patientid.name,
    })

    res.status(200).json({
      message: "Cash on delivery payment completed successfully",
      program: {
        _id: program._id,
        programType,
        patientName: program.patientid.name,
        totalAmount,
        paymentStatus: program.paymentStatus,
        paymentMethod: program.paymentMethod,
      },
      moneyRecord: {
        _id: moneyRecord._id,
        invoiceId: moneyRecord.invoiceId,
        price: moneyRecord.price,
        status: moneyRecord.status,
      },
    })
  } catch (error) {
    console.error("Error completing cash on delivery payment:", error)
    res.status(500).json({
      message: "Error completing cash on delivery payment",
      error: error.message,
    })
  }
})

// ADDED ENDPOINT: Fetch pending cash payments
router.get("/pending-cash-payments", async (req, res) => {
  try {
    console.log("Fetching pending cash payments...")

    // Fetch from all three program types
    const [fullPrograms, singleSessions, schoolEvaluations] = await Promise.all([
      FullProgram.find({
        paymentMethod: "CASH",
        paymentStatus: "PENDING",
        status: { $ne: "cancelled" },
      })
        .populate("patientid", "name email phone")
        .lean(),
      SingleProgram.find({
        paymentMethod: "CASH",
        paymentStatus: "PENDING",
        status: { $ne: "cancelled" },
      })
        .populate("patientid", "name email phone")
        .lean(),
      SchoolProgram.find({
        paymentMethod: "CASH",
        paymentStatus: "PENDING",
        status: { $ne: "cancelled" },
      })
        .populate("patientid", "name email phone")
        .lean(),
    ])

    // Format the data
    const formatPayment = (program, programType) => ({
      programId: program._id,
      programType: programType,
      patientId: program.patientid?._id,
      patientName: program.patientid?.name || "Unknown",
      patientEmail: program.patientid?.email || "",
      date: program.date,
      time: program.time,
      amount: programType === "full_program" ? 1000 : program.totalAmount || 0, // Assuming initial payment for full program is 1000
      description: program.description,
      status: program.status,
    })

    const allPayments = [
      ...fullPrograms.map((p) => formatPayment(p, "full_program")),
      ...singleSessions.map((p) => formatPayment(p, "single_session")),
      ...schoolEvaluations.map((p) => formatPayment(p, "school_evaluation")),
    ]

    // Sort by date (most recent first)
    allPayments.sort((a, b) => new Date(b.date) - new Date(a.date))

    res.status(200).json({
      success: true,
      payments: allPayments,
      count: allPayments.length,
    })
  } catch (error) {
    console.error("Error fetching pending cash payments:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching pending cash payments",
      error: error.message,
    })
  }
})

// ADDED ENDPOINT: Confirm cash payment
router.post("/confirm-cash-payment", async (req, res) => {
  try {
    const { programId, programType, patientId, patientName, amount } = req.body

    if (!programId || !programType || !patientId || !amount) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields",
      })
    }

    // Get the appropriate model
    let Model
    switch (programType) {
      case "full_program":
        Model = FullProgram
        break
      case "single_session":
        Model = SingleProgram
        break
      case "school_evaluation":
        Model = SchoolProgram
        break
      default:
        return res.status(400).json({
          success: false,
          message: "Invalid program type",
        })
    }

    // Find the program
    const program = await Model.findById(programId)
    if (!program) {
      return res.status(404).json({
        success: false,
        message: "Program not found",
      })
    }

    // Create money record
    const moneyRecord = new Money({
      patientId: patientId,
      programId: programId,
      price: amount,
      status: "completed",
      invoiceId: `INV-CASH-${Date.now()}`,
      programType: programType,
      comment: `Cash payment confirmed at center for ${programType} - ${patientName}`,
    })
    await moneyRecord.save()

    // Update program payment status
    if (programType === "full_program") {
      // For full program, only mark the initial 1000 EGP as paid and update status
      // Note: This assumes the initial payment is 1000. Adjust if the logic for full program initial payment differs.
      program.paidAmount = 1000
      program.remainingAmount = 4000 // Assuming total is 5000. Adjust if needed.
      program.paymentStatus = "PARTIALLY_PAID" // Mark as partially paid as the full amount is not yet confirmed
      program.paymentMethod = "CASH" // Update payment method
    } else {
      // For single session and school evaluation, mark as fully paid
      program.paidAmount = amount
      program.remainingAmount = 0
      program.paymentStatus = "FULLY_PAID"
      program.paymentMethod = "CASH" // Update payment method
    }

    await program.save()

    res.status(200).json({
      success: true,
      message: "Cash payment confirmed successfully",
      moneyRecord: moneyRecord,
      program: program,
    })
  } catch (error) {
    console.error("Error confirming cash payment:", error)
    res.status(500).json({
      success: false,
      message: "Error confirming cash payment",
      error: error.message,
    })
  }
})

// ADDED ENDPOINT: Cancel cash appointment
router.post("/cancel-cash-appointment", async (req, res) => {
  try {
    const { programId, programType } = req.body

    if (!programId || !programType) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields",
      })
    }

    // Get the appropriate model
    let Model
    switch (programType) {
      case "full_program":
        Model = FullProgram
        break
      case "single_session":
        Model = SingleProgram
        break
      case "school_evaluation":
        Model = SchoolProgram
        break
      default:
        return res.status(400).json({
          success: false,
          message: "Invalid program type",
        })
    }

    // Find and update the program
    const program = await Model.findById(programId)
    if (!program) {
      return res.status(404).json({
        success: false,
        message: "Program not found",
      })
    }

    program.status = "cancelled"
    await program.save()

    res.status(200).json({
      success: true,
      message: "Appointment cancelled successfully",
      program: program,
    })
  } catch (error) {
    console.error("Error cancelling appointment:", error)
    res.status(500).json({
      success: false,
      message: "Error cancelling appointment",
      error: error.message,
    })
  }
})

router.post("/upload-bank-transfer-screenshot", bankTransferUpload.single("screenshot"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "No file uploaded",
      })
    }

    const filePath = `/uploads/bank-transfers/${req.file.filename}`

    res.status(200).json({
      success: true,
      message: "Screenshot uploaded successfully",
      filePath: filePath,
    })
  } catch (error) {
    console.error("Error uploading bank transfer screenshot:", error)
    res.status(500).json({
      success: false,
      message: "Error uploading screenshot",
      error: error.message,
    })
  }
})

router.get("/pending-bank-transfer-payments", async (req, res) => {
  try {
    console.log("Fetching pending bank transfer payments...")

    // Fetch from all three program types
    const [fullPrograms, singleSessions, schoolEvaluations] = await Promise.all([
      FullProgram.find({
        paymentMethod: "BANK_TRANSFER",
        paymentStatus: "PENDING",
        status: { $ne: "cancelled" },
      })
        .populate("patientid", "name email phone")
        .lean(),
      SingleProgram.find({
        paymentMethod: "BANK_TRANSFER",
        paymentStatus: "PENDING",
        status: { $ne: "cancelled" },
      })
        .populate("patientid", "name email phone")
        .lean(),
      SchoolProgram.find({
        paymentMethod: "BANK_TRANSFER",
        paymentStatus: "PENDING",
        status: { $ne: "cancelled" },
      })
        .populate("patientid", "name email phone")
        .lean(),
    ])

    // Format the data
    const formatPayment = (program, programType) => ({
      programId: program._id,
      programType: programType,
      patientId: program.patientid?._id,
      patientName: program.patientid?.name || "Unknown",
      patientEmail: program.patientid?.email || "",
      date: program.date,
      time: program.time,
      amount: programType === "full_program" ? 1000 : program.totalAmount || 0,
      description: program.description,
      status: program.status,
      transferScreenshot: program.transferScreenshot || null,
    })

    const allPayments = [
      ...fullPrograms.map((p) => formatPayment(p, "full_program")),
      ...singleSessions.map((p) => formatPayment(p, "single_session")),
      ...schoolEvaluations.map((p) => formatPayment(p, "school_evaluation")),
    ]

    // Sort by date (most recent first)
    allPayments.sort((a, b) => new Date(b.date) - new Date(a.date))

    res.status(200).json({
      success: true,
      payments: allPayments,
      count: allPayments.length,
    })
  } catch (error) {
    console.error("Error fetching pending bank transfer payments:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching pending bank transfer payments",
      error: error.message,
    })
  }
})

router.post("/confirm-bank-transfer-payment", async (req, res) => {
  try {
    const { programId, programType, patientId, patientName, amount } = req.body

    if (!programId || !programType || !patientId || !amount) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields",
      })
    }

    // Get the appropriate model
    let Model
    switch (programType) {
      case "full_program":
        Model = FullProgram
        break
      case "single_session":
        Model = SingleProgram
        break
      case "school_evaluation":
        Model = SchoolProgram
        break
      default:
        return res.status(400).json({
          success: false,
          message: "Invalid program type",
        })
    }

    const program = await Model.findById(programId)
    if (!program) {
      return res.status(404).json({
        success: false,
        message: "Program not found",
      })
    }

    // Create money record
    const moneyRecord = new Money({
      patientId: patientId,
      programId: programId,
      price: amount,
      status: "completed",
      invoiceId: `INV-BANK-${Date.now()}`,
      programType: programType,
      comment: `Bank transfer payment confirmed for ${programType} - ${patientName}`,
    })
    await moneyRecord.save()

    // Update program payment status
    if (programType === "full_program") {
      program.paidAmount = 1000
      program.remainingAmount = 4000
      program.paymentStatus = "PARTIALLY_PAID"
      program.paymentMethod = "BANK_TRANSFER"
    } else {
      program.paidAmount = amount
      program.remainingAmount = 0
      program.paymentStatus = "FULLY_PAID"
      program.paymentMethod = "BANK_TRANSFER"
    }

    await program.save()

    const programTypeFormatted = programType
      .replace(/_/g, " ")
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")

    const formattedDate = new Date(program.date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })

    // Send notification to patient
    const notification = await Notification.create({
      receiverId: patientId,
      rule: "Patient",
      title: "Payment Received",
      titleAr: "تم استلام الدفع",
      message: `We have received your bank transfer payment. Your ${programTypeFormatted} appointment on ${formattedDate} at ${program.time} is now confirmed. Thank you!`,
      messageAr: `لقد استلمنا دفعتك عبر التحويل البنكي. تم تأكيد موعدك في ${programTypeFormatted} بتاريخ ${formattedDate} في الساعة ${program.time}. شكراً لك!`,
      type: "confirmed",
    })

    // Emit socket notification for patient
    const io = req.app.get("io")
    const onlineUsers = req.app.get("onlineUsers")
    const socketId = onlineUsers.get(patientId)

    if (socketId) {
      const unreadCount = await Notification.countDocuments({
        receiverId: patientId,
        isRead: false,
      })
      const recentNotifications = await Notification.find({ receiverId: patientId }).sort({ createdAt: -1 }).limit(10)

      io.to(socketId).emit("newNotification", {
        count: unreadCount,
        notifications: recentNotifications,
      })
    }

    try {
      const Admin = require("../models/users/Admin")
      const HeadDoctor = require("../models/users/HeadDoctor")

      const adminIds = (await Admin.find().distinct("_id")).map((id) => id.toString())
      const headDoctorIds = (await HeadDoctor.find().distinct("_id")).map((id) => id.toString())
      const allRecipientIds = [...adminIds, ...headDoctorIds]

      if (allRecipientIds.length > 0) {
        const adminNotifications = adminIds.map((id) => ({
          receiverId: id,
          rule: "Admin",
          title: "Bank Transfer Confirmed",
          message: `Bank transfer payment from ${patientName} for ${programTypeFormatted} on ${formattedDate} at ${program.time} has been confirmed.`,
          type: "confirmed",
        }))

        const headDoctorNotifications = headDoctorIds.map((id) => ({
          receiverId: id,
          rule: "HeadDoctor",
          title: "Bank Transfer Confirmed",
          message: `Bank transfer payment from ${patientName} for ${programTypeFormatted} on ${formattedDate} at ${program.time} has been confirmed.`,
          type: "confirmed",
        }))

        await Notification.insertMany([...adminNotifications, ...headDoctorNotifications])

        // Emit to online admins and head doctors
        allRecipientIds.forEach(async (id) => {
          const recipientSocketId = onlineUsers.get(id)
          if (recipientSocketId) {
            const unreadCount = await Notification.countDocuments({
              receiverId: id,
              isRead: false,
            })
            const recentNotifications = await Notification.find({ receiverId: id }).sort({ createdAt: -1 }).limit(10)

            io.to(recipientSocketId).emit("newNotification", {
              count: unreadCount,
              notifications: recentNotifications,
            })
          }
        })
      }
    } catch (notificationError) {
      console.error("Error sending admin/headdoctor notifications:", notificationError)
    }

    res.status(200).json({
      success: true,
      message: "Bank transfer payment confirmed successfully",
    })
  } catch (error) {
    console.error("Error confirming bank transfer payment:", error)
    res.status(500).json({
      success: false,
      message: "Error confirming bank transfer payment",
      error: error.message,
    })
  }
})

router.post("/reject-bank-transfer-payment", async (req, res) => {
  try {
    const { programId, programType, patientId, patientName } = req.body

    console.log("[v0] Reject payment request:", { programId, programType, patientId, patientName })

    if (!programId || !programType || !patientId) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields",
      })
    }

    // Get the appropriate model
    let Model
    switch (programType) {
      case "full_program":
        Model = FullProgram
        break
      case "single_session":
        Model = SingleProgram
        break
      case "school_evaluation":
        Model = SchoolProgram
        break
      default:
        return res.status(400).json({
          success: false,
          message: "Invalid program type",
        })
    }

    const program = await Model.findById(programId)
    if (!program) {
      return res.status(404).json({
        success: false,
        message: "Program not found",
      })
    }

    console.log("[v0] Program found:", program._id)

    // Update program to cancelled status
    program.status = "cancelled"
    program.paymentStatus = "PENDING"
    program.transferScreenshot = null
    await program.save()

    console.log("[v0] Program updated to cancelled")

    const programTypeFormatted = programType
      .replace(/_/g, " ")
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")

    const formattedDate = new Date(program.date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })

    console.log("[v0] Creating notification for patient:", patientId)

    // Send notification to patient
    const notification = await Notification.create({
      receiverId: patientId,
      rule: "Patient",
      title: "Payment Not Received",
      titleAr: "لم يتم استلام الدفع",
      message: `We did not receive your bank transfer payment. Your ${programTypeFormatted} appointment on ${formattedDate} at ${program.time} has been cancelled. Please contact us for assistance.`,
      messageAr: `لم نستلم دفعتك عبر التحويل البنكي. تم إلغاء موعدك في ${programTypeFormatted} بتاريخ ${formattedDate} في الساعة ${program.time}. يرجى الاتصال بنا للمساعدة.`,
      type: "cancelled",
    })

    console.log("[v0] Notification created:", notification._id)

    // Emit socket notification for patient
    const io = req.app.get("io")
    const onlineUsers = req.app.get("onlineUsers")

    console.log("[v0] IO instance:", !!io)
    console.log("[v0] Online users map:", !!onlineUsers)

    const socketId = onlineUsers.get(patientId)
    console.log("[v0] Socket ID for patient:", socketId)

    if (socketId) {
      const unreadCount = await Notification.countDocuments({
        receiverId: patientId,
        isRead: false,
      })
      const recentNotifications = await Notification.find({ receiverId: patientId }).sort({ createdAt: -1 }).limit(10)

      console.log("[v0] Emitting notification to socket:", socketId, "Unread count:", unreadCount)

      io.to(socketId).emit("newNotification", {
        count: unreadCount,
        notifications: recentNotifications,
      })

      console.log("[v0] Notification emitted successfully")
    } else {
      console.log("[v0] Patient is not online, notification saved to database only")
    }

    try {
      const Admin = require("../models/users/Admin")
      const HeadDoctor = require("../models/users/HeadDoctor")

      const adminIds = (await Admin.find().distinct("_id")).map((id) => id.toString())
      const headDoctorIds = (await HeadDoctor.find().distinct("_id")).map((id) => id.toString())
      const allRecipientIds = [...adminIds, ...headDoctorIds]

      if (allRecipientIds.length > 0) {
        const adminNotifications = adminIds.map((id) => ({
          receiverId: id,
          rule: "Admin",
          title: "Bank Transfer Rejected",
          message: `Bank transfer payment from ${patientName} for ${programTypeFormatted} on ${formattedDate} at ${program.time} has been rejected.`,
          type: "cancelled",
        }))

        const headDoctorNotifications = headDoctorIds.map((id) => ({
          receiverId: id,
          rule: "HeadDoctor",
          title: "Bank Transfer Rejected",
          message: `Bank transfer payment from ${patientName} for ${programTypeFormatted} on ${formattedDate} at ${program.time} has been rejected.`,
          type: "cancelled",
        }))

        await Notification.insertMany([...adminNotifications, ...headDoctorNotifications])

        // Emit to online admins and head doctors
        allRecipientIds.forEach(async (id) => {
          const recipientSocketId = onlineUsers.get(id)
          if (recipientSocketId) {
            const unreadCount = await Notification.countDocuments({
              receiverId: id,
              isRead: false,
            })
            const recentNotifications = await Notification.find({ receiverId: id }).sort({ createdAt: -1 }).limit(10)

            io.to(recipientSocketId).emit("newNotification", {
              count: unreadCount,
              notifications: recentNotifications,
            })
          }
        })
      }
    } catch (notificationError) {
      console.error("Error sending admin/headdoctor notifications:", notificationError)
    }

    res.status(200).json({
      success: true,
      message: "Bank transfer payment rejected successfully",
    })
  } catch (error) {
    console.error("[v0] Error rejecting bank transfer payment:", error)
    res.status(500).json({
      success: false,
      message: "Error rejecting bank transfer payment",
      error: error.message,
    })
  }
})

router.post("/cancel-bank-transfer-appointment", async (req, res) => {
  try {
    const { programId, programType } = req.body

    if (!programId || !programType) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields",
      })
    }

    // Get the appropriate model
    let Model
    switch (programType) {
      case "full_program":
        Model = FullProgram
        break
      case "single_session":
        Model = SingleProgram
        break
      case "school_evaluation":
        Model = SchoolProgram
        break
      default:
        return res.status(400).json({
          success: false,
          message: "Invalid program type",
        })
    }

    // Find and update the program
    const program = await Model.findById(programId)
    if (!program) {
      return res.status(404).json({
        success: false,
        message: "Program not found",
      })
    }

    const patientId = program.patientid.toString()
    const patientName = program.patientName || "Patient"

    program.status = "cancelled"
    await program.save()

    await Notification.create({
      receiverId: patientId,
      rule: "Patient",
      title: "Payment Not Received",
      titleAr: "لم يتم استلام الدفع",
      message: `We did not receive your bank transfer payment. Your appointment has been cancelled. Please contact us if you have any questions.`,
      messageAr: `لم نستلم دفعتك عبر التحويل البنكي. تم إلغاء موعدك. يرجى الاتصال بنا إذا كان لديك أي أسئلة.`,
      type: "cancelled",
      isRead: false,
    })

    const io = req.app.get("io")
    const onlineUsers = req.app.get("onlineUsers")

    if (io && onlineUsers) {
      const socketId = onlineUsers.get(patientId)
      if (socketId) {
        const count = await Notification.countDocuments({
          receiverId: patientId,
          isRead: false,
        })
        const notifications = await Notification.find({
          receiverId: patientId,
        })
          .sort({ createdAt: -1 })
          .limit(10)

        io.to(socketId).emit("newNotification", {
          count,
          notifications,
        })
      }
    }

    res.status(200).json({
      success: true,
      message: "Bank transfer appointment cancelled successfully",
      program: program,
    })
  } catch (error) {
    console.error("Error cancelling bank transfer appointment:", error)
    res.status(500).json({
      success: false,
      message: "Error cancelling bank transfer appointment",
      error: error.message,
    })
  }
})

router.post("/forgot-password", passwordResetLimiter, async (req, res) => {
  try {
    const { email } = req.body

    if (!email) {
      return res.status(400).json({ message: "Email is required" })
    }

    const patient = await Patient.findOne({ email: email.toLowerCase() })

    if (!patient) {
      // Don't reveal if email exists for security
      return res.json({ message: "If the email exists, a password reset link has been sent" })
    }

    // Generate unique reset token
    const resetToken = crypto.randomBytes(32).toString("hex")

    // Save reset token to database
    await PasswordReset.create({
      email: patient.email,
      token: resetToken,
      expiresAt: new Date(Date.now() + 3600000), // 1 hour
    })

    // Create reset URL
    const resetUrl = `${process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000"}/clientportal/reset-password?token=${resetToken}`

    // Email content
    const emailContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333;">Password Reset Request</h2>
        <p>You requested to reset your password. Click the button below to reset it:</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetUrl}"
             style="background-color: #0066cc; color: white; padding: 12px 30px;
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            Reset Password
          </a>
        </div>
        <p style="color: #666; font-size: 14px;">
          This link will expire in 1 hour. If you didn't request this, please ignore this email.
        </p>
        <p style="color: #666; font-size: 14px;">
          Or copy and paste this link: <br/>
          <a href="${resetUrl}">${resetUrl}</a>
        </p>
      </div>
    `

    // Send email
    await transporter.sendMail({
      from: process.env.NODE_MAILER_USER,
      to: patient.email,
      subject: "Password Reset Request",
      html: emailContent,
    })

    res.json({ message: "If the email exists, a password reset link has been sent" })
  } catch (err) {
    console.error("Error in forgot-password:", err)
    res.status(500).json({ message: "Error processing password reset request" })
  }
})

router.post("/reset-password", async (req, res) => {
  try {
    const { token, newPassword } = req.body

    if (!token || !newPassword) {
      return res.status(400).json({ message: "Token and new password are required" })
    }

    // Validate password strength
    if (newPassword.length < 8) {
      return res.status(400).json({ message: "Password must be at least 8 characters long" })
    }

    // Find valid reset token
    const resetRecord = await PasswordReset.findOne({
      token,
      used: false,
      expiresAt: { $gt: new Date() },
    })

    if (!resetRecord) {
      return res.status(400).json({ message: "Invalid or expired reset token" })
    }

    // Find patient
    const patient = await Patient.findOne({ email: resetRecord.email })

    if (!patient) {
      return res.status(404).json({ message: "Patient not found" })
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10)

    // Update patient password
    patient.password = hashedPassword
    await patient.save()

    // Mark token as used
    resetRecord.used = true
    await resetRecord.save()

    res.json({ message: "Password reset successfully" })
  } catch (err) {
    console.error("Error in reset-password:", err)
    res.status(500).json({ message: "Error resetting password" })
  }
})

module.exports = router
