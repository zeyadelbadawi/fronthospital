const express = require("express")
const router = express.Router()
const formidable = require("formidable")
const fs = require("fs")
const path = require("path")
const { v4: uuidv4 } = require("uuid")
const SpecialEducationPlanS = require("../models/single/Special-EducationC/SpecialEducationPlanS")
const PatientSpecialEducationAssignmentS = require("../models/single/Special-EducationC/PatientSpecialEducationAssignmentS")
const Patient = require("../models/users/Patient")
const AssignmentService = require("../services/assignmentService")

// Enhanced Add special_education Assignment - allows multiple assignments
router.post("/assign-to-Special-Education", async (req, res) => {
  const { patientId, notes } = req.body

  if (!patientId) {
    return res.status(400).json({ message: "Invalid or missing patient ID" })
  }

  try {
    const result = await AssignmentService.createAssignment("special_education", patientId, notes)

    if (result.success) {
      res.status(201).json({
        message: result.message,
        assignment: result.assignment,
      })
    } else {
      res.status(400).json({
        message: "Error assigning patient to special_education",
        error: result.error,
      })
    }
  } catch (err) {
    res.status(500).json({
      message: "Error assigning patient to special_education",
      error: err.message,
    })
  }
})

// Enhanced Get special_education Assignments with session tracking
router.get("/Special-Education-assignments", async (req, res) => {
  const { page = 1, limit = 10, search = "", status = "" } = req.query

  try {
    const query = {}

    // Filter by status if provided
    if (status) {
      query.status = status
    }

    if (search) {
      const patients = await Patient.find({
        name: { $regex: search, $options: "i" },
      }).select("_id")

      if (patients.length > 0) {
        query.patient = { $in: patients.map((p) => p._id) }
      } else {
        return res.status(200).json({
          assignments: [],
          totalPages: 0,
          currentPage: Number.parseInt(page),
          totalAssignments: 0,
        })
      }
    }

    const assignments = await PatientSpecialEducationAssignmentS.find(query)
      .populate({
        path: "patient",
        select: "name email phone",
        model: "Patient",
      })
      .populate({
        path: "programId",
        select: "date time description programkind paymentStatus paymentMethod totalAmount paidAmount",
        model: "SingleProgram",
      })
      .skip((Number.parseInt(page) - 1) * Number.parseInt(limit))
      .limit(Number.parseInt(limit))
      .sort({ assignedDate: -1, sessionNumber: -1 })

    const totalAssignments = await PatientSpecialEducationAssignmentS.countDocuments(query)

    res.status(200).json({
      assignments,
      totalPages: Math.ceil(totalAssignments / Number.parseInt(limit)),
      currentPage: Number.parseInt(page),
      totalAssignments,
    })
  } catch (err) {
    console.error("Error fetching special_education assignments:", err)
    res.status(500).json({ message: "Error fetching special_education assignments" })
  }
})

// Complete special_education Assignment
router.put("/complete-assignment/:assignmentId", async (req, res) => {
  const { assignmentId } = req.params

  try {
    const result = await AssignmentService.completeAssignment("special_education", null, assignmentId)

    if (result.success) {
      res.status(200).json({
        message: result.message,
        assignment: result.assignment,
      })
    } else {
      res.status(404).json({
        message: result.error,
      })
    }
  } catch (err) {
    res.status(500).json({
      message: "Error completing assignment",
      error: err.message,
    })
  }
})

// Unassign from special_education (now marks as cancelled instead of deleting)
router.delete("/unassign-from-Special-Education/:patientId", async (req, res) => {
  const { assignmentId } = req.params

  try {
    const assignment = await PatientSpecialEducationAssignmentS.findByIdAndUpdate(
      assignmentId,
      {
        status: "cancelled",
        cancelledAt: new Date(),
      },
      { new: true },
    )

    if (!assignment) {
      return res.status(404).json({ message: "Assignment not found" })
    }

    res.status(200).json({
      message: "Assignment cancelled successfully",
      assignment,
    })
  } catch (err) {
    res.status(500).json({ message: "Error cancelling assignment" })
  }
})

router.post("/upload-plan/:patientId", (req, res) => {
  const form = new formidable.IncomingForm()
  form.keepExtensions = true
  form.maxFileSize = 10 * 1024 * 1024 // 10MB

  const uploadDir = path.join(__dirname, "../uploads/Special-EducationS/plan")
  if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })
  form.uploadDir = uploadDir

  const { patientId } = req.params

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err)
      return res.status(500).json({ message: "Error parsing uploaded file" })
    }

    if (!patientId) {
      console.log("Patient ID is missing!")
      return res.status(400).json({ message: "Patient ID is required" })
    }

    console.log("Patient ID from backend:", patientId)

    const file = files.document[0]
    const tempFilePath = file.filepath
    const originalFileName = file.originalFilename
    const uniqueFileName = `${uuidv4()}${path.extname(originalFileName)}`
    const finalFilePath = path.join(uploadDir, uniqueFileName)

    fs.renameSync(tempFilePath, finalFilePath)

    try {
      const plan = await SpecialEducationPlanS.findOneAndUpdate(
        { patient: patientId },
        {
          filePath: uniqueFileName,
          fileName: originalFileName,
          title: originalFileName.replace(/\.[^/.]+$/, ""),
        },
        { new: true, upsert: true },
      )

      console.log("Uploaded Plan Record:", plan)

      res.status(200).json({
        title: originalFileName.replace(/\.[^/.]+$/, ""),
        fileName: originalFileName,
        filePath: uniqueFileName,
        message: "Plan document uploaded and linked successfully!",
        plan: plan,
      })
    } catch (error) {
      console.error("Error linking document to plan:", error)
      res.status(500).json({ message: "Error linking document to plan" })
    }
  })
})

// Get special_education Plan for a patient
router.get("/plan/:patientId", async (req, res) => {
  const { patientId } = req.params

  try {
    const plan = await SpecialEducationPlanS.findOne({ patient: patientId }).sort({ lastModified: -1 })

    if (!plan) {
      return res.status(404).json({ message: "No plan found for this patient" })
    }

    res.status(200).json(plan)
  } catch (err) {
    res.status(500).json({ message: "Error fetching special_education plan" })
  }
})

// Create special_education Plan
router.post("/plan", async (req, res) => {
  const { patient, title, content, createdBy } = req.body

  try {
    const plan = new SpecialEducationPlanS({
      patient,
      title,
      content,
      createdBy: createdBy || "System",
      lastModified: new Date(),
    })

    await plan.save()
    res.status(201).json(plan)
  } catch (err) {
    res.status(500).json({ message: "Error creating special_education plan" })
  }
})

// Update special_education Plan
router.put("/plan/:planId", async (req, res) => {
  const { planId } = req.params
  const { title, content, createdBy } = req.body

  try {
    const plan = await SpecialEducationPlanS.findByIdAndUpdate(
      planId,
      { title, content, createdBy: createdBy || "System", lastModified: new Date() },
      { new: true },
    )

    if (!plan) {
      return res.status(404).json({ message: "Plan not found" })
    }

    res.status(200).json(plan)
  } catch (err) {
    res.status(500).json({ message: "Error updating special_education plan" })
  }
})

// Get special_education assignment by program ID
router.get("/assignment-by-program/:programId", async (req, res) => {
  const { programId } = req.params

  try {
    const assignment = await PatientSpecialEducationAssignmentS.findOne({
      programId: programId,
    }).populate({
      path: "patient",
      select: "name email phone",
      model: "Patient",
    })

    if (!assignment) {
      return res.status(404).json({ message: "No special_education assignment found for this program" })
    }

    res.status(200).json(assignment)
  } catch (err) {
    console.error("Error fetching special_education assignment by program:", err)
    res.status(500).json({ message: "Error fetching special_education assignment" })
  }
})

// Get special_education plan with file details
router.get("/plan-details/:patientId", async (req, res) => {
  const { patientId } = req.params

  try {
    const plan = await SpecialEducationPlanS.findOne({ patient: patientId }).sort({ lastModified: -1 })

    if (!plan) {
      return res.status(404).json({ message: "No special_education plan found for this patient" })
    }

    res.status(200).json(plan)
  } catch (err) {
    console.error("Error fetching special_education plan details:", err)
    res.status(500).json({ message: "Error fetching special_education plan details" })
  }
})

module.exports = router
