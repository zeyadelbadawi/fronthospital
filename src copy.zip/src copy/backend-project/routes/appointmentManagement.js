const express = require("express")
const router = express.Router()
const SingleProgram = require("../models/SingleProgram")
const FullProgram = require("../models/FullProgram")
const SchoolProgram = require("../models/SchoolProgram")
const Money = require("../models/Money")
const AssignmentService = require("../services/assignmentService")

// Get single appointment by ID
router.get("/appointment/:id", async (req, res) => {
  const { id } = req.params

  try {
    const appointment = await SingleProgram.findById(id).populate({
      path: "patientid",
      select: "name email phone age address",
      model: "Patient",
    })

    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" })
    }

    // Get related money record
    const moneyRecord = await Money.findOne({ programId: id })

    res.status(200).json({
      appointment,
      moneyRecord,
    })
  } catch (error) {
    console.error("Error fetching appointment:", error)
    res.status(500).json({
      message: "Error fetching appointment",
      error: error.message,
    })
  }
})

// Update appointment
router.put("/appointment/:id", async (req, res) => {
  const { id } = req.params
  const { date, time, description, programkind, status } = req.body

  // Validation
  if (!date || !time || !description) {
    return res.status(400).json({
      message: "Missing required fields",
      required: ["date", "time", "description"],
    })
  }

  // Validate date is not in the past
  const appointmentDate = new Date(date)
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  if (appointmentDate < today) {
    return res.status(400).json({
      message: "Appointment date cannot be in the past",
    })
  }

  try {
    const updatedAppointment = await SingleProgram.findByIdAndUpdate(
      id,
      {
        date,
        time,
        description,
        programkind: programkind || [],
        status: status || "upcoming", // <--- UPDATED: Set default status to "upcoming"
        updatedAt: new Date(),
      },
      { new: true, runValidators: true },
    ).populate({
      path: "patientid",
      select: "name email phone",
      model: "Patient",
    })

    if (!updatedAppointment) {
      return res.status(404).json({ message: "Appointment not found" })
    }

    // If services changed, update assignments
    if (programkind && Array.isArray(programkind) && programkind.length > 0) {
      const assignmentNotes = `Updated single session assignment - ${description}`
      const assignmentResults = await AssignmentService.createMultipleAssignments(
        programkind,
        updatedAppointment.patientid._id,
        assignmentNotes,
        updatedAppointment._id,
      )

      console.log("Updated assignment results:", assignmentResults)
    }

    res.status(200).json({
      message: "Appointment updated successfully",
      appointment: updatedAppointment,
    })
  } catch (error) {
    console.error("Error updating appointment:", error)
    res.status(500).json({
      message: "Error updating appointment",
      error: error.message,
    })
  }
})

// Cancel appointment (soft delete)
router.put("/appointment/:id/cancel", async (req, res) => {
  const { id } = req.params
  const { reason } = req.body

  try {
    const appointment = await SingleProgram.findById(id)
    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" })
    }

    // Check if appointment is in the future
    const appointmentDate = new Date(appointment.date)
    const now = new Date()

    if (appointmentDate < now) {
      return res.status(400).json({
        message: "Cannot cancel past appointments",
      })
    }

    // Update appointment status
    const updatedAppointment = await SingleProgram.findByIdAndUpdate(
      id,
      {
        status: "cancelled",
        cancellationReason: reason || "Cancelled by user",
        cancelledAt: new Date(),
      },
      { new: true },
    ).populate({
      path: "patientid",
      select: "name email phone",
      model: "Patient",
    })

    // Update related money record
    await Money.findOneAndUpdate(
      { programId: id },
      {
        status: "refunded",
        refundedAt: new Date(),
        refundReason: reason || "Appointment cancelled",
      },
    )

    // Cancel related assignments
    if (appointment.programkind && appointment.programkind.length > 0) {
      for (const service of appointment.programkind) {
        await AssignmentService.cancelAssignmentsByProgram(service, appointment.patientid, id)
      }
    }

    res.status(200).json({
      message: "Appointment cancelled successfully",
      appointment: updatedAppointment,
    })
  } catch (error) {
    console.error("Error cancelling appointment:", error)
    res.status(500).json({
      message: "Error cancelling appointment",
      error: error.message,
    })
  }
})

// Delete appointment (hard delete - admin only)
router.delete("/appointment/:id", async (req, res) => {
  const { id } = req.params

  try {
    const appointment = await SingleProgram.findById(id)
    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" })
    }

    // Delete related money records
    await Money.deleteMany({ programId: id })

    // Cancel related assignments
    if (appointment.programkind && appointment.programkind.length > 0) {
      for (const service of appointment.programkind) {
        await AssignmentService.cancelAssignmentsByProgram(service, appointment.patientid, id)
      }
    }

    // Delete the appointment
    await SingleProgram.findByIdAndDelete(id)

    res.status(200).json({
      message: "Appointment deleted successfully",
    })
  } catch (error) {
    console.error("Error deleting appointment:", error)
    res.status(500).json({
      message: "Error deleting appointment",
      error: error.message,
    })
  }
})

// Reschedule appointment
router.put("/appointment/:id/reschedule", async (req, res) => {
  const { id } = req.params
  const { newDate, newTime, reason } = req.body

  if (!newDate || !newTime) {
    return res.status(400).json({
      message: "New date and time are required",
    })
  }

  // Validate new date is not in the past
  const appointmentDate = new Date(newDate)
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  if (appointmentDate < today) {
    return res.status(400).json({
      message: "New appointment date cannot be in the past",
    })
  }

  try {
    const appointment = await SingleProgram.findById(id)
    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" })
    }

    // Store old date/time for history
    const oldDate = appointment.date
    const oldTime = appointment.time

    const updatedAppointment = await SingleProgram.findByIdAndUpdate(
      id,
      {
        date: newDate,
        time: newTime,
        rescheduledFrom: {
          date: oldDate,
          time: oldTime,
          reason: reason || "Rescheduled by user",
          rescheduledAt: new Date(),
        },
        status: "rescheduled",
      },
      { new: true },
    ).populate({
      path: "patientid",
      select: "name email phone",
      model: "Patient",
    })

    res.status(200).json({
      message: "Appointment rescheduled successfully",
      appointment: updatedAppointment,
    })
  } catch (error) {
    console.error("Error rescheduling appointment:", error)
    res.status(500).json({
      message: "Error rescheduling appointment",
      error: error.message,
    })
  }
})

// Mark appointment as completed
router.put("/appointment/:id/complete", async (req, res) => {
  const { id } = req.params
  const { notes } = req.body

  try {
    const appointment = await SingleProgram.findById(id)
    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" })
    }

    const updatedAppointment = await SingleProgram.findByIdAndUpdate(
      id,
      {
        status: "completed",
        completedAt: new Date(),
        completionNotes: notes || "",
      },
      { new: true },
    ).populate({
      path: "patientid",
      select: "name email phone",
      model: "Patient",
    })

    // Complete related assignments
    if (appointment.programkind && appointment.programkind.length > 0) {
      for (const service of appointment.programkind) {
        await AssignmentService.completeAssignmentsByProgram(service, appointment.patientid, id)
      }
    }

    res.status(200).json({
      message: "Appointment marked as completed",
      appointment: updatedAppointment,
    })
  } catch (error) {
    console.error("Error completing appointment:", error)
    res.status(500).json({
      message: "Error completing appointment",
      error: error.message,
    })
  }
})

module.exports = router
