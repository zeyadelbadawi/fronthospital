const express = require("express")
const router = express.Router()
const FullProgram = require("../models/FullProgram")
const PatientABAAssignment = require("../models/ABA/PatientABAAssignment")
const PatientOccupationalTherapyAssignment = require("../models/Occupational-therapy/PatientOccupationalTherapyAssignment")
const PatientPhysicalTherapyAssignment = require("../models/physicalTherapy/PatientPhysicalTherapyAssignment")
const PatientSpecialEducationAssignment = require("../models/Special-Education/PatientSpecialEducationAssignment")
const PatientSpeechAssignment = require("../models/Speech/PatientSpeechAssignment")
const PatientPsychotherapyAssignment = require("../models/psychotherapy/PatientPsychotherapyAssignment")

// POST endpoint to manually check and unassign expired subscriptions
router.post("/manual-check-subscriptions", async (req, res) => {
  try {
    const now = new Date()

    console.log(`[Subscription Checker] Running manual check at: ${now.toISOString()}`)
    console.log(`[Subscription Checker] Academic year ends on June 15th each year`)

    // Find FullProgram entries where subscriptionEndDate is in the past and isAssigned is true
    // subscriptionEndDate is set to June 15th of the academic year when students are assigned
    const expiredFullPrograms = await FullProgram.find({
      subscriptionEndDate: { $lt: now },
      isAssigned: true,
    }).populate("patientid")

    if (expiredFullPrograms.length === 0) {
      console.log(`[Subscription Checker] No expired subscriptions found`)
      return res.status(200).json({ message: "No expired subscriptions found to unassign.", results: [] })
    }

    console.log(`[Subscription Checker] Found ${expiredFullPrograms.length} expired subscription(s) to process`)

    const unassignmentResults = []

    for (const program of expiredFullPrograms) {
      const patientId = program.patientid._id
      const patientName = program.patientid.firstName + " " + program.patientid.lastName
      const departmentsUnassigned = []

      console.log(
        `[Subscription Checker] Processing expired subscription for patient: ${patientName} (ID: ${patientId})`,
      )
      console.log(
        `[Subscription Checker] - Subscription ended on: ${program.subscriptionEndDate.toISOString().split("T")[0]}`,
      )

      // Attempt to unassign from all relevant department assignments
      const unassignPromises = [
        PatientABAAssignment.findOneAndDelete({ patient: patientId }),
        PatientOccupationalTherapyAssignment.findOneAndDelete({ patient: patientId }),
        PatientPhysicalTherapyAssignment.findOneAndDelete({ patient: patientId }),
        PatientSpecialEducationAssignment.findOneAndDelete({ patient: patientId }),
        PatientSpeechAssignment.findOneAndDelete({ patient: patientId }),
        PatientPsychotherapyAssignment.findOneAndDelete({ patient: patientId }),

      ]

      const results = await Promise.allSettled(unassignPromises)

      results.forEach((result, index) => {
        const departmentNames = ["ABA", "OccupationalTherapy", "PhysicalTherapy", "SpecialEducation", "Speech"]
        if (result.status === "fulfilled" && result.value) {
          departmentsUnassigned.push(departmentNames[index])
          console.log(
            `[Subscription Checker] - Successfully unassigned from ${departmentNames[index]} for ${patientName}`,
          )
        } else if (result.status === "rejected") {
          console.error(
            `[Subscription Checker] - Failed to unassign from ${departmentNames[index]} for ${patientName}:`,
            result.reason,
          )
        }
      })

      // Update the FullProgram document to reflect unassignment
      program.isAssigned = false
      await program.save()
      console.log(
        `[Subscription Checker] - Updated FullProgram status to unassigned for ${patientName} (FullProgram ID: ${program._id})`,
      )

      unassignmentResults.push({
        fullProgramId: program._id,
        patientId: patientId,
        patientName: patientName,
        status: "unassigned",
        departments: departmentsUnassigned,
        message: `Unassigned from: ${departmentsUnassigned.join(", ")}`,
      })
    }

    console.log(`[Subscription Checker] Successfully processed ${unassignmentResults.length} expired subscription(s)`)

    res.status(200).json({
      message: `Successfully processed ${unassignmentResults.length} expired subscriptions.`,
      results: unassignmentResults,
    })
  } catch (error) {
    console.error("[Subscription Checker] Error during manual subscription check:", error)
    res.status(500).json({ message: "Internal server error during subscription check.", error: error.message })
  }
})

module.exports = router
