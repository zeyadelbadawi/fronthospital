const express = require("express")
const doctorFileRouter = express.Router()
const formidable = require("formidable")
const fs = require("fs")
const path = require("path")
const { v4: uuidv4 } = require("uuid")
const DoctorFile = require("../models/doctor-file-schema") // adjust the path as needed
const Department = require("../models/department")
const Doctor = require("../models/users/Doctor") // adjust the path as needed

// Helper function to get next quarter
const getNextQuarterAndYear = (currentQ, currentY) => {
  if (currentQ === 4) {
    return { quarter: 1, year: currentY + 1 }
  }
  return { quarter: currentQ + 1, year: currentY }
}

/* doctorFileRouter.post("/upload-plan", (req, res) => {
  const form = new formidable.IncomingForm();
  form.keepExtensions = true;
  form.maxFileSize = 10 * 1024 * 1024; // 10MB

  const uploadDir = path.join(__dirname, "../uploads/doctor-files");
  if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

  form.uploadDir = uploadDir;

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err);
      return res.status(500).json({ message: "Error parsing uploaded file" });
    }

    const doctorId = fields.doctorId?.[0];
    const departmentId = fields.departmentId?.[0];
    const quarterOfYear = parseInt(fields.quarterOfYear?.[0], 10);
    const year = parseInt(fields.year?.[0], 10);

    if (!doctorId || !departmentId || !quarterOfYear || !year) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    try {
      const file = files.document?.[0];
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const tempFilePath = file.filepath;
      const originalFileName = file.originalFilename;
      const uniqueFileName = `${uuidv4()}${path.extname(originalFileName)}`;
      const finalFilePath = path.join(uploadDir, uniqueFileName);

      fs.renameSync(tempFilePath, finalFilePath);

      const newDoctorFile = await DoctorFile.create({
        doctorId,
        departmentId,
        fileName: originalFileName,
        filePath: uniqueFileName,
        quarterOfYear,
        year,
      });

      res.status(200).json({
        message: "File uploaded and saved successfully",
        file: {
          fileName: originalFileName,
          filePath: uniqueFileName,
          fullPath: `uploads/doctor-files/${uniqueFileName}`,
          createdAt: newDoctorFile.createdAt,
        },
      });
    } catch (error) {
      console.error("Error saving doctor file:", error);
      res.status(500).json({ message: "Error saving file" });
    }
  });
}); */

doctorFileRouter.get("/doctor-deps/:id", async (req, res) => {
  const { id } = req.params
  try {
    if (!id) {
      return res.status(400).json({ error: "Doctor ID is required" })
    }

    const doctor = await Doctor.findById(id).populate("departments")

    if (!doctor) {
      return res.status(404).json({ error: "Doctor not found" })
    }

    // Extract department names
    //const departmentNames = doctor.departments.map((dept) => dept.name);

    res.status(200).json(doctor.departments)
  } catch (error) {
    res.status(500).json({
      error: "Failed to fetch doctor departments",
      details: error.message,
    })
  }
})

/* Get request */
/* doctorFileRouter.get("/get-plans/:doctorId/:departmentId", async (req, res) => {
  const { doctorId, departmentId } = req.params;

  try {
    if (!doctorId || !departmentId) {
      return res.status(400).json({ message: "Missing required fields" });
    }
    const doctorFiles = await DoctorFile.find({
      doctorId,
      departmentId,
    }).sort({ createdAt: -1 });

    console.log("rrrr",!doctorFiles)

    if (!doctorFiles) {
      return res
        .status(404)
        .json({ message: "No plans found for this doctor" });
    }

    res.status(200).json({
      message: "Doctor plans retrieved successfully",
      doctorFiles,
    });
  } catch (error) {
    console.error("Error retrieving doctor files:", error);
    res.status(500).json({ message: "Error retrieving doctor files" });
  }
}); */

doctorFileRouter.get("/get-plans/:doctorId/:departmentId", async (req, res) => {
  const { doctorId, departmentId } = req.params
  const { last, quarter, year } = req.query

  try {
    if (!doctorId || !departmentId) {
      return res.status(400).json({ message: "Missing required fields" })
    }

    const query = { doctorId, departmentId }

    // Add quarter and year filters if provided
    if (quarter) query.quarterOfYear = Number.parseInt(quarter)
    if (year) query.year = Number.parseInt(year)

    let doctorFiles

    if (last === "true") {
      // Return only the latest plan
      doctorFiles = await DoctorFile.findOne(query).populate("doctorId", "departmentId").sort({ createdAt: -1 })
    } else {
      // Return all plans matching the query
      doctorFiles = await DoctorFile.find(query).sort({ year: -1, quarterOfYear: -1, createdAt: -1 })
    }

    res.status(200).json({
      message: "Doctor plans retrieved successfully",
      doctorFiles,
    })
  } catch (error) {
    console.error("Error retrieving doctor files:", error)
    res.status(500).json({ message: "Error retrieving doctor files" })
  }
})

/* Post request - For manual file uploads (initial, historical) */
doctorFileRouter.post("/upload-plan", (req, res) => {
  const form = new formidable.IncomingForm()
  form.keepExtensions = true
  form.maxFileSize = 10 * 1024 * 1024 // 10MB

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err)
      return res.status(500).json({ message: "Error parsing uploaded file" })
    }

    const doctorId = fields.doctorId?.[0]
    const departmentId = fields.departmentId?.[0]
    const quarterOfYear = Number.parseInt(fields.quarterOfYear?.[0], 10)
    const year = Number.parseInt(fields.year?.[0], 10)

    if (!doctorId || !departmentId || !quarterOfYear || !year) {
      return res.status(400).json({ message: "Missing required fields" })
    }

    if (quarterOfYear < 1 || quarterOfYear > 4) {
      return res.status(400).json({ message: "Quarter of year must be between 1 and 4" })
    }

    const department = await Department.findById(departmentId)
    if (!department) {
      return res.status(404).json({ message: "Department not found" })
    }

    try {
      const file = files.document?.[0]
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" })
      }

      const tempFilePath = file.filepath
      const originalFileName = file.originalFilename
      const uniqueFileName = `${uuidv4()}${path.extname(originalFileName)}`

      // Create the upload directory structure
      const uploadDir = path.join(
        __dirname,
        "../uploads",
        `Q${quarterOfYear}`,
        `${year}`,
        `${department.name}`,
        `doctor-plans`,
      )

      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true })
      }

      const finalFilePath = path.join(uploadDir, uniqueFileName)
      fs.copyFileSync(tempFilePath, finalFilePath)
      fs.unlinkSync(tempFilePath)

      const newDoctorFile = await DoctorFile.create({
        doctorId,
        departmentId,
        fileName: originalFileName,
        uniqueName: uniqueFileName,
        fullPath: `/uploads/Q${quarterOfYear}/${year}/${department.name}/doctor-plans/${uniqueFileName}`,
        quarterOfYear,
        year,
      })

      res.status(200).json({
        message: "File uploaded and saved successfully",
        doctorFile: { ...newDoctorFile._doc },
      })
    } catch (error) {
      console.error("Error saving doctor file:", error)
      res.status(500).json({ message: "Error saving file" })
    }
  })
})

/* New Route: Upload Department Template (Admin Functionality) */
doctorFileRouter.post("/upload-template", (req, res) => {
  const form = new formidable.IncomingForm()
  form.keepExtensions = true
  form.maxFileSize = 10 * 1024 * 1024 // 10MB

  const uploadDir = path.join(__dirname, "../uploads/templates")
  if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err)
      return res.status(500).json({ message: "Error parsing uploaded file" })
    }

    const departmentName = fields.departmentName?.[0] // e.g., "Physical-Therapy"
    if (!departmentName) {
      return res.status(400).json({ message: "Department name is required" })
    }

    try {
      const file = files.templateFile?.[0]
      if (!file) {
        return res.status(400).json({ message: "No template file uploaded" })
      }

      const tempFilePath = file.filepath
      const originalFileName = file.originalFilename
      const fileExtension = path.extname(originalFileName).toLowerCase()

      if (fileExtension !== ".docx") {
        fs.unlinkSync(tempFilePath) // Delete unsupported file
        return res.status(400).json({ message: "Only .docx files are allowed for templates" })
      }

      const finalFileName = `${departmentName}-template.docx`
      const finalFilePath = path.join(uploadDir, finalFileName)

      // Overwrite existing template if it exists
      fs.copyFileSync(tempFilePath, finalFilePath)
      fs.unlinkSync(tempFilePath)

      res.status(200).json({
        message: `Template for ${departmentName} uploaded successfully`,
        fileName: finalFileName,
        filePath: `/uploads/templates/${finalFileName}`,
      })
    } catch (error) {
      console.error("Error uploading template:", error)
      res.status(500).json({ message: "Error uploading template" })
    }
  })
})

/* New Route: Close Quarter and Generate Next Quarter's Plan from Template */
doctorFileRouter.post("/close-and-generate-next-plan", async (req, res) => {
  const { doctorId, departmentId, quarterToClose, yearToClose } = req.body

  if (!doctorId || !departmentId || !quarterToClose || !yearToClose) {
    return res.status(400).json({ message: "Missing required fields for closing quarter" })
  }

  try {
    const department = await Department.findById(departmentId)
    if (!department) {
      return res.status(404).json({ message: "Department not found" })
    }

    const { quarter: nextQuarter, year: nextYear } = getNextQuarterAndYear(quarterToClose, yearToClose)

    // Check if a plan already exists for the next quarter
    const existingNextPlan = await DoctorFile.findOne({
      doctorId,
      departmentId,
      quarterOfYear: nextQuarter,
      year: nextYear,
    })

    if (existingNextPlan) {
      return res.status(409).json({
        message: `A plan already exists for Q${nextQuarter}/${nextYear}. No new plan generated.`,
        doctorFile: existingNextPlan,
      })
    }

    // Construct template path
    const templateFileName = `${department.name}-template.docx`
    const templatePath = path.join(__dirname, "../uploads/templates", templateFileName)

    if (!fs.existsSync(templatePath)) {
      return res.status(404).json({
        message: `Default template for department '${department.name}' not found. Please upload one.`,
      })
    }

    // Generate unique filename for the new plan
    const uniqueFileName = `${uuidv4()}.docx` // Always .docx as it's a template
    const uploadDir = path.join(
      __dirname,
      "../uploads",
      `Q${nextQuarter}`,
      `${nextYear}`,
      `${department.name}`,
      `doctor-plans`,
    )

    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true })
    }

    const finalFilePath = path.join(uploadDir, uniqueFileName)

    // Copy the template to the new plan's location
    fs.copyFileSync(templatePath, finalFilePath)

    // Create new DoctorFile entry in DB
    const newDoctorFile = await DoctorFile.create({
      doctorId,
      departmentId,
      fileName: `Default Plan for Q${nextQuarter} ${nextYear}`, // Descriptive name
      uniqueName: uniqueFileName,
      fullPath: `/uploads/Q${nextQuarter}/${nextYear}/${department.name}/doctor-plans/${uniqueFileName}`,
      quarterOfYear: nextQuarter,
      year: nextYear,
    })

    res.status(200).json({
      message: `Quarter ${quarterToClose}/${yearToClose} closed. New plan for Q${nextQuarter}/${nextYear} generated from template.`,
      doctorFile: { ...newDoctorFile._doc },
    })
  } catch (error) {
    console.error("Error closing quarter and generating next plan:", error)
    res.status(500).json({ message: "Error processing quarter closure and plan generation" })
  }
})

/* Put request */

doctorFileRouter.put("/update-plan/:id", (req, res) => {
  const form = new formidable.IncomingForm()
  form.keepExtensions = true
  form.maxFileSize = 10 * 1024 * 1024 // 10MB

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err)
      return res.status(500).json({ message: "Error parsing uploaded data" })
    }

    const fileId = req.params.id

    try {
      const existingFile = await DoctorFile.findById(fileId)
      if (!existingFile) {
        return res.status(404).json({ message: "File not found" })
      }

      // Validate input fields
      const doctorId = fields.doctorId?.[0]
      const departmentId = fields.departmentId?.[0]
      const quarterOfYear = Number.parseInt(fields.quarterOfYear?.[0], 10)
      const year = Number.parseInt(fields.year?.[0], 10)

      // Basic validation
      if (!doctorId || !departmentId || !quarterOfYear || !year) {
        return res.status(400).json({ message: "All fields are required" })
      }

      if (![1, 2, 3, 4].includes(quarterOfYear)) {
        return res.status(400).json({ message: "quarterOfYear must be 1, 2, 3, or 4" })
      }

      const department = await Department.findById(departmentId)
      if (!department) {
        return res.status(404).json({ message: "Department not found" })
      }

      let fileName = existingFile.fileName
      let filePath = existingFile.uniqueName

      // Check if new file is provided
      const file = files.document?.[0]
      if (file) {
        const tempFilePath = file.filepath
        const originalFileName = file.originalFilename
        const uniqueFileName = `${uuidv4()}${path.extname(originalFileName)}`

        /* // Validate file type (optional)
        const allowedTypes = [".pdf", ".doc", ".docx", ".jpg", ".png"];
        const ext = path.extname(originalFileName).toLowerCase();
        if (!allowedTypes.includes(ext)) {
          return res.status(400).json({ message: "Unsupported file type" });
        } */

        const uploadDir = path.join(
          __dirname,
          "../uploads",
          `Q${quarterOfYear}`,
          `${year}`,
          `${department.name}`,
          `doctor-plans`,
        )

        if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

        const finalFilePath = path.join(uploadDir, uniqueFileName)

        fs.copyFileSync(tempFilePath, finalFilePath)
        fs.unlinkSync(tempFilePath)

        const exDepartment = await Department.findById(existingFile.departmentId)
        if (!exDepartment) {
          return res.status(404).json({ message: "Department not found" })
        }

        // Delete old file from disk
        const oldFilePath = path.join(
          __dirname,
          "../uploads",
          `Q${existingFile.quarterOfYear}`,
          `${existingFile.year}`,
          `${exDepartment.name}`,
          `doctor-plans`,
          existingFile.uniqueName,
        )
        if (fs.existsSync(oldFilePath)) fs.unlinkSync(oldFilePath)

        fileName = originalFileName
        filePath = uniqueFileName
      }

      // Save updated data to DB
      const updatedFile = await DoctorFile.findByIdAndUpdate(
        fileId,
        {
          doctorId,
          departmentId,
          quarterOfYear,
          year,
          fileName,
          uniqueName: filePath,
          fullPath: `/uploads/Q${quarterOfYear}/${year}/${department.name}/doctor-plans/${filePath}`,
        },
        { new: true },
      )

      /*  const fullPath = path.join(
        "uploads",
        `Q${quarterOfYear}`,
        `${year}`,
        `${departmentId}`,
        `${doctorId}`,
        filePath
      ); */

      res.status(200).json({
        message: "File and data updated successfully",
        /* file: {
          fileName,
          filePath,
          fullPath,
          
        }, */
        ...updatedFile._doc,
      })
    } catch (error) {
      console.error("Error updating file:", error)
      res.status(500).json({ message: "Error updating file" })
    }
  })
})

/* doctorFileRouter.put("/upload-plan/:id", (req, res) => {
  const form = new formidable.IncomingForm();
  form.keepExtensions = true;
  form.maxFileSize = 10 * 1024 * 1024; // 10MB

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err);
      return res.status(500).json({ message: "Error parsing uploaded file" });
    }

    const fileId = req.params.id;

    try {
      const existingFile = await DoctorFile.findById(fileId);
      if (!existingFile) {
        return res.status(404).json({ message: "File not found" });
      }

      const department = await Department.findById(existingFile.departmentId);
      if (!department) {
        return res.status(404).json({ message: "Department not found" });
      }

      const file = files.document?.[0];
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      // Prepare new file
      const tempFilePath = file.filepath;
      const originalFileName = file.originalFilename;
      const uniqueFileName = `${uuidv4()}${path.extname(originalFileName)}`;

      const uploadDir = path.join(
        __dirname,
        "../uploads",
        `Q${existingFile.quarterOfYear}`,
        `${existingFile.year}`,
        `${existingFile.departmentId}`,
        `${existingFile.doctorId}`
      );
      if (!fs.existsSync(uploadDir))
        fs.mkdirSync(uploadDir, { recursive: true });

      const finalFilePath = path.join(uploadDir, uniqueFileName);

      // Replace file on disk
      fs.copyFileSync(tempFilePath, finalFilePath);
      fs.unlinkSync(tempFilePath);

      const filePath = path.join(
        __dirname,
        "../uploads",
        `Q${existingFile.quarterOfYear}`,
        `${existingFile.year}`,
        `${department.name}`,
        "doctor-plans",
        existingFile.uniqueName
      );

      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }

      // Update DB record
      existingFile.fileName = originalFileName;
      existingFile.filePath = uniqueFileName;
      await existingFile.save();

      const fullPath = path.join(
        "uploads",
        `Q${existingFile.quarterOfYear}`,
        `${existingFile.year}`,
        `${existingFile.departmentId}`,
        `${existingFile.doctorId}`,
        uniqueFileName
      );

      res.status(200).json({
        message: "File updated successfully",
        file: {
          fileName: originalFileName,
          filePath: uniqueFileName,
          fullPath,
        },
      });
    } catch (error) {
      console.error("Error updating file:", error);
      res.status(500).json({ message: "Error updating file" });
    }
  });
}); */

/* Delete request */
doctorFileRouter.delete("/delete-plan/:id", async (req, res) => {
  const { id } = req.params

  try {
    const doctorFile = await DoctorFile.findById(id)
    if (!doctorFile) {
      return res.status(404).json({ message: "Doctor file not found" })
    }

    const department = await Department.findById(doctorFile.departmentId)
    if (!department) {
      return res.status(404).json({ message: "Department not found" })
    }
    const filePath = path.join(
      __dirname,
      "../uploads",
      `Q${doctorFile.quarterOfYear}`,
      `${doctorFile.year}`,
      `${department.name}`,
      "doctor-plans",
      doctorFile.uniqueName,
    )
    console.log("Doctor file:", filePath)

    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath)
    }

    await DoctorFile.findByIdAndDelete(id)

    res.status(200).json({ message: "Doctor file deleted successfully" })
  } catch (error) {
    console.error("Error deleting doctor file:", error)
    res.status(500).json({ message: "Error deleting doctor file" })
  }
})

doctorFileRouter.get("/active-quarter/:doctorId/:departmentId", async (req, res) => {
  const { doctorId, departmentId } = req.params

  try {
    const now = new Date()
    const currentMonth = now.getMonth() + 1
    const currentYear = now.getFullYear()

    let currentQuarter
    if (currentMonth <= 3) currentQuarter = 1
    else if (currentMonth <= 6) currentQuarter = 2
    else if (currentMonth <= 9) currentQuarter = 3
    else currentQuarter = 4

    // Check if current quarter has a plan
    const currentPlan = await DoctorFile.findOne({
      doctorId,
      departmentId,
      quarterOfYear: currentQuarter,
      year: currentYear,
    })

    let activeQuarter, activeYear

    if (currentPlan) {
      // Current quarter has a plan, suggest next quarter
      if (currentQuarter === 4) {
        activeQuarter = 1
        activeYear = currentYear + 1
      } else {
        activeQuarter = currentQuarter + 1
        activeYear = currentYear
      }
    } else {
      // Current quarter doesn't have a plan
      activeQuarter = currentQuarter
      activeYear = currentYear
    }

    res.status(200).json({
      currentQuarter,
      currentYear,
      activeQuarter,
      activeYear,
      hasCurrentPlan: !!currentPlan,
    })
  } catch (error) {
    console.error("Error determining active quarter:", error)
    res.status(500).json({ message: "Error determining active quarter" })
  }
})

module.exports = doctorFileRouter
