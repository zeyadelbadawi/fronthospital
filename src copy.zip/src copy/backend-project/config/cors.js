// config/cors.js
const cors = require("cors");

function parseList(s = "") {
  return s.split(",").map(v => v.trim()).filter(Boolean);
}

const allowedOrigins = parseList(process.env.ALLOWED_ORIGINS);

const corsOptions = {
  origin(origin, cb) {
    // allow server-to-server (no Origin) and whitelisted origins
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    return cb(new Error("Not allowed by CORS"));
  },
  credentials: true,
  methods: ["GET","POST","PUT","PATCH","DELETE","OPTIONS"],
  allowedHeaders: ["Content-Type","Authorization"]
};

module.exports = { corsMiddleware: cors(corsOptions), allowedOrigins };
