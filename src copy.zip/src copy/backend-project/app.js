const express = require("express")
const path = require("path")
const expressLayouts = require("express-ejs-layouts")
const connectDB = require("./db")
const dotenv = require("dotenv")
dotenv.config()
const http = require("http")
const { Server } = require("socket.io")

// NEW: import your env-driven CORS config
const { corsMiddleware, allowedOrigins } = require("./config/cors")
const { securityHeaders } = require("./middleware/securityHeaders")

//const { securityHeaders, enforceHTTPS } = require("./middleware/securityHeaders")
const { apiLimiter } = require("./middleware/rateLimiter")

const app = express()

// socket.io configuration (MOVED to after we know allowedOrigins)
const server = http.createServer(app)
const io = new Server(server, {
  cors: {
    origin: allowedOrigins, // use the same whitelist as Express
    credentials: true,
    methods: ["GET", "POST"],
  },
})

// Connect to MongoDB
connectDB()

// NEW: trust proxy (important behind tunnels like Cloudflare)
app.set("trust proxy", 1)

app.use(securityHeaders)


//enable after deployment

//app.use(enforceHTTPS)

// NEW: use your CORS middleware (replaces origin:"*" block)
app.use(corsMiddleware)
app.options("*", corsMiddleware)

app.use("/authentication", apiLimiter)
app.use("/uploads/Psycho-therapyS/plan", express.static(path.join(__dirname, "uploads", "Psycho-therapyS", "plan")))
app.use("/uploads/physical-therapyS/exam", express.static(path.join(__dirname, "uploads", "physical-therapyS", "exam")))
app.use("/uploads/physical-therapyS/plan", express.static(path.join(__dirname, "uploads", "physical-therapyS", "plan")))
app.use("/uploads/DRAST-7ALA/plan", express.static(path.join(__dirname, "uploads", "DRAST-7ALA", "plan")))
app.use("/uploads/school-plan/plan", express.static(path.join(__dirname, "uploads", "school-plan", "plan")))
app.use("/uploads/SpeechS/exam", express.static(path.join(__dirname, "uploads", "SpeechS", "exam")))
app.use("/uploads/SpeechS/plan", express.static(path.join(__dirname, "uploads", "SpeechS", "plan")))
app.use("/uploads/ABAS/exam", express.static(path.join(__dirname, "uploads", "ABAS", "exam")))
app.use("/uploads/ABAS/plan", express.static(path.join(__dirname, "uploads", "ABAS", "plan")))
app.use(
  "/uploads/Occupational-therapyS/exam",
  express.static(path.join(__dirname, "uploads", "Occupational-therapyS", "exam")),
)
app.use(
  "/uploads/Occupational-therapyS/plan",
  express.static(path.join(__dirname, "uploads", "Occupational-therapyS", "plan")),
)
app.use(
  "/uploads/Special-EducationS/exam",
  express.static(path.join(__dirname, "uploads", "Special-EducationS", "exam")),
)
app.use(
  "/uploads/Special-EducationS/plan",
  express.static(path.join(__dirname, "uploads", "Special-EducationS", "plan")),
)

app.use("/uploads", express.static(path.join(__dirname, "uploads")))
app.use("/uploads/templates", express.static(path.join(__dirname, "uploads", "templates")))

app.use(express.static("public"))
app.use(expressLayouts)
app.set("layout", "./layout/layout")
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

app.set("views", path.join(__dirname, "views"))
app.set("view engine", "ejs")

app.use("/css", express.static(__dirname + "public/css"))
app.use("/fonts", express.static(__dirname + "public/fonts"))
app.use("/images", express.static(__dirname + "public/images"))
app.use("/js", express.static(__dirname + "public/js"))
app.use("/webfonts", express.static(__dirname + "public/webfonts"))

const pageRouter = require("./routes/routes")
pageRouter(app)

// set up socket.io users
const onlineUsers = new Map()
io.on("connection", (socket) => {
  console.log("A user connected", socket.id)
  socket.on("register", (userId) => {
    onlineUsers.set(userId, socket.id)
    console.log(`User ${userId} registered with socket ${socket.id}`)
  })
  socket.on("disconnect", () => {
    for (const [userId, sockId] of onlineUsers.entries()) {
      if (sockId === socket.id) {
        onlineUsers.delete(userId)
        break
      }
    }
    console.log("User disconnected", socket.id)
  })
})
app.set("io", io)
app.set("onlineUsers", onlineUsers)

// Start the server
const PORT = process.env.PORT || 8070
server.listen(PORT, () => console.log(`Server running on port ${PORT}`))
