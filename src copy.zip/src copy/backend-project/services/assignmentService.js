const PatientABAAssignmentS = require("../models/single/ABAC/PatientABAAssignmentS")
const PatientOccupationalTherapyAssignmentS = require("../models/single/Occupational-therapyC/PatientOccupationalTherapyAssignmentS")
const PatientPhysicalTherapyAssignmentS = require("../models/single/physicalTherapyC/PatientPhysicalTherapyAssignmentS")
const PatientSpecialEducationAssignmentS = require("../models/single/Special-EducationC/PatientSpecialEducationAssignmentS")
const PatientSpeechAssignmentS = require("../models/single/SpeechC/PatientSpeechAssignmentS")
const Patient = require("../models/users/Patient")

class AssignmentService {
  constructor() {
    this.serviceModels = {
      ABA: PatientABAAssignmentS,
      occupational_therapy: PatientOccupationalTherapyAssignmentS,
      physical_therapy: PatientPhysicalTherapyAssignmentS,
      special_education: PatientSpecialEducationAssignmentS,
      speech: PatientSpeechAssignmentS,
    }
  }

  async validatePatient(patientId) {
    if (!patientId) {
      throw new Error("Patient ID is required")
    }

    const patient = await Patient.findById(patientId)
    if (!patient) {
      throw new Error("Patient not found")
    }

    return patient
  }

  async createAssignment(serviceName, patientId, notes = "", programId = null) {
    try {
      const Model = this.serviceModels[serviceName]
      if (!Model) {
        throw new Error(`Invalid service name: ${serviceName}`)
      }

      await this.validatePatient(patientId)

      const assignmentData = {
        patient: patientId,
        notes: notes || `Assignment for ${serviceName} service`,
        status: "active",
        programId: programId,
        sessionNumber: await this.getNextSessionNumber(serviceName, patientId),
      }

      const assignment = new Model(assignmentData)
      await assignment.save()

      return {
        success: true,
        assignment,
        message: `Patient successfully assigned to ${serviceName}`,
      }
    } catch (error) {
      return {
        success: false,
        error: error.message,
      }
    }
  }

  async getNextSessionNumber(serviceName, patientId) {
    try {
      const Model = this.serviceModels[serviceName]
      const lastAssignment = await Model.findOne({ patient: patientId })
        .sort({ sessionNumber: -1 })
        .select("sessionNumber")

      return (lastAssignment?.sessionNumber || 0) + 1
    } catch (error) {
      return 1
    }
  }

  async createMultipleAssignments(services, patientId, notes = "", programId = null) {
    const results = []
    const errors = []

    for (const service of services) {
      const result = await this.createAssignment(service, patientId, notes, programId)
      if (result.success) {
        results.push(result)
      } else {
        errors.push({ service, error: result.error })
      }
    }

    return {
      success: errors.length === 0,
      results,
      errors,
      totalAssigned: results.length,
      totalFailed: errors.length,
    }
  }

  async completeAssignment(serviceName, patientId, assignmentId = null) {
    try {
      const Model = this.serviceModels[serviceName]
      if (!Model) {
        throw new Error(`Invalid service name: ${serviceName}`)
      }

      const query = assignmentId ? { _id: assignmentId } : { patient: patientId, status: "active" }

      const assignment = await Model.findOneAndUpdate(
        query,
        {
          status: "completed",
          completedAt: new Date(),
        },
        { new: true },
      )

      if (!assignment) {
        throw new Error("Assignment not found or already completed")
      }

      return {
        success: true,
        assignment,
        message: `Assignment completed successfully`,
      }
    } catch (error) {
      return {
        success: false,
        error: error.message,
      }
    }
  }

  // New methods for program-based operations
  async cancelAssignmentsByProgram(serviceName, patientId, programId) {
    try {
      const Model = this.serviceModels[serviceName]
      if (!Model) {
        throw new Error(`Invalid service name: ${serviceName}`)
      }

      const result = await Model.updateMany(
        { patient: patientId, programId: programId, status: "active" },
        {
          status: "cancelled",
          cancelledAt: new Date(),
        },
      )

      return {
        success: true,
        modifiedCount: result.modifiedCount,
        message: `${result.modifiedCount} assignments cancelled for ${serviceName}`,
      }
    } catch (error) {
      return {
        success: false,
        error: error.message,
      }
    }
  }

  async completeAssignmentsByProgram(serviceName, patientId, programId) {
    try {
      const Model = this.serviceModels[serviceName]
      if (!Model) {
        throw new Error(`Invalid service name: ${serviceName}`)
      }

      const result = await Model.updateMany(
        { patient: patientId, programId: programId, status: "active" },
        {
          status: "completed",
          completedAt: new Date(),
        },
      )

      return {
        success: true,
        modifiedCount: result.modifiedCount,
        message: `${result.modifiedCount} assignments completed for ${serviceName}`,
      }
    } catch (error) {
      return {
        success: false,
        error: error.message,
      }
    }
  }
}

module.exports = new AssignmentService()
