const axios = require("axios")

// Verify Google reCAPTCHA v2
const verifyCaptcha = async (captchaToken) => {
  try {
    const secretKey = process.env.RECAPTCHA_SECRET_KEY

    if (!secretKey) {
      console.error("RECAPTCHA_SECRET_KEY not configured")
      return { success: false, error: "CAPTCHA not configured" }
    }

    const verificationURL = `https://www.google.com/recaptcha/api/siteverify?secret=${secretKey}&response=${captchaToken}`

    const response = await axios.post(verificationURL)

    if (response.data.success) {
      return { success: true }
    } else {
      return {
        success: false,
        error: "CAPTCHA verification failed",
        errorCodes: response.data["error-codes"],
      }
    }
  } catch (error) {
    console.error("CAPTCHA verification error:", error)
    return {
      success: false,
      error: "CAPTCHA verification failed",
    }
  }
}

module.exports = { verifyCaptcha }
