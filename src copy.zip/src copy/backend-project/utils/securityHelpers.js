const crypto = require("crypto")

const timingSafeCompare = (a, b) => {
  if (typeof a !== "string" || typeof b !== "string") {
    return false
  }

  const bufferA = Buffer.from(a)
  const bufferB = Buffer.from(b)

  if (bufferA.length !== bufferB.length) {
    return false
  }

  return crypto.timingSafeEqual(bufferA, bufferB)
}

const isValidEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

const isStrongPassword = (password) => {
  // At least 8 characters, 1 uppercase, 1 lowercase, 1 number, 1 special char
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/
  return passwordRegex.test(password)
}

const sanitizeInput = (input) => {
  if (typeof input !== "string") return input

  return input
    .replace(/[<>]/g, "") // Remove < and >
    .trim()
    .substring(0, 255) // Limit length
}

const generateSecureToken = () => {
  return crypto.randomBytes(32).toString("hex")
}

module.exports = {
  timingSafeCompare,
  isValidEmail,
  isStrongPassword,
  sanitizeInput,
  generateSecureToken,
}
