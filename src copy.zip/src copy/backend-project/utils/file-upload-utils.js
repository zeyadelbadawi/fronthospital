const formidable = require("formidable")
const fs = require("fs")
const path = require("path")
const { v4: uuidv4 } = require("uuid")

// Helper function to get next quarter and year
const getNextQuarterAndYear = (currentQ, currentY) => {
  if (currentQ === 4) {
    return { quarter: 1, year: currentY + 1 }
  }
  return { quarter: currentQ + 1, year: currentY }
}

// Generic file upload handler
const handleFileUpload = (req, res, uploadBaseDir, model, identifierField, departmentName, isTemplate = false) => {
  const form = new formidable.IncomingForm()
  form.keepExtensions = true
  form.maxFileSize = 10 * 1024 * 1024 // 10MB

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err)
      return res.status(500).json({ message: "Error parsing uploaded file" })
    }

    const id = fields[identifierField]?.[0]
    const quarterOfYear = Number.parseInt(fields.quarterOfYear?.[0], 10)
    const year = Number.parseInt(fields.year?.[0], 10)

    if (!id || !quarterOfYear || !year) {
      return res.status(400).json({ message: "Missing required fields: ID, quarter, or year" })
    }

    if (quarterOfYear < 1 || quarterOfYear > 4) {
      return res.status(400).json({ message: "Quarter of year must be between 1 and 4" })
    }

    try {
      const file = files.document?.[0] || files.templateFile?.[0]
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" })
      }

      const tempFilePath = file.filepath
      const originalFileName = file.originalFilename
      const fileExtension = path.extname(originalFileName).toLowerCase()

      if (isTemplate && fileExtension !== ".docx") {
        fs.unlinkSync(tempFilePath) // Delete unsupported file
        return res.status(400).json({ message: "Only .docx files are allowed for templates" })
      }

      const uniqueFileName = isTemplate ? `${departmentName}-template.docx` : `${uuidv4()}${fileExtension}`

      const uploadDir = isTemplate
        ? path.join(__dirname, "..", uploadBaseDir)
        : path.join(__dirname, "..", uploadBaseDir, `Q${quarterOfYear}`, `${year}`, `${departmentName}`)

      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true })
      }

      const finalFilePath = path.join(uploadDir, uniqueFileName)

      // If it's a template, overwrite existing
      if (isTemplate && fs.existsSync(finalFilePath)) {
        fs.unlinkSync(finalFilePath)
      }

      fs.copyFileSync(tempFilePath, finalFilePath)
      fs.unlinkSync(tempFilePath)

      const fullPath = isTemplate
        ? `${uploadBaseDir.replace(/\\/g, "/")}/${uniqueFileName}`
        : `${uploadBaseDir.replace(/\\/g, "/")}/Q${quarterOfYear}/${year}/${departmentName}/${uniqueFileName}`

      return {
        id,
        quarterOfYear,
        year,
        fileName: originalFileName,
        uniqueName: uniqueFileName,
        fullPath,
      }
    } catch (error) {
      console.error("Error in file upload utility:", error)
      throw new Error("Error processing file upload")
    }
  })
}

// Generic file update handler
const handleFileUpdate = (req, res, uploadBaseDir, model, identifierField, departmentName) => {
  const form = new formidable.IncomingForm()
  form.keepExtensions = true
  form.maxFileSize = 10 * 1024 * 1024 // 10MB

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err)
      return res.status(500).json({ message: "Error parsing uploaded data" })
    }

    const fileId = req.params.id

    try {
      const existingFile = await model.findById(fileId)
      if (!existingFile) {
        return res.status(404).json({ message: "File not found" })
      }

      const id = fields[identifierField]?.[0] || existingFile[identifierField]
      const quarterOfYear = Number.parseInt(fields.quarterOfYear?.[0], 10) || existingFile.quarterOfYear
      const year = Number.parseInt(fields.year?.[0], 10) || existingFile.year

      if (!id || !quarterOfYear || !year) {
        return res.status(400).json({ message: "All fields are required" })
      }

      if (![1, 2, 3, 4].includes(quarterOfYear)) {
        return res.status(400).json({ message: "quarterOfYear must be 1, 2, 3, or 4" })
      }

      let fileName = existingFile.fileName
      let uniqueName = existingFile.uniqueName

      const file = files.document?.[0]
      if (file) {
        const tempFilePath = file.filepath
        const originalFileName = file.originalFilename
        const fileExtension = path.extname(originalFileName)
        const newUniqueFileName = `${uuidv4()}${fileExtension}`

        const uploadDir = path.join(__dirname, "..", uploadBaseDir, `Q${quarterOfYear}`, `${year}`, `${departmentName}`)

        if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

        const finalFilePath = path.join(uploadDir, newUniqueFileName)

        fs.copyFileSync(tempFilePath, finalFilePath)
        fs.unlinkSync(tempFilePath)

        // Delete old file from disk
        const oldFilePath = path.join(
          __dirname,
          "..",
          uploadBaseDir,
          `Q${existingFile.quarterOfYear}`,
          `${existingFile.year}`,
          `${departmentName}`,
          existingFile.uniqueName,
        )
        if (fs.existsSync(oldFilePath)) fs.unlinkSync(oldFilePath)

        fileName = originalFileName
        uniqueName = newUniqueFileName
      }

      const fullPath = `${uploadBaseDir.replace(/\\/g, "/")}/Q${quarterOfYear}/${year}/${departmentName}/${uniqueName}`

      const updatedFile = await model.findByIdAndUpdate(
        fileId,
        {
          [identifierField]: id,
          quarterOfYear,
          year,
          fileName,
          uniqueName,
          fullPath,
        },
        { new: true },
      )

      res.status(200).json({
        message: "File and data updated successfully",
        ...updatedFile._doc,
      })
    } catch (error) {
      console.error("Error updating file:", error)
      res.status(500).json({ message: "Error updating file" })
    }
  })
}

// Generic file deletion handler
const handleDeleteFile = async (req, res, model, uploadBaseDir, departmentName) => {
  const { id } = req.params

  try {
    const docFile = await model.findById(id)
    if (!docFile) {
      return res.status(404).json({ message: "File not found" })
    }

    const filePath = path.join(
      __dirname,
      "..",
      uploadBaseDir,
      `Q${docFile.quarterOfYear}`,
      `${docFile.year}`,
      `${departmentName}`,
      docFile.uniqueName,
    )

    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath)
    }

    await model.findByIdAndDelete(id)

    res.status(200).json({ message: "File deleted successfully" })
  } catch (error) {
    console.error("Error deleting file:", error)
    res.status(500).json({ message: "Error deleting file" })
  }
}

// Generic close quarter and generate next plan handler
const handleCloseQuarterAndGenerateNext = async (req, res, model, identifierField, departmentName, uploadBaseDir) => {
  const { id, quarterToClose, yearToClose } = req.body // id is patientId

  if (!id || !quarterToClose || !yearToClose) {
    return res.status(400).json({ message: "Missing required fields for closing quarter" })
  }

  try {
    const { quarter: nextQuarter, year: nextYear } = getNextQuarterAndYear(quarterToClose, yearToClose)

    // Check if a plan already exists for the next quarter
    const existingNextPlan = await model.findOne({
      [identifierField]: id,
      quarterOfYear: nextQuarter,
      year: nextYear,
    })

    if (existingNextPlan) {
      return res.status(409).json({
        message: `A plan already exists for Q${nextQuarter}/${nextYear}. No new plan generated.`,
        docFile: existingNextPlan,
      })
    }

    // Construct template path
    const templateFileName = `${departmentName}-template.docx`
    const templatePath = path.join(__dirname, "..", "uploads", "templates", templateFileName)

    if (!fs.existsSync(templatePath)) {
      return res.status(404).json({
        message: `Default template for department '${departmentName}' not found. Please upload one.`,
      })
    }

    // Generate unique filename for the new plan
    const uniqueFileName = `${uuidv4()}.docx` // Always .docx as it's a template
    const uploadDir = path.join(__dirname, "..", uploadBaseDir, `Q${nextQuarter}`, `${nextYear}`, `${departmentName}`)

    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true })
    }

    const finalFilePath = path.join(uploadDir, uniqueFileName)

    // Copy the template to the new plan's location
    fs.copyFileSync(templatePath, finalFilePath)

    // Create new entry in DB
    const newDocFile = await model.create({
      [identifierField]: id,
      fileName: `Default Plan for Q${nextQuarter} ${nextYear}`, // Descriptive name
      uniqueName: uniqueFileName,
      fullPath: `${uploadBaseDir.replace(/\\/g, "/")}/Q${nextQuarter}/${nextYear}/${departmentName}/${uniqueFileName}`,
      quarterOfYear: nextQuarter,
      year: nextYear,
    })

    res.status(200).json({
      message: `Quarter ${quarterToClose}/${yearToClose} closed. New plan for Q${nextQuarter}/${nextYear} generated from template.`,
      docFile: { ...newDocFile._doc },
    })
  } catch (error) {
    console.error("Error closing quarter and generating next plan:", error)
    res.status(500).json({ message: "Error processing quarter closure and plan generation" })
  }
}

// Generic get active quarter handler
const handleGetActiveQuarter = async (req, res, model, identifierField) => {
  const { id } = req.params // id is patientId

  try {
    const now = new Date()
    const currentMonth = now.getMonth() + 1
    const currentYear = now.getFullYear()

    let currentQuarter
    if (currentMonth >= 1 && currentMonth <= 3) currentQuarter = 1
    else if (currentMonth >= 4 && currentMonth <= 6) currentQuarter = 2
    else if (currentMonth >= 7 && currentMonth <= 9) currentQuarter = 3
    else currentQuarter = 4

    // Check if current quarter has a plan
    const currentPlan = await model.findOne({
      [identifierField]: id,
      quarterOfYear: currentQuarter,
      year: currentYear,
    })

    let activeQuarter, activeYear

    if (currentPlan) {
      // Current quarter has a plan, suggest next quarter
      if (currentQuarter === 4) {
        activeQuarter = 1
        activeYear = currentYear + 1
      } else {
        activeQuarter = currentQuarter + 1
        activeYear = currentYear
      }
    } else {
      // Current quarter doesn't have a plan
      activeQuarter = currentQuarter
      activeYear = currentYear
    }

    res.status(200).json({
      currentQuarter,
      currentYear,
      activeQuarter,
      activeYear,
      hasCurrentPlan: !!currentPlan,
    })
  } catch (error) {
    console.error("Error determining active quarter:", error)
    res.status(500).json({ message: "Error determining active quarter" })
  }
}

module.exports = {
  handleFileUpload,
  handleFileUpdate,
  handleDeleteFile,
  handleCloseQuarterAndGenerateNext,
  handleGetActiveQuarter,
  getNextQuarterAndYear, // Exported for potential use in other backend logic
}
