/**
 * Calculate the subscription end date based on academic year
 * Academic year: August 15 - June 15 of the following year
 *
 * Logic:
 * - If current date is between Aug 15 and Dec 31 of year X, subscription ends June 15 of year X+1
 * - If current date is between Jan 1 and June 14 of year X, subscription ends June 15 of year X
 * - If current date is between June 15 and Aug 14 of year X, subscription ends June 15 of year X+1
 *
 * @param {Date} startDate - The date when subscription starts (defaults to now)
 * @returns {Date} - The subscription end date (June 15 of the academic year)
 */
function calculateAcademicYearEndDate(startDate = new Date()) {
    const currentDate = new Date(startDate)
    const currentYear = currentDate.getFullYear()
    const currentMonth = currentDate.getMonth() // 0-indexed (0 = January, 7 = August)
    const currentDay = currentDate.getDate()
  
    // Academic year end is always June 15
    let endYear
  
    // If we're between August 15 (month 7, day 15) and December 31
    if (currentMonth > 7 || (currentMonth === 7 && currentDay >= 15)) {
      // Subscription ends June 15 of next year
      endYear = currentYear + 1
    }
    // If we're between January 1 and June 14
    else if (currentMonth < 5 || (currentMonth === 5 && currentDay < 15)) {
      // Subscription ends June 15 of current year
      endYear = currentYear
    }
    // If we're between June 15 and August 14
    else {
      // Subscription ends June 15 of next year
      endYear = currentYear + 1
    }
  
    // Create the end date: June 15 of the calculated year
    const subscriptionEndDate = new Date(endYear, 5, 15, 23, 59, 59, 999) // Month 5 = June (0-indexed)
  
    return subscriptionEndDate
  }
  
  module.exports = {
    calculateAcademicYearEndDate,
  }
  
