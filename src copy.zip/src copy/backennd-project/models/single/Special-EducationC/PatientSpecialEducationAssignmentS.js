const mongoose = require('mongoose');

const PatientSpecialEducationAssignmentSchemaS = new mongoose.Schema(
  {
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Patient',
      required: true,
    },
    assignedDate: {
      type: Date,
      default: Date.now,
    },
    status: {
      type: String,
      enum: ['active', 'completed', 'suspended'],
      default: 'active',
    },
    notes: {
      type: String,
      required: false,
    },
        programId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "SingleProgram",
          required: false,
        },
        sessionNumber: {
          type: Number,
          default: 1,
        },
        completedAt: {
          type: Date,
          required: false,
        },
        cancelledAt: {
          type: Date,
          required: false,
        },
  },
  { timestamps: true },
);

// Index for better query performance
PatientSpecialEducationAssignmentSchemaS.index({ patient: 1, sessionNumber: 1 })
PatientSpecialEducationAssignmentSchemaS.index({ status: 1 })


const PatientSpecialEducationAssignmentS = mongoose.model(
  'PatientSpecialEducationAssignmentS',
  PatientSpecialEducationAssignmentSchemaS,
  'patient_special_education_assignments_s' // Specify a distinct collection name here
);

module.exports = PatientSpecialEducationAssignmentS;
