const mongoose = require("mongoose")

const notificationSchema = new mongoose.Schema(
  {
    receiverId: {
      type: String,
      required: true,
    },
    rule: {
      type: String,
      enum: ["Patient", "Doctor", "Admin", "HeadDoctor", "Accountant"],
      required: true,
    },
    isRead: {
      type: Boolean,
      default: false,
    },
    title: {
      type: String,
      required: true,
    },
    titleAr: {
      type: String,
      required: false,
    },
    message: {
      type: String,
      required: true,
    },
    messageAr: {
      type: String,
      required: false,
    },
    type: {
      type: String,
      enum: [
        "create",
        "update",
        "reschedule",
        "delete",
        "successfully",
        "unsuccessfully",
        "active",
        "pending",
        "confirmed",
        "cancelled",
        "assignment",
        "school_evaluation_ready", // Added for school evaluation completion notifications
      ],
      required: true,
    },
    relatedData: {
      type: mongoose.Schema.Types.Mixed,
      default: null,
    },
  },
  { timestamps: true },
)

const Notification = mongoose.model("Notification", notificationSchema)

module.exports = Notification
