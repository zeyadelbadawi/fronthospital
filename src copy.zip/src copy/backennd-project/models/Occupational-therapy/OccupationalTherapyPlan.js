const mongoose = require("mongoose")

const OccupationalTherapyPlanSchema = new mongoose.Schema({
  patient: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Patient",
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  filePath: {
    type: String,
    required: false, // Can be null if content is stored directly
  },
  fullPath: {
    type: String,
    required: false, // Path to the file including uploads directory structure
  },
  fileName: {
    type: String,
    required: false, // Can be null if content is stored directly
  },
  content: {
    type: String, // Stores SFDT content
    required: false,
  },
  quarterOfYear: {
    type: Number,
    required: true,
    min: 1,
    max: 4,
  },
  year: {
    type: Number,
    required: true,
  },
  createdBy: {
    type: String, // Could be doctor ID or system
    default: "System",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  lastModified: {
    type: Date,
    default: Date.now,
  },
})

// Add a unique compound index to prevent duplicate plans for the same patient, quarter, and year
OccupationalTherapyPlanSchema.index({ patient: 1, quarterOfYear: 1, year: 1 }, { unique: true })

module.exports = mongoose.model("OccupationalTherapyPlan", OccupationalTherapyPlanSchema)



