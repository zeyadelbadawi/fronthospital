const express = require("express")
const Appointment = require("../models/appointment")
const StudentsAppointmentDepartment = require("../models/StudentsAppointmentDepartment")
const Doctor = require("../models/users/Doctor")
const Department = require("../models/department") // Import Department model
const appointmentRouter = express.Router()
const allowedDepartments = ["PhysicalTherapy", "ABA", "OccupationalTherapy", "SpecialEducation", "Speech"]

function extractTime(input) {
  const date = new Date(input)
  if (isNaN(date)) return null
  return date.getHours() * 60 + date.getMinutes()
}

// NEW: Get assigned students count for an appointment
appointmentRouter.get("/assigned-students/:appointmentId", async (req, res) => {
  try {
    const { appointmentId } = req.params

    const assignedStudents = await StudentsAppointmentDepartment.find({
      appointmentId: appointmentId,
    }).populate("patientId", "name email")

    return res.status(200).json({
      count: assignedStudents.length,
      students: assignedStudents,
    })
  } catch (error) {
    return res.status(500).json({ error: "Failed to fetch assigned students" })
  }
})

// UPDATED: Get doctors by department for update dropdown
appointmentRouter.get("/doctors-by-department/:department", async (req, res) => {
  try {
    const { department: requestedDepartmentName } = req.params

    // Find the department by name, considering case-insensitivity and alternative names
    let departmentDoc = await Department.findOne({
      name: { $regex: new RegExp(`^${requestedDepartmentName}$`, "i") },
    })

    // If not found, try alternative names (consistent with doctor-student-assignment.js)
    if (!departmentDoc) {
      const alternativeNames = {
        ABA: ["Applied Behavior Analysis", "ABA", "Behavioral Analysis"],
        Speech: ["speech", "Speech Therapy", "Speech", "Speech-Language Pathology"],
        PhysicalTherapy: ["PhysicalTherapy", "physicalTherapy", "PT", "Physiotherapy"], // Added for consistency
        OccupationalTherapy: ["OccupationalTherapy", "Occupational Therapy", "OT"],
        "Special Education": ["SpecialEducation", "Special Education", "Special Ed", "SPED"],
      }
      const searchNames = alternativeNames[requestedDepartmentName] || [requestedDepartmentName]
      for (const name of searchNames) {
        departmentDoc = await Department.findOne({
          name: { $regex: new RegExp(`^${name}$`, "i") },
        })
        if (departmentDoc) break
      }
    }

    if (!departmentDoc) {
      // If department still not found, it means no doctors can be associated with it
      return res.status(200).json({ doctors: [] })
    }

    // Find doctors that have this department's ObjectId in their departments array
    const doctors = await Doctor.find({
      departments: departmentDoc._id, // Filter by the found department's ObjectId
    }).populate("departments", "name")

    // Map doctors to include a display name for consistency
    const doctorsWithDisplayName = doctors.map((doctor) => {
      const displayName =
        doctor.username ||
        doctor.name ||
        (doctor.firstName && doctor.lastName ? `${doctor.firstName} ${doctor.lastName}` : null) ||
        doctor.firstName ||
        doctor.lastName ||
        doctor.email?.split("@")[0] ||
        "Unknown Doctor"
      return {
        _id: doctor._id,
        username: doctor.username, // Keep username for existing frontend usage
        displayName: displayName,
        departments: doctor.departments,
      }
    })

    return res.status(200).json({ doctors: doctorsWithDisplayName })
  } catch (error) {
    console.error("Error fetching doctors by department:", error)
    return res.status(500).json({ error: "Failed to fetch doctors by department" })
  }
})

// Handle creating a new appointment
appointmentRouter.post("/", async (req, res) => {
  try {
    const { department, day, start_time, end_time, doctor } = req.body

    // Validate department enum
    if (!allowedDepartments.includes(department)) {
      return res.status(400).json({ error: "Invalid department" })
    }

    // Validate required fields
    if (!day || !start_time || !end_time || !doctor) {
      return res.status(400).json({ error: "Missing required fields" })
    }

    // Validate time logic
    const startMinutes = extractTime(start_time)
    const endMinutes = extractTime(end_time)

    // Handle invalid times
    if (startMinutes === null || endMinutes === null) {
      return res.status(400).json({ error: "Invalid time format" })
    }

    console.log("Start time:", startMinutes, "End time:", endMinutes)

    if (startMinutes >= endMinutes) {
      return res.status(400).json({ error: "Start time must be before end time" })
    }

    // Check for overlapping time slots for the same doctor and day
    const overlappingAppointments = await Appointment.findOne({
      doctor,
      day,
      $or: [
        {
          start_time: { $lt: new Date(end_time) },
          end_time: { $gt: new Date(start_time) },
        },
      ],
    })

    if (overlappingAppointments) {
      return res.status(400).json({
        error: "Appointment overlaps with an existing one for this doctor and department.",
      })
    }

    // Create appointment
    const appointment = new Appointment({
      department,
      day,
      doctor,
      start_time,
      end_time,
    })

    await appointment.save()

    // ---------- ✅ Format the times nicely ----------
    const Notification = require("../models/notifications")

    const formatTime = (isoString, isArabic = false) => {
      const date = new Date(isoString)
      const options = {
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
        timeZone: "Africa/Cairo",
      }

      let time = date.toLocaleTimeString(isArabic ? "ar-EG" : "en-US", options)
      if (isArabic) {
        time = time.replace("ص", "صباحًا").replace("م", "مساءً")
      }
      return time
    }

    const formattedStartEn = formatTime(start_time)
    const formattedEndEn = formatTime(end_time)
    const formattedStartAr = formatTime(start_time, true)
    const formattedEndAr = formatTime(end_time, true)

    const appointmentTimeEn = `${formattedStartEn} - ${formattedEndEn}`
    const appointmentTimeAr = `${formattedStartAr} - ${formattedEndAr}`

    // ---------- ✅ Create notification ----------
    const notification = new Notification({
      receiverId: doctor,
      rule: "Doctor",
      title: "New Appointment Assigned",
      titleAr: "تم تعيين موعد جديد",
      message: `A new ${department} appointment has been added to your schedule in ${department} on ${day} from ${appointmentTimeEn}`,
      messageAr: `تم تعيين موعد جديد لك في قسم ${department} يوم ${day} من ${appointmentTimeAr}`,
      type: "create",
    })

    await notification.save()

    // ---------- ✅ Emit real-time notification ----------
    const io = req.app.get("io")
    const onlineUsers = req.app.get("onlineUsers")
    const socketId = onlineUsers.get(doctor)

    if (socketId) {
      const unreadNotifications = await Notification.find({
        receiverId: doctor,
        isRead: false,
      })

      io.to(socketId).emit("newNotification", {
        count: unreadNotifications.length,
        notifications: [notification],
      })
    }

    // ---------- ✅ Return success ----------
    return res.status(201).json({
      message: "Appointment created successfully",
      appointment,
    })
  } catch (error) {
    console.error("Error creating appointment:", error)
    return res.status(500).json({ error: "Failed to create appointment" })
  }
})


appointmentRouter.get("/findByDepartment/:department", async (req, res) => {
  try {
    const { department } = req.params

    // Validate department enum
    if (!allowedDepartments.includes(department)) {
      return res.status(400).json({ error: "Invalid department" })
    }

    const appointments = await Appointment.find({ department })
    return res.status(200).json({ appointments })
  } catch (error) {
    return res.status(500).json({ error: "Failed to fetch appointments" })
  }
})

// Handle fetching a single appointment by ID
appointmentRouter.get("/findById/:id", async (req, res) => {
  try {
    const appointment = await Appointment.findById({
      _id: req.params.id,
    }).populate("doctor")
    if (!appointment) {
      return res.status(404).json({ error: "Appointment not found" })
    }
    return res.status(200).json({ appointment })
  } catch (error) {
    return res.status(500).json({ error: "Failed to fetch appointment" })
  }
})

appointmentRouter.get("/", async (req, res) => {
  try {
    const appointments = await Appointment.find().populate("doctor")
    return res.status(200).json({ appointments })
  } catch (error) {
    return res.status(500).json({ error: "Failed to fetch appointments" })
  }
})

// Handle updating an appointment by ID
appointmentRouter.put("/:id", async (req, res) => {
  try {
    const { department, day, start_time, end_time, doctor } = req.body

    // Validate department enum
    if (!allowedDepartments.includes(department)) {
      return res.status(400).json({ error: "Invalid department" })
    }
    // Validate required fields
    if (!day || !start_time || !end_time || !doctor) {
      return res.status(400).json({ error: "Missing required fields" })
    }

    // Validate time logic
    const startMinutes = extractTime(start_time)
    const endMinutes = extractTime(end_time)

    // Handle invalid times
    if (startMinutes === null || endMinutes === null) {
      return res.status(400).json({ error: "Invalid time format" })
    }

    console.log("Start time:", startMinutes, "End time:", endMinutes)

    if (startMinutes >= endMinutes) {
      return res.status(400).json({ error: "Start time must be before end time" })
    }

    // Check for overlapping time slots for the same doctor, department, and day
    const overlappingAppointments = await Appointment.findOne({
      /* department, */
      doctor,
      day,
      _id: { $ne: req.params.id }, // Exclude current appointment
      $or: [
        {
          start_time: { $lt: new Date(end_time) },
          end_time: { $gt: new Date(start_time) },
        },
      ],
    })

    if (overlappingAppointments) {
      return res.status(400).json({
        error: "Appointment overlaps with an existing one for this doctor and department.",
      })
    }

    const updatedAppointment = await Appointment.findByIdAndUpdate(
      req.params.id,
      { department, day, start_time, end_time, doctor },
      { new: true },
    )

    if (!updatedAppointment) {
      return res.status(404).json({ error: "Appointment not found" })
    }

    return res.status(200).json({
      message: "Appointment updated successfully",
      appointment: updatedAppointment,
    })
  } catch (error) {
    return res.status(500).json({ error: "Failed to update appointment" })
  }
})

// UPDATED: Handle deleting an appointment by ID with student cleanup
appointmentRouter.delete("/:id", async (req, res) => {
  try {
    const appointmentId = req.params.id

    // First, delete all student assignments for this appointment
    await StudentsAppointmentDepartment.deleteMany({
      appointmentId: appointmentId,
    })

    // Then delete the appointment
    const deletedAppointment = await Appointment.findByIdAndDelete(appointmentId)

    if (!deletedAppointment) {
      return res.status(404).json({ error: "Appointment not found" })
    }

    return res.status(200).json({
      message: "Appointment and all student assignments deleted successfully",
    })
  } catch (error) {
    return res.status(500).json({ error: "Failed to delete appointment" })
  }
})

module.exports = appointmentRouter
