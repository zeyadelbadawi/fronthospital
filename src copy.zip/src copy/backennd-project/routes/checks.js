// routes/checks.js
const express = require("express")
const router = express.Router()
const Checks = require("../models/Checks")
const Money = require("../models/Money")
const mongoose = require("mongoose")

// Validation middleware
const validateCheckData = (req, res, next) => {
  const { checkNumber, amount, dueDate, patientId, programId, moneyId } = req.body

  const errors = []

  // Required field validation
  if (!checkNumber || checkNumber.trim() === "") {
    errors.push("Check number is required")
  }

  if (!amount || isNaN(amount) || Number.parseFloat(amount) <= 0) {
    errors.push("Valid amount greater than 0 is required")
  }

  if (!dueDate) {
    errors.push("Due date is required")
  } else {
    const dueDateObj = new Date(dueDate)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    if (dueDateObj < today) {
      errors.push("Due date cannot be in the past")
    }
  }

  if (!patientId || !mongoose.Types.ObjectId.isValid(patientId)) {
    errors.push("Valid patient ID is required")
  }

  if (!programId || !mongoose.Types.ObjectId.isValid(programId)) {
    errors.push("Valid program ID is required")
  }

  if (!moneyId || !mongoose.Types.ObjectId.isValid(moneyId)) {
    errors.push("Valid money record ID is required")
  }

  // Check number format validation (alphanumeric, 3-20 characters)
  if (checkNumber && !/^[a-zA-Z0-9]{3,20}$/.test(checkNumber.trim())) {
    errors.push("Check number must be 3-20 alphanumeric characters")
  }

  // Amount validation (max 6 digits before decimal, 2 after)
  if (amount && !/^\d{1,6}(\.\d{1,2})?$/.test(amount.toString())) {
    errors.push("Amount format is invalid (max 6 digits before decimal, 2 after)")
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: "Validation failed",
      errors: errors,
    })
  }

  next()
}

// POST - Create new check (without transactions)
router.post("/", validateCheckData, async (req, res) => {
  try {
    const { patientId, programId, moneyId, checkNumber, amount, dueDate, bankName, notes } = req.body

    // Check if check number already exists
    const existingCheck = await Checks.findOne({
      checkNumber: checkNumber.trim(),
      isActive: true,
    })

    if (existingCheck) {
      return res.status(400).json({
        success: false,
        message: "Check number already exists",
      })
    }

    // Verify money record exists
    const moneyRecord = await Money.findById(moneyId)
    if (!moneyRecord) {
      return res.status(404).json({
        success: false,
        message: "Money record not found",
      })
    }

    // Create new check
    const newCheck = new Checks({
      patientId,
      programId,
      moneyId,
      checkNumber: checkNumber.trim(),
      amount: Number.parseFloat(amount),
      dueDate: new Date(dueDate),
      bankName: bankName?.trim() || "",
      notes: notes?.trim() || "",
      status: "pending",
    })

    const savedCheck = await newCheck.save()

    res.status(201).json({
      success: true,
      message: "Check created successfully",
      data: savedCheck,
    })
  } catch (error) {
    console.error("Error creating check:", error)

    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: "Check number already exists",
      })
    }

    if (error.name === 'ValidationError') {
      const validationErrors = Object.values(error.errors).map(err => err.message)
      return res.status(400).json({
        success: false,
        message: "Validation failed",
        errors: validationErrors,
      })
    }

    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    })
  }
})

// GET - Get checks by money record ID
router.get("/money/:moneyId", async (req, res) => {
  try {
    const { moneyId } = req.params

    if (!mongoose.Types.ObjectId.isValid(moneyId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid money record ID",
      })
    }

    const checks = await Checks.find({
      moneyId: moneyId,
      isActive: true,
    })
      .populate("patientId", "name email phone")
      .sort({ dueDate: 1 })

    res.status(200).json({
      success: true,
      data: checks,
    })
  } catch (error) {
    console.error("Error fetching checks:", error)
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    })
  }
})

// GET - Get checks by patient ID
router.get("/patient/:patientId", async (req, res) => {
  try {
    const { patientId } = req.params
    const { status, overdue } = req.query

    if (!mongoose.Types.ObjectId.isValid(patientId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid patient ID",
      })
    }

    const query = {
      patientId: patientId,
      isActive: true,
    }

    // Filter by status if provided
    if (status && ["pending", "deposited", "cleared", "bounced", "cancelled"].includes(status)) {
      query.status = status
    }

    let checks = await Checks.find(query)
      .populate("patientId", "name email phone")
      .populate("moneyId", "invoiceId programType")
      .sort({ dueDate: 1 })

    // Filter overdue checks if requested
    if (overdue === "true") {
      checks = checks.filter((check) => check.isOverdue)
    }

    res.status(200).json({
      success: true,
      data: checks,
    })
  } catch (error) {
    console.error("Error fetching patient checks:", error)
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    })
  }
})

// PUT - Update check status
router.put("/:checkId/status", async (req, res) => {
  try {
    const { checkId } = req.params
    const { status, bouncedReason } = req.body

    if (!mongoose.Types.ObjectId.isValid(checkId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid check ID",
      })
    }

    if (!["pending", "deposited", "cleared", "bounced", "cancelled"].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid status",
      })
    }

    const check = await Checks.findById(checkId)
    if (!check) {
      return res.status(404).json({
        success: false,
        message: "Check not found",
      })
    }

    // Update status and related fields
    check.status = status

    if (status === "bounced" && bouncedReason) {
      check.bouncedReason = bouncedReason.trim()
    }

    const updatedCheck = await check.save()

    res.status(200).json({
      success: true,
      message: "Check status updated successfully",
      data: updatedCheck,
    })
  } catch (error) {
    console.error("Error updating check status:", error)
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    })
  }
})

// DELETE - Soft delete check
router.delete("/:checkId", async (req, res) => {
  try {
    const { checkId } = req.params

    if (!mongoose.Types.ObjectId.isValid(checkId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid check ID",
      })
    }

    const check = await Checks.findById(checkId)
    if (!check) {
      return res.status(404).json({
        success: false,
        message: "Check not found",
      })
    }

    // Only allow deletion of pending checks
    if (check.status !== "pending") {
      return res.status(400).json({
        success: false,
        message: "Only pending checks can be deleted",
      })
    }

    check.isActive = false
    check.status = "cancelled"
    await check.save()

    res.status(200).json({
      success: true,
      message: "Check deleted successfully",
    })
  } catch (error) {
    console.error("Error deleting check:", error)
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    })
  }
})

// GET - Get all checks with filters
router.get("/", async (req, res) => {
  try {
    const { status, overdue, page = 1, limit = 10, sortBy = "dueDate", sortOrder = "asc" } = req.query

    const query = { isActive: true }

    // Filter by status
    if (status && ["pending", "deposited", "cleared", "bounced", "cancelled"].includes(status)) {
      query.status = status
    }

    // Calculate pagination
    const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

    // Build sort object
    const sort = {}
    sort[sortBy] = sortOrder === "desc" ? -1 : 1

    let checks = await Checks.find(query)
      .populate("patientId", "name email phone")
      .populate("moneyId", "invoiceId programType")
      .sort(sort)
      .skip(skip)
      .limit(Number.parseInt(limit))

    // Filter overdue if requested
    if (overdue === "true") {
      checks = checks.filter((check) => check.isOverdue)
    }

    const total = await Checks.countDocuments(query)

    res.status(200).json({
      success: true,
      data: checks,
      pagination: {
        current: Number.parseInt(page),
        pages: Math.ceil(total / Number.parseInt(limit)),
        total: total,
      },
    })
  } catch (error) {
    console.error("Error fetching checks:", error)
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    })
  }
})

// Bulk create checks (for installment plans)
router.post("/bulk", async (req, res) => {
  try {
    const { checks, moneyId } = req.body

    if (!Array.isArray(checks) || checks.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Checks array is required and cannot be empty",
      })
    }

    if (!moneyId || !mongoose.Types.ObjectId.isValid(moneyId)) {
      return res.status(400).json({
        success: false,
        message: "Valid money record ID is required",
      })
    }

    // Verify money record exists
    const moneyRecord = await Money.findById(moneyId)
    if (!moneyRecord) {
      return res.status(404).json({
        success: false,
        message: "Money record not found",
      })
    }

    // Validate all checks first
    const validationErrors = []
    const checkNumbers = []

    for (let i = 0; i < checks.length; i++) {
      const check = checks[i]
      const errors = []

      if (!check.checkNumber || check.checkNumber.trim() === "") {
        errors.push(`Check ${i + 1}: Check number is required`)
      } else if (!/^[a-zA-Z0-9]{3,20}$/.test(check.checkNumber.trim())) {
        errors.push(`Check ${i + 1}: Check number must be 3-20 alphanumeric characters`)
      } else if (checkNumbers.includes(check.checkNumber.trim())) {
        errors.push(`Check ${i + 1}: Duplicate check number in request`)
      } else {
        checkNumbers.push(check.checkNumber.trim())
      }

      if (!check.amount || isNaN(check.amount) || Number.parseFloat(check.amount) <= 0) {
        errors.push(`Check ${i + 1}: Valid amount greater than 0 is required`)
      }

      if (!check.dueDate) {
        errors.push(`Check ${i + 1}: Due date is required`)
      } else {
        const dueDateObj = new Date(check.dueDate)
        const today = new Date()
        today.setHours(0, 0, 0, 0)

        if (dueDateObj < today) {
          errors.push(`Check ${i + 1}: Due date cannot be in the past`)
        }
      }

      if (!check.patientId || !mongoose.Types.ObjectId.isValid(check.patientId)) {
        errors.push(`Check ${i + 1}: Valid patient ID is required`)
      }

      if (!check.programId || !mongoose.Types.ObjectId.isValid(check.programId)) {
        errors.push(`Check ${i + 1}: Valid program ID is required`)
      }

      validationErrors.push(...errors)
    }

    if (validationErrors.length > 0) {
      return res.status(400).json({
        success: false,
        message: "Validation failed",
        errors: validationErrors,
      })
    }

    // Check for existing check numbers in database
    const existingChecks = await Checks.find({
      checkNumber: { $in: checkNumbers },
      isActive: true,
    })

    if (existingChecks.length > 0) {
      const existingNumbers = existingChecks.map(check => check.checkNumber)
      return res.status(400).json({
        success: false,
        message: "Some check numbers already exist",
        errors: existingNumbers.map(num => `Check number ${num} already exists`),
      })
    }

    // Create all checks
    const checksToCreate = checks.map(check => ({
      patientId: check.patientId,
      programId: check.programId,
      moneyId: moneyId,
      checkNumber: check.checkNumber.trim(),
      amount: Number.parseFloat(check.amount),
      dueDate: new Date(check.dueDate),
      bankName: check.bankName?.trim() || "",
      notes: check.notes?.trim() || "",
      status: "pending",
    }))

    const savedChecks = await Checks.insertMany(checksToCreate)

    res.status(201).json({
      success: true,
      message: `${savedChecks.length} checks created successfully`,
      data: savedChecks,
    })
  } catch (error) {
    console.error("Error creating bulk checks:", error)

    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: "One or more check numbers already exist",
      })
    }

    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    })
  }
})

module.exports = router
