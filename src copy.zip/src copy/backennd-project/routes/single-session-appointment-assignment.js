const express = require("express")
const router = express.Router()
const SingleSessionAppointmentAssignment = require("../models/SingleSessionAppointmentAssignment")
const SingleProgram = require("../models/SingleProgram")
const Doctor = require("../models/users/Doctor")
const Patient = require("../models/users/Patient")

// Assign a doctor to an appointment department
router.post("/assign", async (req, res) => {
  const { doctorId, appointmentId, patientId, department, assignedBy } = req.body

  try {
    // Validate appointment exists
    const appointment = await SingleProgram.findById(appointmentId)
    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" })
    }

    // Validate doctor exists
    const doctor = await Doctor.findById(doctorId)
    if (!doctor) {
      return res.status(404).json({ message: "Doctor not found" })
    }

    // Check if assignment already exists for this department
    const existingAssignment = await SingleSessionAppointmentAssignment.findOne({
      appointmentId,
      department,
      status: "active",
    })

    if (existingAssignment) {
      return res.status(400).json({ message: "This department is already assigned to a doctor" })
    }

    // Create new assignment
    const assignment = new SingleSessionAppointmentAssignment({
      appointmentId,
      doctorId,
      patientId,
      department,
      assignedBy: assignedBy || null,
    })

    const savedAssignment = await assignment.save()

    // Populate references
    const populatedAssignment = await SingleSessionAppointmentAssignment.findById(savedAssignment._id)
      .populate("doctorId", "username email")
      .populate("patientId", "name email")
      .populate("appointmentId")

    res.status(201).json({
      message: "Doctor assigned successfully",
      assignment: populatedAssignment,
    })
  } catch (error) {
    console.error("Error assigning doctor:", error)
    res.status(500).json({ message: "Error assigning doctor", error: error.message })
  }
})

// Get assignment for a specific appointment and department
router.get("/appointment/:appointmentId", async (req, res) => {
  const { appointmentId } = req.params
  const { department } = req.query

  try {
    const assignment = await SingleSessionAppointmentAssignment.findOne({
      appointmentId,
      department,
      status: "active",
    })
      .populate("doctorId", "username email")
      .populate("patientId", "name email")
      .populate("appointmentId")

    if (!assignment) {
      return res.status(200).json({ message: "No assignment found", assignment: null })
    }

    res.status(200).json({ assignment })
  } catch (error) {
    console.error("Error fetching assignment:", error)
    res.status(500).json({ message: "Error fetching assignment", error: error.message })
  }
})

// Get all assignments for a doctor
router.get("/doctor/:doctorId", async (req, res) => {
  const { doctorId } = req.params

  try {
    const assignments = await SingleSessionAppointmentAssignment.find({
      doctorId,
      status: "active",
    })
      .populate("appointmentId")
      .populate("patientId", "name email")
      .sort({ assignedAt: -1 })

    res.status(200).json({ assignments })
  } catch (error) {
    console.error("Error fetching doctor assignments:", error)
    res.status(500).json({ message: "Error fetching assignments", error: error.message })
  }
})

// Get all assignments for an appointment
router.get("/appointment-all/:appointmentId", async (req, res) => {
  const { appointmentId } = req.params

  try {
    const assignments = await SingleSessionAppointmentAssignment.find({
      appointmentId,
      status: "active",
    })
      .populate("doctorId", "username email")
      .populate("patientId", "name email")

    res.status(200).json({ assignments })
  } catch (error) {
    console.error("Error fetching appointment assignments:", error)
    res.status(500).json({ message: "Error fetching assignments", error: error.message })
  }
})

// Update an assignment (reassign to different doctor)
router.put("/:assignmentId", async (req, res) => {
  const { assignmentId } = req.params
  const { doctorId, appointmentId, patientId, department } = req.body

  try {
    const oldAssignment = await SingleSessionAppointmentAssignment.findById(assignmentId)
      .populate("doctorId", "username email _id")
      .populate("appointmentId")

    if (!oldAssignment) {
      return res.status(404).json({ message: "Assignment not found" })
    }

    // Validate new doctor exists
    const doctor = await Doctor.findById(doctorId)
    if (!doctor) {
      return res.status(404).json({ message: "Doctor not found" })
    }

    // Update assignment
    const updatedAssignment = await SingleSessionAppointmentAssignment.findByIdAndUpdate(
      assignmentId,
      {
        doctorId,
        appointmentId,
        patientId,
        department,
      },
      { new: true },
    )
      .populate("doctorId", "username email")
      .populate("patientId", "name email")
      .populate("appointmentId")

    res.status(200).json({
      message: "Assignment updated successfully",
      assignment: updatedAssignment,
      oldDoctorId: oldAssignment.doctorId._id,
      oldDoctorName: oldAssignment.doctorId.username || oldAssignment.doctorId.email,
    })
  } catch (error) {
    console.error("Error updating assignment:", error)
    res.status(500).json({ message: "Error updating assignment", error: error.message })
  }
})

// Delete an assignment (unassign doctor)
router.delete("/:assignmentId", async (req, res) => {
  const { assignmentId } = req.params

  try {
    const deletedAssignment = await SingleSessionAppointmentAssignment.findByIdAndDelete(assignmentId)

    if (!deletedAssignment) {
      return res.status(404).json({ message: "Assignment not found" })
    }

    res.status(200).json({ message: "Assignment deleted successfully" })
  } catch (error) {
    console.error("Error deleting assignment:", error)
    res.status(500).json({ message: "Error deleting assignment", error: error.message })
  }
})

module.exports = router
