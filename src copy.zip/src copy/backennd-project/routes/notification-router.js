const nodemailer = require("nodemailer")
const express = require("express")
const Notification = require("../models/notifications")
const Doctor = require("../models/users/Doctor")
const Admin = require("../models/users/Admin")
const HeadDoctor = require("../models/users/HeadDoctor")

const notificationRouter = express.Router()
const allowedRule = ["Patient", "Doctor", "Admin", "HeadDoctor", "Accountant"]

notificationRouter.post("/send", async (req, res) => {
  const { receiverId, receiverIds, rule, title, titleAr, message, messageAr, type } = req.body

  if (
    (!receiverId && (!receiverIds || !Array.isArray(receiverIds) || receiverIds.length === 0)) ||
    !rule ||
    !title ||
    !message ||
    !type
  ) {
    return res.status(400).json({ error: "Missing or invalid required fields" })
  }

  if (!allowedRule.includes(rule)) {
    return res.status(400).json({ error: "Invalid rule" })
  }

  const io = req.app.get("io") // Get socket instance
  const onlineUsers = req.app.get("onlineUsers") // Assumes it's registered in `app.set(...)`

  let savedNotifications = []

  if (receiverIds && Array.isArray(receiverIds)) {
    // Handle multiple notifications
    const notifications = receiverIds.map((id) => ({
      receiverId: id,
      rule,
      title,
      titleAr,
      message,
      messageAr,
      type,
    }))

    savedNotifications = await Notification.insertMany(notifications)

    // Emit to each online user
    receiverIds.forEach(async (id) => {
      const socketId = onlineUsers.get(id)
      if (socketId) {
        const newNotifications = await getUnreadData(id)
        io.to(socketId).emit("newNotification", newNotifications)
      }
    })
  } else {
    // Handle single notification
    const notification = new Notification({
      receiverId,
      rule,
      title,
      titleAr,
      message,
      messageAr,
      type,
    })

    const savedNotification = await notification.save()
    savedNotifications = savedNotification

    // Emit to online user
    const socketId = onlineUsers.get(receiverId)
    if (socketId) {
      const newNotifications = await getUnreadData(receiverId)
      console.log("Notification Counts:", newNotifications)
      io.to(socketId).emit("newNotification", newNotifications)
    }
  }

  return res.status(201).json({
    message: "Notification(s) created successfully",
    notifications: savedNotifications,
  })
})

notificationRouter.get("/", async (req, res) => {
  try {
    const notifications = await Notification.find()
    return res.status(200).json({ notifications })
  } catch (error) {
    return res.status(500).json({ error: "Failed to fetch notifications" })
  }
})

notificationRouter.get("/byId/:id", async (req, res) => {
  try {
    const { id } = req.params
    if (!id) {
      return res.status(400).json({ error: "Missing required fields" })
    }
    const notifications = await Notification.find({
      receiverId: id,
    }).sort({ createdAt: -1 })

    const unRead = await Notification.find({
      receiverId: id,
      isRead: false,
    })

    console.log("Notifications for userId:", id, notifications)

    if (!notifications) {
      return res.status(404).json({ error: "Notifications not found" })
    }
    return res.status(200).json({ notifications, count: unRead.length })
  } catch (error) {
    return res.status(500).json({ error: "Failed to fetch notifications" })
  }
})

async function getUnreadNotificationsCountByUserId(userId) {
  console.log("Fetching for userId:", userId)
  if (!userId) {
    throw new Error("Missing userId")
  }

  const notifications = await Notification.find({
    receiverId: userId,
    isRead: false,
  })

  return notifications.length
}

// Utility to get unread count and list
async function getUnreadData(userId) {
  const notifications = await Notification.find({
    receiverId: userId,
  }).sort({ createdAt: -1 })

  const unRead = await Notification.find({
    receiverId: userId,
    isRead: false,
  })

  return {
    count: unRead.length,
    notifications,
  }
}

// MARK AS READ
notificationRouter.put("/read/:id", async (req, res) => {
  try {
    const { id } = req.params

    const notification = await Notification.findByIdAndUpdate(id, { isRead: true }, { new: true })

    if (!notification) {
      return res.status(404).json({ error: "Notification not found" })
    }

    return res.status(200).json({ message: "Notification marked as read" })
  } catch (error) {
    return res.status(500).json({ error: "Failed to mark as read" })
  }
})

notificationRouter.get("/doctor-ids", async (req, res) => {
  try {
    // Keeping it for backward compatibility but it should not be used for new notifications
    const doctorIdss = await Doctor.find().distinct("_id")

    const doctorIds = doctorIdss.map((id) => id.toString())
    res.status(200).json(doctorIds)
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch doctor IDs", details: error.message })
  }
})

notificationRouter.get("/admin-headdoctor-ids", async (req, res) => {
  try {
    const adminIdss = await Admin.find().distinct("_id")
    const headDoctorIdss = await HeadDoctor.find().distinct("_id")

    const adminIds = adminIdss.map((id) => id.toString())
    const headDoctorIds = headDoctorIdss.map((id) => id.toString())

    res.status(200).json({ adminIds, headDoctorIds })
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch admin and head doctor IDs", details: error.message })
  }
})

notificationRouter.get("/accountant-ids", async (req, res) => {
  try {
    const Accountant = require("../models/users/Accountant")
    const accountantIdss = await Accountant.find().distinct("_id")
    const accountantIds = accountantIdss.map((id) => id.toString())
    res.status(200).json(accountantIds)
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch accountant IDs", details: error.message })
  }
})

module.exports = notificationRouter
