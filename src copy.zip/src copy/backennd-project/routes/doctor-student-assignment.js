const express = require("express")
const router = express.Router()
const Doctor = require("../models/users/Doctor")
const Patient = require("../models/users/Patient")
const Department = require("../models/department")
const DoctorStudentAssignment = require("../models/DoctorStudentAssignment")
const Notification = require("../models/notifications")
const { calculateAcademicYearEndDate } = require("../utils/academicYearHelper")

// Get doctors by department name (handles both string and ObjectId) - FIXED with better name handling
router.get("/doctors-by-department/:departmentName", async (req, res) => {
  try {
    const { departmentName } = req.params
    console.log("Fetching doctors for department:", departmentName)

    // First, try to find the department by name (case-insensitive)
    let department = await Department.findOne({
      name: { $regex: new RegExp(`^${departmentName}$`, "i") },
    })

    // If not found, try alternative names
    if (!department) {
      const alternativeNames = {
        ABA: ["Applied Behavior Analysis", "ABA", "Behavioral Analysis"],
        Speech: ["speech", "Speech Therapy", "Speech", "Speech-Language Pathology"],
        PT: ["physicalTherapy", "Physical Therapy", "PT", "Physiotherapy"],
        OT: ["OccupationalTherapy", "Occupational Therapy", "OT"],
        "Special Education": ["SpecialEducation", "Special Education", "Special Ed", "SPED"],
      }
      const searchNames = alternativeNames[departmentName] || [departmentName]
      for (const name of searchNames) {
        department = await Department.findOne({
          name: { $regex: new RegExp(`^${name}$`, "i") },
        })
        if (department) break
      }
    }

    // If still not found, create the department
    if (!department) {
      console.log("Department not found, creating:", departmentName)
      department = new Department({
        name: departmentName,
        description: `${departmentName} Department`,
        isActive: true,
      })
      await department.save()
      console.log("Created department:", department)
    }

    console.log("Using department:", department)

    // ✅ FIXED: Only use ObjectId matching for departments field
    const doctors = await Doctor.find({
      $and: [
        {
          // Only query by department ObjectId since departments field contains ObjectIds
          departments: department._id,
        },
        {
          $or: [{ role: "doctor" }, { role: { $exists: false } }],
        },
      ],
    }).populate("departments", "name")

    console.log("Found doctors:", doctors.length)

    // ✅ ENHANCED: Better debugging to see all available fields
    console.log("Raw doctor data:")
    doctors.forEach((doctor, index) => {
      console.log(`Doctor ${index + 1}:`, {
        _id: doctor._id,
        name: doctor.name,
        username: doctor.username,
        firstName: doctor.firstName,
        lastName: doctor.lastName,
        fullName: doctor.fullName,
        email: doctor.email,
        role: doctor.role,
        departments: doctor.departments?.map((d) => d.name),
        // Show all fields to debug
        allFields: Object.keys(doctor.toObject()),
      })
    })

    // ✅ ENHANCED: Create a display name for each doctor
    const doctorsWithDisplayName = doctors.map((doctor) => {
      // Try different name combinations
      const displayName =
        doctor.name ||
        doctor.username ||
        doctor.fullName ||
        (doctor.firstName && doctor.lastName ? `${doctor.firstName} ${doctor.lastName}` : null) ||
        doctor.firstName ||
        doctor.lastName ||
        doctor.email?.split("@")[0] ||
        "Unknown Doctor"

      return {
        _id: doctor._id,
        name: doctor.name,
        username: doctor.username,
        firstName: doctor.firstName,
        lastName: doctor.lastName,
        displayName: displayName,
        email: doctor.email,
        role: doctor.role,
        departments: doctor.departments,
        // Include original doctor object for compatibility
        ...doctor.toObject(),
      }
    })

    console.log(
      "Doctor details with display names:",
      doctorsWithDisplayName.map((d) => ({
        displayName: d.displayName,
        name: d.name,
        username: d.username,
        firstName: d.firstName,
        lastName: d.lastName,
        email: d.email,
        departments: d.departments?.map((dept) => dept.name),
        role: d.role,
      })),
    )

    // If no doctors found, let's check what doctors exist
    if (doctors.length === 0) {
      const allDoctors = await Doctor.find({}).populate("departments", "name")
      console.log("All doctors in database:")
      allDoctors.forEach((doctor, index) => {
        console.log(`All Doctor ${index + 1}:`, {
          _id: doctor._id,
          name: doctor.name,
          username: doctor.username,
          firstName: doctor.firstName,
          lastName: doctor.lastName,
          email: doctor.email,
          role: doctor.role,
          departments: doctor.departments?.map((d) => d.name),
          allFields: Object.keys(doctor.toObject()),
        })
      })
    }

    res.status(200).json({
      success: true,
      doctors: doctorsWithDisplayName, // Return enhanced doctors with display names
      department: department.name,
      departmentId: department._id,
    })
  } catch (error) {
    console.error("Error fetching doctors by department:", error)
    res.status(500).json({
      message: "Error fetching doctors by department",
      error: error.message,
      stack: process.env.NODE_ENV === "development" ? error.stack : undefined,
    })
  }
})

// Rest of your routes remain the same...
// Get all assignments with optional department filter
router.get("/all-assignments", async (req, res) => {
  try {
    const { department, page = 1, limit = 10 } = req.query
    console.log("Fetching assignments for department:", department)

    const query = { status: { $ne: "inactive" } }
    if (department) {
      query.department = { $regex: new RegExp(department, "i") }
    }

    const assignments = await DoctorStudentAssignment.find(query)
      .populate("doctor", "name email username firstName lastName")
      .populate("patient", "name email patientId phone")
      .sort({ assignedDate: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)

    const total = await DoctorStudentAssignment.countDocuments(query)

    console.log("Found assignments:", assignments.length)

    res.status(200).json({
      success: true,
      assignments: assignments,
      totalPages: Math.ceil(total / limit),
      currentPage: Number.parseInt(page),
      total: total,
    })
  } catch (error) {
    console.error("Error fetching assignments:", error)
    res.status(500).json({
      message: "Error fetching assignments",
      error: error.message,
    })
  }
})

// NEW ENDPOINT: Get students assigned to a specific doctor in a specific department
router.get("/doctor-students/:doctorId/:department", async (req, res) => {
  try {
    const { doctorId, department } = req.params
    const { page = 1, limit = 10, search = "" } = req.query

    console.log("Fetching students for doctor:", doctorId, "in department:", department)

    // Verify doctor exists
    const doctor = await Doctor.findById(doctorId)
    if (!doctor) {
      return res.status(404).json({
        success: false,
        message: "Doctor not found",
      })
    }

    // Build query
    const query = {
      doctor: doctorId,
      department: { $regex: new RegExp(department, "i") },
      status: { $ne: "inactive" },
    }

    // Handle search
    let patientIds = []
    if (search) {
      const patients = await Patient.find({
        $or: [
          { name: { $regex: search, $options: "i" } },
          { email: { $regex: search, $options: "i" } },
          { phone: { $regex: search, $options: "i" } },
          { patientId: { $regex: search, $options: "i" } },
        ],
      }).select("_id")
      patientIds = patients.map((p) => p._id)
      if (patientIds.length > 0) {
        query.patient = { $in: patientIds }
      } else {
        // No patients match search, return empty result
        return res.status(200).json({
          success: true,
          assignments: [],
          totalPages: 0,
          currentPage: Number.parseInt(page),
          total: 0,
        })
      }
    }

    // Fetch assignments
    const assignments = await DoctorStudentAssignment.find(query)
      .populate({
        path: "patient",
        select: "name email phone patientId dateOfBirth",
      })
      .populate({
        path: "doctor",
        select: "name email username firstName lastName",
      })
      .sort({ assignedDate: -1 })
      .limit(Number.parseInt(limit))
      .skip((Number.parseInt(page) - 1) * Number.parseInt(limit))

    const total = await DoctorStudentAssignment.countDocuments(query)

    console.log(`Found ${assignments.length} assignments for doctor ${doctorId} in ${department}`)

    res.status(200).json({
      success: true,
      assignments: assignments,
      totalPages: Math.ceil(total / limit),
      currentPage: Number.parseInt(page),
      total: total,
      doctor: {
        id: doctor._id,
        name:
          doctor.name ||
          doctor.username ||
          `${doctor.firstName || ""} ${doctor.lastName || ""}`.trim() ||
          "Unknown Doctor",
        email: doctor.email,
      },
    })
  } catch (error) {
    console.error("Error fetching doctor students:", error)
    res.status(500).json({
      success: false,
      message: "Error fetching doctor students",
      error: error.message,
    })
  }
})

// Assign student to doctor
router.post("/assign-student-to-doctor", async (req, res) => {
  try {
    const { doctor, patient, department, subscriptionEndDate, notes } = req.body
    console.log("[v0] Assignment request:", { doctor, patient, department })

    // Validate required fields
    if (!doctor || !patient || !department) {
      return res.status(400).json({
        message: "Doctor ID, Patient ID, and Department are required",
      })
    }

    // Check if doctor exists
    const doctorExists = await Doctor.findById(doctor)
    if (!doctorExists) {
      return res.status(404).json({ message: "Doctor not found" })
    }

    // Check if patient exists
    const patientExists = await Patient.findById(patient)
    if (!patientExists) {
      return res.status(404).json({ message: "Patient not found" })
    }

    // Check if assignment already exists
    const existingAssignment = await DoctorStudentAssignment.findOne({
      doctor: doctor,
      patient: patient,
      department: { $regex: new RegExp(department, "i") },
      status: { $ne: "inactive" },
    })

    if (existingAssignment) {
      return res.status(400).json({
        message: "This patient is already assigned to this doctor in this department",
      })
    }

    // Create new assignment
    const assignment = new DoctorStudentAssignment({
      doctor: doctor,
      patient: patient,
      department: department,
      subscriptionEndDate: subscriptionEndDate || calculateAcademicYearEndDate(),
      notes: notes || "",
      status: "active",
      assignedDate: new Date(),
    })

    await assignment.save()

    // Populate the assignment with doctor and patient details
    const populatedAssignment = await DoctorStudentAssignment.findById(assignment._id)
      .populate("doctor", "name email username firstName lastName")
      .populate("patient", "name email patientId")

    console.log("[v0] Created assignment:", populatedAssignment)

    try {
      const io = req.app.get("io")
      const onlineUsers = req.app.get("onlineUsers")

      console.log("[v0] io available:", !!io)
      console.log("[v0] onlineUsers available:", !!onlineUsers)
      console.log("[v0] Doctor ID:", doctor)
      console.log("[v0] Online users map:", Array.from(onlineUsers?.entries() || []))

      const patientName = patientExists.name || "Unknown Patient"
      const departmentName = department

      // Create notification
      const notification = new Notification({
        receiverId: doctor,
        rule: "Doctor",
        title: "New Patient Assignment",
        titleAr: "تعيين مريض جديد",
        message: `Patient "${patientName}" has been assigned to you in ${departmentName} department`,
        messageAr: `تم تعيين المريض "${patientName}" لك في قسم ${departmentName}`,
        type: "assignment",
      })

      await notification.save()
      console.log("[v0] Notification saved to database:", notification._id)

      // Emit real-time notification to doctor if online
      if (io && onlineUsers) {
        const socketId = onlineUsers.get(doctor.toString())
        console.log("[v0] Socket ID for doctor:", socketId)

        if (socketId) {
          const unreadNotifications = await Notification.find({
            receiverId: doctor,
            isRead: false,
          })
          console.log("[v0] Emitting notification to socket:", socketId)
          io.to(socketId).emit("newNotification", {
            count: unreadNotifications.length,
            notifications: [notification],
          })
          console.log("[v0] Notification emitted successfully")
        } else {
          console.log("[v0] Doctor is not currently online")
        }
      } else {
        console.log("[v0] Socket.io or onlineUsers not available")
      }

      console.log("[v0] Notification sent to doctor:", doctor)
    } catch (notificationError) {
      console.error("[v0] Error sending notification:", notificationError)
      // Don't fail the assignment if notification fails
    }

    res.status(201).json({
      success: true,
      message: "Student assigned to doctor successfully",
      assignment: populatedAssignment,
    })
  } catch (error) {
    console.error("[v0] Error assigning student to doctor:", error)
    res.status(500).json({
      message: "Error assigning student to doctor",
      error: error.message,
    })
  }
})

// NEW ENDPOINT: Update assignment (change doctor, subscription, notes)
router.put("/update-assignment/:assignmentId", async (req, res) => {
  try {
    const { assignmentId } = req.params
    const { doctor, subscriptionEndDate, notes } = req.body

    console.log("Update assignment request:", { assignmentId, doctor, subscriptionEndDate, notes })

    // Validate required fields
    if (!doctor) {
      return res.status(400).json({
        message: "Doctor ID is required",
      })
    }

    // Check if assignment exists
    const existingAssignment = await DoctorStudentAssignment.findById(assignmentId)
    if (!existingAssignment) {
      return res.status(404).json({ message: "Assignment not found" })
    }

    // Check if doctor exists
    const doctorExists = await Doctor.findById(doctor)
    if (!doctorExists) {
      return res.status(404).json({ message: "Doctor not found" })
    }

    // Check if trying to assign to a different doctor who already has this patient
    if (doctor !== existingAssignment.doctor.toString()) {
      const conflictingAssignment = await DoctorStudentAssignment.findOne({
        doctor: doctor,
        patient: existingAssignment.patient,
        department: { $regex: new RegExp(existingAssignment.department, "i") },
        status: { $ne: "inactive" },
        _id: { $ne: assignmentId }, // Exclude current assignment
      })

      if (conflictingAssignment) {
        return res.status(400).json({
          message: "This patient is already assigned to the selected doctor in this department",
        })
      }
    }

    // Update the assignment
    const updatedAssignment = await DoctorStudentAssignment.findByIdAndUpdate(
      assignmentId,
      {
        doctor: doctor,
        subscriptionEndDate: subscriptionEndDate || null,
        notes: notes || "",
        updatedAt: new Date(),
      },
      { new: true },
    )
      .populate("doctor", "name email username firstName lastName")
      .populate("patient", "name email patientId phone")

    console.log("Updated assignment:", updatedAssignment)

    if (doctor !== existingAssignment.doctor.toString()) {
      try {
        const io = req.app.get("io")
        const onlineUsers = req.app.get("onlineUsers")

        const patient = await Patient.findById(existingAssignment.patient)
        const patientName = patient?.name || "Unknown Patient"
        const departmentName = existingAssignment.department
        const oldDoctorId = existingAssignment.doctor.toString()

        const oldDoctorNotification = new Notification({
          receiverId: oldDoctorId,
          rule: "Doctor",
          title: "Patient Removed from Assignment",
          titleAr: "تم إزالة المريض من التعيين",
          message: `Patient "${patientName}" has been removed from your assignments in ${departmentName} department`,
          messageAr: `تم إزالة المريض "${patientName}" من تعييناتك في قسم ${departmentName}`,
          type: "assignment",
          isRead: false,
        })

        await oldDoctorNotification.save()

        // Emit real-time notification to old doctor if online
        const oldDoctorSocketId = onlineUsers.get(oldDoctorId)
        if (oldDoctorSocketId && io) {
          const unreadNotifications = await Notification.find({
            receiverId: oldDoctorId,
            isRead: false,
          })
          io.to(oldDoctorSocketId).emit("newNotification", {
            count: unreadNotifications.length,
            notifications: [oldDoctorNotification],
          })
        }

        console.log("Notification sent to old doctor:", oldDoctorId)

        // Create notification for new doctor
        const notification = new Notification({
          receiverId: doctor,
          rule: "Doctor",
          title: "New Patient Assignment",
          titleAr: "تعيين مريض جديد",
          message: `Patient "${patientName}" has been assigned to you in ${departmentName} department`,
          messageAr: `تم تعيين المريض "${patientName}" لك في قسم ${departmentName}`,
          type: "assignment",
          isRead: false,
        })

        await notification.save()

        // Emit real-time notification to new doctor if online
        const socketId = onlineUsers.get(doctor.toString())
        if (socketId && io) {
          const unreadNotifications = await Notification.find({
            receiverId: doctor,
            isRead: false,
          })
          io.to(socketId).emit("newNotification", {
            count: unreadNotifications.length,
            notifications: [notification],
          })
        }

        console.log("Notification sent to new doctor:", doctor)
      } catch (notificationError) {
        console.error("Error sending notification:", notificationError)
        // Don't fail the update if notification fails
      }
    }

    res.status(200).json({
      success: true,
      message: "Assignment updated successfully",
      assignment: updatedAssignment,
    })
  } catch (error) {
    console.error("Error updating assignment:", error)
    res.status(500).json({
      message: "Error updating assignment",
      error: error.message,
    })
  }
})

// Get assignments for a specific doctor (FIXED ENDPOINT)
router.get("/doctor-assignments/:doctorId", async (req, res) => {
  try {
    const { doctorId } = req.params
    const { department, page = 1, limit = 10, search = "" } = req.query

    console.log("Fetching assignments for doctor:", doctorId, "department:", department)

    // Verify doctor exists
    const doctor = await Doctor.findById(doctorId)
    if (!doctor) {
      return res.status(404).json({
        success: false,
        message: "Doctor not found",
      })
    }

    const query = {
      doctor: doctorId,
      status: { $ne: "inactive" },
    }

    if (department) {
      query.department = { $regex: new RegExp(department, "i") }
    }

    // Handle search
    if (search) {
      const patients = await Patient.find({
        $or: [
          { name: { $regex: search, $options: "i" } },
          { email: { $regex: search, $options: "i" } },
          { phone: { $regex: search, $options: "i" } },
          { patientId: { $regex: search, $options: "i" } },
        ],
      }).select("_id")
      const patientIds = patients.map((p) => p._id)
      if (patientIds.length > 0) {
        query.patient = { $in: patientIds }
      } else {
        return res.status(200).json({
          success: true,
          assignments: [],
          totalPages: 0,
          currentPage: Number.parseInt(page),
          total: 0,
        })
      }
    }

    const assignments = await DoctorStudentAssignment.find(query)
      .populate("patient", "name email patientId phone")
      .populate("doctor", "name email username firstName lastName")
      .sort({ assignedDate: -1 })
      .limit(Number.parseInt(limit))
      .skip((Number.parseInt(page) - 1) * Number.parseInt(limit))

    const total = await DoctorStudentAssignment.countDocuments(query)

    console.log("Found doctor assignments:", assignments.length)

    res.status(200).json({
      success: true,
      assignments: assignments,
      totalPages: Math.ceil(total / limit),
      currentPage: Number.parseInt(page),
      total: total,
    })
  } catch (error) {
    console.error("Error fetching doctor assignments:", error)
    res.status(500).json({
      message: "Error fetching doctor assignments",
      error: error.message,
    })
  }
})

// Unassign student from doctor
router.delete("/unassign-student/:assignmentId", async (req, res) => {
  try {
    const { assignmentId } = req.params

    const assignment = await DoctorStudentAssignment.findById(assignmentId)
      .populate("doctor", "name email username firstName lastName")
      .populate("patient", "name email patientId")

    if (!assignment) {
      return res.status(404).json({ message: "Assignment not found" })
    }

    // Update assignment status to inactive
    const updatedAssignment = await DoctorStudentAssignment.findByIdAndUpdate(
      assignmentId,
      { status: "inactive", unassignedDate: new Date() },
      { new: true },
    )

    try {
      const doctorId = assignment.doctor?._id
      const patientName = assignment.patient?.name || "Unknown Patient"
      const departmentName = assignment.department || "Department"

      if (doctorId) {
        const Notification = require("../models/notifications")
        const notification = new Notification({
          receiverId: doctorId,
          rule: "Doctor", // Added required rule field
          title: "Patient Removed",
          titleAr: "تم إزالة المريض",
          message: `Patient '${patientName}' has been removed from your assignments in ${departmentName} department`,
          messageAr: `تم إزالة المريض '${patientName}' من تعيينك في قسم ${departmentName}`,
          type: "assignment",
          isRead: false, // Changed from 'read' to 'isRead' to match schema
        })
        await notification.save()
        console.log("[v0] Notification saved for doctor removal:", doctorId)

        // Send real-time notification via socket.io if doctor is online
        const io = req.app.get("io")
        const onlineUsers = req.app.get("onlineUsers")

        if (io && onlineUsers && onlineUsers[doctorId]) {
          const socketId = onlineUsers[doctorId]
          io.to(socketId).emit("notification", {
            count: 1,
            notification: {
              _id: notification._id,
              title: notification.title,
              titleAr: notification.titleAr,
              message: notification.message,
              messageAr: notification.messageAr,
              type: notification.type,
              createdAt: notification.createdAt,
            },
          })
          console.log("[v0] Real-time notification sent to doctor:", doctorId)
        } else {
          console.log("[v0] Doctor not online or socket not available")
        }
      }
    } catch (notificationError) {
      console.error("[v0] Error sending notification:", notificationError)
      // Don't fail the unassignment if notification fails
    }

    res.status(200).json({
      success: true,
      message: "Student unassigned successfully",
      assignment: updatedAssignment,
    })
  } catch (error) {
    console.error("Error unassigning student:", error)
    res.status(500).json({
      message: "Error unassigning student",
      error: error.message,
    })
  }
})

// Update subscription end date
router.put("/update-subscription/:assignmentId", async (req, res) => {
  try {
    const { assignmentId } = req.params
    const { subscriptionEndDate, status } = req.body

    const assignment = await DoctorStudentAssignment.findByIdAndUpdate(
      assignmentId,
      {
        subscriptionEndDate: subscriptionEndDate,
        status: status || "active",
      },
      { new: true },
    )
      .populate("doctor", "name email username firstName lastName")
      .populate("patient", "name email patientId")

    if (!assignment) {
      return res.status(404).json({ message: "Assignment not found" })
    }

    res.status(200).json({
      success: true,
      message: "Subscription updated successfully",
      assignment: assignment,
    })
  } catch (error) {
    console.error("Error updating subscription:", error)
    res.status(500).json({
      message: "Error updating subscription",
      error: error.message,
    })
  }
})

module.exports = router
