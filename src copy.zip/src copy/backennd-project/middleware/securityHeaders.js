const helmet = require("helmet")

// Security headers middleware
const securityHeaders = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://www.google.com", "https://www.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", "data:"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["https://www.google.com"],
    },
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true,
  },
  noSniff: true,
  xssFilter: true,
  hidePoweredBy: true,
})

//enable after deployment


// HTTPS enforcement middleware
// const enforceHTTPS = (req, res, next) => {
//   // Skip in development
//   if (process.env.NODE_ENV === "development") {
//     return next()
//   }

//   // Check if request is secure
//   if (!req.secure && req.get("x-forwarded-proto") !== "https") {
//     return res.redirect(301, `https://${req.get("host")}${req.url}`)
//   }

//   next()
// }

module.exports = {
  securityHeaders,
 //enable after deployment
  // enforceHTTPS,
}
