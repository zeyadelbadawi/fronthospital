"use client";

import SpeechExam from "@/components/SpeechExam";

import Breadcrumb from "@/components/Breadcrumb";
import MasterLayout from "@/masterLayout/MasterLayout";

const page = () => {

  return (
    <MasterLayout>

<Breadcrumb 
  heading="Speech Exam" 
  title="Dashboard / Speech Exam Program" 
/>

      <SpeechExam />
    </MasterLayout>

  );
};

export default page;


