"use client";

import SpeechTest from "@/components/SpeechTest";

import Breadcrumb from "@/components/Breadcrumb";
import MasterLayout from "@/masterLayout/MasterLayout";

const page = () => {

  return (
    <MasterLayout>

<Breadcrumb 
  heading="Speech Test" 
  title="Dashboard / Speech Test Program" 
/>

      <SpeechTest />
    </MasterLayout>

  );
};

export default page;


