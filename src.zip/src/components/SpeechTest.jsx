"use client";
import React, { useState, useEffect, useRef, useCallback } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import axiosInstance from "@/helper/axiosSetup";
import Swal from "sweetalert2";
import { Overlay, Tooltip } from "react-bootstrap";
import GoalsTable from "./GoalsTable"; // Make sure this path matches your structure

const SpeechTest = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const planId = searchParams?.get("planId");
  const patientId = searchParams?.get("id");

  const [currentStep, setCurrentStep] = useState(0);
  const [fullPlan, setFullPlan] = useState(null);
  const [editingGoalIndex, setEditingGoalIndex] = useState(null);

  // بيانات عامة
  const [therapistSignature, setTherapistSignature] = useState("");

  // الحقول التقييمية لكل تبويب
  const [additionalNotes, setAdditionalNotes] = useState("");

  const [attendanceGoals, setAttendanceGoals] = useState([]);
  const [imitationGoals, setImitationGoals] = useState([]);
  const [receptiveLangGoals, setReceptiveLangGoals] = useState([]);
  const [expressiveLangGoals, setExpressiveLangGoals] = useState([]);

  const doneRef = useRef(null);
  const [showHint, setShowHint] = useState(false);

  // Fetch full plan from backend
  const fetchPlan = useCallback(async () => {
    if (!patientId) return;

    try {
      const plan = await axiosInstance.get(`/authentication/plan/${patientId}`).then(res => res.data);

      if (!plan) {
        Swal.fire("خطأ", "خطة العلاج غير موجودة", "error");
        return;
      }

      setTherapistSignature(plan.therapistSignature || "");
      setAdditionalNotes(plan.additionalNotes || "");

      setAttendanceGoals(
        (plan.attendanceGoals || []).map((g) => ({
          ...g,
          startDate: g.startDate ? new Date(g.startDate) : null,
          endDate: g.endDate ? new Date(g.endDate) : null,
          evaluation: g.evaluation || { status: "", notes: "" },
        }))
      );

      setImitationGoals(
        (plan.imitationGoals || []).map((g) => ({
          ...g,
          startDate: g.startDate ? new Date(g.startDate) : null,
          endDate: g.endDate ? new Date(g.endDate) : null,
          evaluation: g.evaluation || { status: "", notes: "" },
        }))
      );

      setReceptiveLangGoals(
        (plan.receptiveLangGoals || []).map((g) => ({
          ...g,
          startDate: g.startDate ? new Date(g.startDate) : null,
          endDate: g.endDate ? new Date(g.endDate) : null,
          evaluation: g.evaluation || { status: "", notes: "" },
        }))
      );

      setExpressiveLangGoals(
        (plan.expressiveLangGoals || []).map((g) => ({
          ...g,
          startDate: g.startDate ? new Date(g.startDate) : null,
          endDate: g.endDate ? new Date(g.endDate) : null,
          evaluation: g.evaluation || { status: "", notes: "" },
        }))
      );
    } catch (err) {
      console.error(err);
      Swal.fire("خطأ", "فشل في تحميل بيانات الخطة", "error");
    }
  }, [patientId]);


  useEffect(() => {
    if (patientId) {
      fetchPlan();
    }
  }, [patientId, fetchPlan]);

  // On tab change, load goals for that tab from fullPlan
  useEffect(() => {
    if (!fullPlan) return;

    const mapGoals = (goals) =>
      (goals || []).map((g) => ({
        ...g,
        startDate: g.startDate ? new Date(g.startDate) : null,
        endDate: g.endDate ? new Date(g.endDate) : null,
        evaluation: g.evaluation || { status: "", notes: "" },
      }));

    switch (currentStep) {
      case 1:
        setAttendanceGoals(mapGoals(fullPlan.attendanceGoals));
        break;
      case 2:
        setImitationGoals(mapGoals(fullPlan.imitationGoals));
        break;
      case 3:
        setReceptiveLangGoals(mapGoals(fullPlan.receptiveLangGoals));
        break;
      case 4:
        setExpressiveLangGoals(mapGoals(fullPlan.expressiveLangGoals));
        break;
      default:
        // Clear goals on general tab
        setAttendanceGoals([]);
        setImitationGoals([]);
        setReceptiveLangGoals([]);
        setExpressiveLangGoals([]);
        break;
    }
  }, [currentStep, fullPlan]);

  const getGoals = () => {
    switch (currentStep) {
      case 1:
        return attendanceGoals;
      case 2:
        return imitationGoals;
      case 3:
        return receptiveLangGoals;
      case 4:
        return expressiveLangGoals;
      default:
        return [];
    }
  };

  const setGoals = (newGoals) => {
    switch (currentStep) {
      case 1:
        setAttendanceGoals(newGoals);
        break;
      case 2:
        setImitationGoals(newGoals);
        break;
      case 3:
        setReceptiveLangGoals(newGoals);
        break;
      case 4:
        setExpressiveLangGoals(newGoals);
        break;
      default:
        break;
    }
  };

  const handleGoalChange = (index, field, value) => {
    const goals = getGoals();
    const newGoals = [...goals];
    if (field.startsWith("evaluation.")) {
      const subfield = field.split(".")[1];
      newGoals[index].evaluation = { ...newGoals[index].evaluation, [subfield]: value };
    } else {
      newGoals[index][field] = value;
    }
    setGoals(newGoals);
  };

  const addGoal = () => {
    const newGoal = {
      description: "",
      startDate: null,
      endDate: null,
      toolsUsed: "",
      evaluation: { status: "", notes: "" },
    };
    const goals = getGoals();
    setGoals([...goals, newGoal]);
  };

  const removeGoal = (index) => {
    const goals = getGoals();
    if (goals.length === 1) {
      setShowHint(true);
      setTimeout(() => setShowHint(false), 3000);
      return;
    }
    const newGoals = goals.filter((_, i) => i !== index);
    setGoals(newGoals);
  };

  // Save current tab only
  const handleSaveTab = async () => {
    if (!patientId) {
      Swal.fire("خطأ", "معرف المريض مفقود", "error");
      return;
    }
    let payload = { patientId };

    if (currentStep === 0) {
      if (!therapistSignature) {
        Swal.fire("خطأ", "التوقيع مطلوب", "error");
        return;
      }
      payload = {
        ...payload,
        therapistSignature,
      };
    } else if (currentStep === 1) {
      payload = {
        ...payload,
        attendanceGoals,
      };
    } else if (currentStep === 2) {
      payload = {
        ...payload,
        imitationGoals,
      };
    } else if (currentStep === 3) {
      payload = {
        ...payload,
        receptiveLangGoals,
      };
    } else if (currentStep === 4) {
      payload = {
        ...payload,
        expressiveLangGoals,
        additionalNotes,
      };
    }

    try {
      if (planId) {
        await axiosInstance.put(`/authentication/plan/${planId}`, payload);
        Swal.fire("نجاح", "تم حفظ البيانات", "success");
      } else {
        await axiosInstance.post(`/authentication/plan`, payload);
        Swal.fire("نجاح", "تم إنشاء خطة علاج جديدة", "success");
      }
      await fetchPlan();
    } catch (err) {
      console.error(err);
      Swal.fire("خطأ", "فشل في حفظ البيانات", "error");
    }
  };

  const nextStep = () => setCurrentStep((s) => Math.min(s + 1, 4));
  const prevStep = () => setCurrentStep((s) => Math.max(s - 1, 0));

  return (
    <div className="col-md-12">
      <div className="card p-4">

        <div style={{ display: "flex", gap: "30px", alignItems: "flex-start" }}>
          <div style={{
            flex: 4,
            minWidth: 0,
            maxHeight: "80vh",
            overflowY: "auto",
            padding: "40px ",
            border: "1px solid #ddd",
            borderRadius: "8px",
            boxShadow: "0 2px 8px rgb(0 0 0 / 0.1)",
            backgroundColor: "#fff",
          }}>

            <div className="form-wizard">
              <form onSubmit={(e) => e.preventDefault()}>
                <div className="form-wizard-header overflow-x-auto scroll-sm pb-8 my-32">
                  <ul className="list-unstyled form-wizard-list style-three">
                    {[0, 1, 2, 3, 4].map((step) => (
                      <li
                        key={step}
                        className={`form-wizard-list__item d-flex align-items-center gap-8 ${currentStep === step ? "active" : ""
                          }`}
                        onClick={() => setCurrentStep(step)}
                        style={{ cursor: "pointer" }}
                      >
                        <div className="form-wizard-list__line">
                          <span className="count">{step + 1}</span>
                        </div>
                        <span className="text text-xs fw-semibold">
                          {[
                            "بيانات أساسية",
                            "مهارات الحضور والانتباه",
                            "مهارة التقليد",
                            "مهارات اللغة الإستقبالية",
                            "مهارات اللغة التعبيردة",
                          ][step]}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Tab 0 - بيانات عامة */}
                {currentStep === 0 && (
                  <fieldset className="wizard-fieldset show">
                    <div className="row gy-3">



                      <div className="col-sm-6">
                        <label>توقيع المعالج</label>
                        <input
                          type="text"
                          className="form-control"
                          value={therapistSignature}
                          onChange={(e) => setTherapistSignature(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="form-group text-end mt-4 d-flex gap-3 justify-content-end">
                      <button type="button" className="btn btn-primary px-32" onClick={handleSaveTab}>
                        حفظ
                      </button>
                      <button type="button" className="btn btn-primary px-32" onClick={nextStep}>
                        التالي
                      </button>
                    </div>
                  </fieldset>
                )}

                {/* Tab 1 - حضور وانتباه */}
                {currentStep === 1 && (
                  <fieldset className="wizard-fieldset show">

                    <table className="table table-bordered mb-3">
                      <thead>
                        <tr>
                          <th>الوصف</th>
                          <th>تاريخ البداية</th>
                          <th>تاريخ النهاية</th>
                          <th>الأدوات المستخدمة</th>
                          <th>حالة التقييم</th>
                          <th>ملاحظات التقييم</th>
                          <th>إجراء</th>
                        </tr>
                      </thead>
                      <tbody>
                        {attendanceGoals.map((goal, idx) => {
                          return (
                            <tr key={idx}>
                              <td>
                                <input
                                  type="text"
                                  className="form-control"
                                  value={goal.description}
                                  onChange={(e) => handleGoalChange(idx, "description", e.target.value)}
                                />
                              </td>
                              <td>
                                <DatePicker
                                  selected={goal.startDate}
                                  onChange={(date) => handleGoalChange(idx, "startDate", date)}
                                  className="form-control"
                                  dateFormat="MM/dd/yyyy"
                                  isClearable
                                />
                              </td>
                              <td>
                                <DatePicker
                                  selected={goal.endDate}
                                  onChange={(date) => handleGoalChange(idx, "endDate", date)}
                                  className="form-control"
                                  dateFormat="MM/dd/yyyy"
                                  isClearable
                                />
                              </td>
                              <td>
                                <input
                                  type="text"
                                  className="form-control"
                                  value={goal.toolsUsed}
                                  onChange={(e) => handleGoalChange(idx, "toolsUsed", e.target.value)}
                                />


                              </td>
                              <td>
                                <select
                                  className="form-select"
                                  value={goal.evaluation.status}
                                  onChange={(e) => handleGoalChange(idx, "evaluation.status", e.target.value)}
                                >
                                  <option value="">-- اختر --</option>
                                  <option value="أتقن">أتقن</option>
                                  <option value="لا أتقن">لا أتقن</option>
                                  <option value="بمساعدة">بمساعدة</option>
                                </select>
                              </td>
                              <td>
                                <textarea
                                  className="form-control"
                                  value={goal.evaluation.notes}
                                  onChange={(e) => handleGoalChange(idx, "evaluation.notes", e.target.value)}
                                />
                              </td>
                              <td>

                                <button
                                  className="btn btn-danger btn-sm"
                                  onClick={() => removeGoal(idx)}
                                  type="button"
                                >
                                  حذف
                                </button>

                              </td>
                            </tr>
                          );
                        })}

                      </tbody>
                    </table>

                    <button className="btn btn-success mb-3" type="button" onClick={addGoal}>
                      + إضافة هدف جديد
                    </button>

                    <div className="form-group text-end mt-4 d-flex gap-3 justify-content-end">
                      <button type="button" className="btn btn-secondary px-32" onClick={prevStep}>
                        السابق
                      </button>
                      <button type="button" className="btn btn-primary px-32" onClick={handleSaveTab}>
                        حفظ
                      </button>
                      <button type="button" className="btn btn-primary px-32" onClick={nextStep}>
                        التالي
                      </button>
                    </div>
                  </fieldset>
                )}

                {/* Tab 2 - مهارة التقليد */}
                {currentStep === 2 && (
                  <fieldset className="wizard-fieldset show">

                    <table className="table table-bordered mb-3">
                      <thead>
                        <tr>
                          <th>الوصف</th>
                          <th>تاريخ البداية</th>
                          <th>تاريخ النهاية</th>
                          <th>الأدوات المستخدمة</th>
                          <th>حالة التقييم</th>
                          <th>ملاحظات التقييم</th>
                          <th>إجراء</th>
                        </tr>
                      </thead>
                      <tbody>
                        {imitationGoals.map((goal, idx) => (
                          <tr key={idx}>
                            <td>
                              <input
                                type="text"
                                className="form-control"
                                value={goal.description}
                                onChange={(e) => handleGoalChange(idx, "description", e.target.value)}
                              />
                            </td>
                            <td>
                              <DatePicker
                                selected={goal.startDate}
                                onChange={(date) => handleGoalChange(idx, "startDate", date)}
                                className="form-control"
                                dateFormat="MM/dd/yyyy"
                                isClearable
                              />
                            </td>
                            <td>
                              <DatePicker
                                selected={goal.endDate}
                                onChange={(date) => handleGoalChange(idx, "endDate", date)}
                                className="form-control"
                                dateFormat="MM/dd/yyyy"
                                isClearable
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                className="form-control"
                                value={goal.toolsUsed}
                                onChange={(e) => handleGoalChange(idx, "toolsUsed", e.target.value)}
                              />
                            </td>
                            <td>
                              <select
                                className="form-select"
                                value={goal.evaluation.status}
                                onChange={(e) => handleGoalChange(idx, "evaluation.status", e.target.value)}
                              >
                                <option value="">-- اختر --</option>
                                <option value="أتقن">أتقن</option>
                                <option value="لا أتقن">لا أتقن</option>
                                <option value="بمساعدة">بمساعدة</option>
                              </select>
                            </td>
                            <td>
                              <textarea
                                className="form-control"
                                value={goal.evaluation.notes}
                                onChange={(e) => handleGoalChange(idx, "evaluation.notes", e.target.value)}
                              />
                            </td>
                            <td>
                              <button
                                className="btn btn-danger btn-sm"
                                onClick={() => removeGoal(idx)}
                              >
                                حذف
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>

                    <button className="btn btn-success mb-3" type="button" onClick={addGoal}>
                      + إضافة هدف جديد
                    </button>

                    <div className="form-group text-end mt-4 d-flex gap-3 justify-content-end">
                      <button type="button" className="btn btn-secondary px-32" onClick={prevStep}>
                        السابق
                      </button>
                      <button type="button" className="btn btn-primary px-32" onClick={handleSaveTab}>
                        حفظ
                      </button>
                      <button type="button" className="btn btn-primary px-32" onClick={nextStep}>
                        التالي
                      </button>
                    </div>
                  </fieldset>
                )}

                {/* Tab 3 - مهارات اللغة الإستقبالية */}
                {currentStep === 3 && (
                  <fieldset className="wizard-fieldset show">


                    <table className="table table-bordered mb-3">
                      <thead>
                        <tr>
                          <th>الوصف</th>
                          <th>تاريخ البداية</th>
                          <th>تاريخ النهاية</th>
                          <th>الأدوات المستخدمة</th>
                          <th>حالة التقييم</th>
                          <th>ملاحظات التقييم</th>
                          <th>إجراء</th>
                        </tr>
                      </thead>
                      <tbody>
                        {receptiveLangGoals.map((goal, idx) => (
                          <tr key={idx}>
                            <td>
                              <input
                                type="text"
                                className="form-control"
                                value={goal.description}
                                onChange={(e) => handleGoalChange(idx, "description", e.target.value)}
                              />
                            </td>
                            <td>
                              <DatePicker
                                selected={goal.startDate}
                                onChange={(date) => handleGoalChange(idx, "startDate", date)}
                                className="form-control"
                                dateFormat="MM/dd/yyyy"
                                isClearable
                              />
                            </td>
                            <td>
                              <DatePicker
                                selected={goal.endDate}
                                onChange={(date) => handleGoalChange(idx, "endDate", date)}
                                className="form-control"
                                dateFormat="MM/dd/yyyy"
                                isClearable
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                className="form-control"
                                value={goal.toolsUsed}
                                onChange={(e) => handleGoalChange(idx, "toolsUsed", e.target.value)}
                              />
                            </td>
                            <td>
                              <select
                                className="form-select"
                                value={goal.evaluation.status}
                                onChange={(e) => handleGoalChange(idx, "evaluation.status", e.target.value)}
                              >
                                <option value="">-- اختر --</option>
                                <option value="أتقن">أتقن</option>
                                <option value="لا أتقن">لا أتقن</option>
                                <option value="بمساعدة">بمساعدة</option>
                              </select>
                            </td>
                            <td>
                              <textarea
                                className="form-control"
                                value={goal.evaluation.notes}
                                onChange={(e) => handleGoalChange(idx, "evaluation.notes", e.target.value)}
                              />
                            </td>
                            <td>
                              <button
                                className="btn btn-danger btn-sm"
                                onClick={() => removeGoal(idx)}
                              >
                                حذف
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>

                    <button className="btn btn-success mb-3" type="button" onClick={addGoal}>
                      + إضافة هدف جديد
                    </button>

                    <div className="form-group text-end mt-4 d-flex gap-3 justify-content-end">
                      <button type="button" className="btn btn-secondary px-32" onClick={prevStep}>
                        السابق
                      </button>
                      <button type="button" className="btn btn-primary px-32" onClick={handleSaveTab}>
                        حفظ
                      </button>
                      <button type="button" className="btn btn-primary px-32" onClick={nextStep}>
                        التالي
                      </button>
                    </div>
                  </fieldset>
                )}

                {/* Tab 4 - مهارات اللغة التعبيرية */}
                {currentStep === 4 && (
                  <fieldset className="wizard-fieldset show">


                    <table className="table table-bordered mb-3">
                      <thead>
                        <tr>
                          <th>الوصف</th>
                          <th>تاريخ البداية</th>
                          <th>تاريخ النهاية</th>
                          <th>الأدوات المستخدمة</th>
                          <th>حالة التقييم</th>
                          <th>ملاحظات التقييم</th>
                          <th>إجراء</th>
                        </tr>
                      </thead>
                      <tbody>
                        {expressiveLangGoals.map((goal, idx) => (
                          <tr key={idx}>
                            <td>
                              <input
                                type="text"
                                className="form-control"
                                value={goal.description}
                                onChange={(e) => handleGoalChange(idx, "description", e.target.value)}
                              />
                            </td>
                            <td>
                              <DatePicker
                                selected={goal.startDate}
                                onChange={(date) => handleGoalChange(idx, "startDate", date)}
                                className="form-control"
                                dateFormat="MM/dd/yyyy"
                                isClearable
                              />
                            </td>
                            <td>
                              <DatePicker
                                selected={goal.endDate}
                                onChange={(date) => handleGoalChange(idx, "endDate", date)}
                                className="form-control"
                                dateFormat="MM/dd/yyyy"
                                isClearable
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                className="form-control"
                                value={goal.toolsUsed}
                                onChange={(e) => handleGoalChange(idx, "toolsUsed", e.target.value)}
                              />
                            </td>
                            <td>
                              <select
                                className="form-select"
                                value={goal.evaluation.status}
                                onChange={(e) => handleGoalChange(idx, "evaluation.status", e.target.value)}
                              >
                                <option value="">-- اختر --</option>
                                <option value="أتقن">أتقن</option>
                                <option value="لا أتقن">لا أتقن</option>
                                <option value="بمساعدة">بمساعدة</option>
                              </select>
                            </td>
                            <td>
                              <textarea
                                className="form-control"
                                value={goal.evaluation.notes}
                                onChange={(e) => handleGoalChange(idx, "evaluation.notes", e.target.value)}
                              />
                            </td>
                            <td>
                              <button
                                className="btn btn-danger btn-sm"
                                onClick={() => removeGoal(idx)}
                              >
                                حذف
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>

                    <button className="btn btn-success mb-3" type="button" onClick={addGoal}>
                      + إضافة هدف جديد
                    </button>

                    <div className="mb-3">
                      <label>ملاحظات إضافية</label>
                      <textarea
                        className="form-control"
                        value={additionalNotes}
                        onChange={(e) => setAdditionalNotes(e.target.value)}
                      />
                    </div>

                    <div className="form-group text-end mt-4 d-flex gap-3 justify-content-end">
                      <button type="button" className="btn btn-secondary px-32" onClick={prevStep}>
                        السابق
                      </button>
                      <button type="button" className="btn btn-primary px-32" onClick={handleSaveTab}>
                        حفظ
                      </button>
                    </div>
                  </fieldset>
                )}
              </form>
            </div>
          </div>
          <div style={{
            flex: 3,
            minWidth: 0,
            maxHeight: "80vh",
            overflowY: "auto",
            padding: "40px",
            border: "1px solid #ddd",
            borderRadius: "8px",
            boxShadow: "0 2px 8px rgb(0 0 0 / 0.1)",
            backgroundColor: "#fff",
          }}>

            <GoalsTable

              attendanceGoals={attendanceGoals}
              imitationGoals={imitationGoals}
              receptiveLangGoals={receptiveLangGoals}
              expressiveLangGoals={expressiveLangGoals}
              therapistSignature={therapistSignature}
            //          language="en"

            />
          </div>
        </div>

        <Overlay target={doneRef.current} show={showHint} placement="right">
          <Tooltip id="hint-tooltip">يجب أن يكون هناك هدف واحد على الأقل في الخطة</Tooltip>
        </Overlay>
      </div>
    </div>
  );
};

export default SpeechTest;
