"use client";
import React, { useState, useEffect } from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import axiosInstance from "@/helper/axiosSetup";
import Swal from "sweetalert2";
import SpeechExamTable from "./SpeechExamTable"; // Make sure this path matches your structure

// Age ranges array (same as before)
const ageRanges = [
  "From birth to 2 months",
  "3-5 months",
  "6-8 months",
  "9-11 months",
  "1 year to 1 year 5 months",
  "From 1 year 6 months to 1 year 11 months",
  "From 2 years to 2 years 5 months",
  "From 2 years 6 months to 2 years 11 months",
  "From 3 years to 3 years 5 months",
  "From 3 years 6 months to 3 years 11 months",
  "From 4 years to 4 years 5 months",
  "From 4 years 6 months to 4 years 11 months",
  "From 5 years to 5 years 5 months",
  "From 5 years 6 months to 5 years 11 months",
  "From 6 years to 6 years 5 months",
  "From 6 years 6 months to 6 years 11 months",
  "From 7 years to 7 years 5 months",
];



const expressiveByAge = {
  "From birth to 2 months": [
    "1- الطفل يستطيع الرضاعة بدون شرقة",
    "2- الطفل يصدر أصوات ناعمة ويناغي (المناغاة)",
    "3- الطفل يستجيب للمتحدث إليه بالابتسام",
  ],
  "3-5 months": [
    "4- الطفل يستطيع تنويع نغمة البكاء (أحيانا طويل وأحيانا قصير واحيانا منخفض)",
    "5- الطفل يصدر أصواتا تدل على السعادة أو عدم السعادة (الحزن)",
    "6- الطفل يصدر أصواتا عند التحدث إليه مع تحريك يديه ورجليه",
  ],
  "6-8 months": [
    "7- الطفل يعترض باستخدام إشارات أو أصوات",
    "8- الطفل ينطق صوتين متحركين مثل (a/ - O/)",
    "9- الطفل ينطق صوتين ساكنين مختلفين مثل (W/ - d/)",
    "10- الطفل يمزج الأصوات لتكوين متطع",

  ],
  "9-11 months": [
    "11- الطفل يحاول جذب انتباه الآخرين له",
    "12- يستطيع الطفل ممارسة لعبة بسيطة مع الأم",
    "13- يكلم الأخرين عن طريق حركات وإشارات",

  ],
  "1 year to 1 year 5 months": [
    "14- الطفل قادر على أصدار صوت (يناغي) مصاحبة حركة اليدين والرجلين",
    "15- الطفل يشارك في لعبة مألوفة مع شخص آخر لمدة دقيقة إلى …",
    "16- يصدر الطفل مقطعين متصلين",
    "17- لديه مفردات لغوية على الأقل كلمة واحدة",
    "18- الطفل يحاول يبدأ هو اللعب",
    "19- يلتفت نظر الأبوين لوجود لبة أو شيء معين عن طريق الإشارة إليه",
    "20- يصدر أصوات ساكنة متنوعة",
  ],
  "From 1 year 6 months to 1 year 11 months": [
    "21- يستطيع إخراج مقاطع عديدة مكونة من ساكن ومتحرك أو ساكن ومتحرك وساكن أو ساكن ومتحرك وساكن ومتحرك",
    "22- ينطق الطفل مقاطع قصيرة مشابهة لكلام الأم",
    "23- الطفل يستطيع تقليد الكلمات",
    "24- يستخدم ألفاظ أو إشارات لطلب لعبة أو طعام",
    "25- يستخدم الطفل حوالي 5-10 كلمات في موقف معين",


  ],
  "From 2 years to 2 years 5 months": [
    "26- يسمى الطفل الأشياء الموجودة بالصور",
    "27- يستخدم الطفل كلمات وعبارات التخاطب أكثر من الإشارة",
    "28- يستخدم الطفل أسلوب الاستفهام",
    "29- الطفل يستخدم أساليب تدل على تطور البلاغة في لغته",
    "30- يعبر الطفل بجمل متنوعة أثناء الكلام التلقائي واللعب",
  ],
  "From 2 years 6 months to 2 years 11 months": [

    "31- الطفل يستخدم الجمل المنتظمة",
    "32- الطفل يستطيع النطق بجمل من 3-4 كلمات أثناء الكلام التلقائي",
    "33- يستطيع الطفل الإجابة على صيغة الاستفهام 'ماذا؟' أو 'إيه؟'",
    "34- يستطيع الطفل استخدام الفعل الدال على المضارع",
    "35- يستطيع الطفل استخدام أسماء متنوعة، وأفعال، وضمائر، وصفات",
  ],
  "From 3 years to 3 years 5 months": [
    "36- الطفل يستطيع النطق بجملة من 4-5 كلمات",
    "37- الطفل يسمِّي أشياء متعددة موجودة في صور",
    "38- يستطيع الطفل التعبير عن كيفية استخدام الشيء",
    "39- الطفل يعبر عن مفهوم الكم بكلمات مثل (كثير، قليل، يذكر عدد)",
    "40- الطفل يستخدم الملكية بوضوح (جزامة الولد)",
    "41- يعبر الطفل عن زمن الفعل الماضى",
  ],
  "From 3 years 6 months to 3 years 11 months": [
    "42- الطفل يستخدم الكلمات الدالة على الحال",
    "43- الطفل يجيب على الأسئلة بطريقة منطقية مع استخدام النفي",
    "44- يستطيع الطفل التعبير عن عكس الكلمة (المعكوسات)",
    "45- الطفل يجيب أسئلة عن الأحداث الافتراضية",
  ],
  "From 4 years to 4 years 5 months": [
    "46- الطفل يستجيب للسؤال عن المكان (أين؟)",
    "47- يستطيع الطفل إكمال المتناظرات (الجمل باستخدام مهارة التدا...)",
    "48- يستطيع الطفل تسمية الأشياء بعد وصف استخدامها",
    "49- يستطيع الطفل التعبير بالمبنى للمجهول",

  ],
  "From 4 years 6 months to 4 years 11 months": [
    "50- يستجيب الطفل للاستفهام 'لماذا؟' ويعطي تفسيراً",
    "51- يستطيع الطفل تصنيف المجموعات",
    "52 الطفل يعبر عن الصفات المتنوعة مثل ( طويل - قصير)",
    "53— يستطيع الطفل تكرار جمل بنطق صحيح وقواعد صحيحة بدون",
    "54- يستطيع الطفل التعبير عن المثنى",
    "55- يستطيع الطفل استخدام اسم الفاعل ( المهنة ) فى كلامه",
  ],
  "From 5 years to 5 years 5 months": [
    "56- يستطيع الطفل صياغة السؤال بطريقة صحيحة ومفهوم وبقواعد سلمية استجابة للتنبيه بالصور",
    "57- الطفل يستطيع وصف المتشابهات",
    "58- يستطيع الطفل تسمية الأشياء المكونة لكل مجموعة ضمنيه",
  ],
  "From 5 years 6 months to 5 years 11 months": [
    "59- يستطيع الطفل نطق اسم الشئ بعد نطق الصفة الخاصة به",
    "60- يعد ( يحصى ) الطفل ويعطى الرقم الصحيح ويسمى الاشكال والالوان",
    "61- يستطيع الطفل إصلاح المعاني ( المفهوم ) الخاطئة في الجملة",
  ],
  "From 6 years to 6 years 5 months": [
    "62- يستطيع الطفل تعريف الأسماء مع ذكر صفتين للشئ أو استخدامين",
    "63- يستطيع الطفل تصحيح أخطاء القواعد فى الجمل",
"64- يستطيع الطفل التعبير باستخدام كلمات تدل على الكمية ( فاضيه ،مليانه، أكثر من )",
"65- يستطيع الطفل التعبير عن التفضيل ( أكبر واحدة ، أطولهم )",

  ],
  "From 6 years 6 months to 6 years 11 months": [
    "66- يستطيع الطفل التير عن ظرف الزمان ( قبل و بعد)",
    "67- يستطيع الطفل سرد قصة (تشمل مقدمة، تسلسل أحداث ، خاتمة )",
    "68- يستخدم الطفل الجمع الغير منتظم ( التكسير )",
    
  ],
  "From 7 years to 7 years 5 months": [
    "69- يستطيع الطفل اتباع الوزن ( نفس نغمة الكلمة )",
    "70- يستطيع الطفل التعبير عن ظرف المكان ( فى الوسط حولين )",
    "71- يستطيع الطفل التعبير عن الاسم الموصول واسم الاشارة",
  ],
};

const receptiveByAge = {
  "From birth to 2 months": [
    "1- يشير (يلوح) بيديه ناحية المتحدث",
    "2- الطفل يستمتع بانتباه الأبوين إليه",
    "3- مع أصوات في البيئة (هل ينتبه الطفل لأي صوت؟)",
    "4- ينظر الطفل للمتحدث",
  ],
  "3-5 months": [
    "5- الطفل يدير رأسه لتحديد مصدر الصوت",
    "6- الطفل يبحث عن الشخص الذي يتحدث",
    "7- الطفل يستطيع التمييز بين صوتين مختلفين",
    "8- الطفل يضع الأشياء في فمه للتعرف عليها",
  ],
  "6-8 months": [
    "9- الطفل يهز الأشياء التي يلعب بها",
    "10- الطفل يوقف اللعب عندما تنادی علیه",
    "11- الطفل يتوقع ما سيحدث في الخطوة القادمة أثناء اللعب معه",
    "12- الطفل يبحث عن مصدر الصوت الذي لا يراه",
  ],
  "9-11 months": [
    "13- الطفل ينظر إلى الشخص واللعبة التي تنطق الأم اسمها وتُشير إليها",
    "14- يفهم الطفل قصدك لما تمد يدك وتقول 'تعالَ معي'",
    "15- الطفل يستجيب لأمر النهي 'لا'",
    "16- الطفل يفهم كلمة معينة لفرد في الأسرة أو شيء مألوف مثل 'بای باي'",
  ],
  "1 year to 1 year 5 months": [
    "17- الطفل يلعَب أكثر من لعبة في نفس التوقيت",
    "18- يستجيب الطفل للأوامر المألوفة بالإشارة",
    "19- يستطيع الطفل فهم الاستخدام الصحيح للأشياء أثناء اللعب",
    "20- التعرف على الأشياء المألوفة من وسط أشياء متنوعة",
  ],
  "From 1 year 6 months to 1 year 11 months": [
    "21- الطفل يتعرف على أجزاء الجسم (على نفسه أو دبدوبه)",
    "22- الطفل يفهم كلمات المنع مثل: ('بس، لا، كفاية')",
    "23- يتعرف على صور الأشياء المألوفة",
    "24- يستطيع فهم الأفعال الموجودة في الجملة الحوارية",
  ],
  "From 2 years to 2 years 5 months": [
    "25- يتعرف الطفل على الملابس",
    "26- الطفل يفهم كلمات تدل على المكان (جوف، بره، فوق)",
    "27- يستطيع الطفل التعرف على أحداث من خلال صور",
    "28- الطفل يفهم ضمائر متصلة ومنفصلة متنوعة",
  ],
  "From 2 years 6 months to 2 years 11 months": [
    "29- الطفل يفهم استخدام الأشياء",
    "30- يستطيع الطفل فهم علاقة الجزء/الكل",
    "31- يستطيع الطفل فهم كلمات الوصف البسيطة (كبير، صغير)",
    "32- الطفل ينفذ أمر مكون من خطوتين بدون الاستعانة بالإشارة",
  ],
  "From 3 years to 3 years 5 months": [
    "33- الطفل يفهم الكلمات الدالة على الكم (واحد، باقي، كل)",
    "34- الطفل يفهم الضمائر (هو، هي، بتاعه، بتاعها)",
    "35- الطفل يفهم النفي في الجملة",
  ],
  "From 3 years 6 months to 3 years 11 months": [
    "36- الطفل يتعرف على الألوان",
    "37- الطفل لديه قدرة على الاستنتاج",
    "38- يستطيع الطفل فهم التصنيف",
    "39- الطفل يفهم الصورة المتناظرة",
    "40- الطفل يفهم كلمات التفضيل مثل (أكثر من)",
  ],
  "From 4 years to 4 years 5 months": [
    "41- يستطيع الطفل فهم الجمل الطويلة",
    "42- الطفل يفهم الكلمات الدالة على الصفة (طويل – قصير)",
    "43- الطفل يفهم الكلمات الدالة على الأشكال",
    "44- يستطيع الطفل فهم كلمات الدالة على ظرف المكان (بين، وراء، جنب، قدام)",
  ],
  "From 4 years 6 months to 4 years 11 months": [
    "45- يستطيع الطفل فهم المهن",
    "46- يستطيع الطفل إدراك مفهوم الوقت (ليل – نهار)",
    "47- يستطيع الطفل فهم جملة طويلة",
    "48- الطفل يفهم جملة مكونة من اسم وصفة",
    "49- يفهم ويتعرف الطفل على الأشياء من خلال وصفها",

  ],
  "From 5 years to 5 years 5 months": [
    "50- يستطيع الطفل التعرف على الشيء الذي لا ينتمي إلى نفس المجموعة الضمنية",
    "51- يستطيع الطفل فهم الكلمات التي تدل على العدد ثلاثة",
    "52- يتعرف الطفل على أجزاء جسمه الأصعب",
    "53- يستطيع الطفل فهم الجمل المبنية للمجهول",

  ],
  "From 5 years 6 months to 5 years 11 months": [
    "54- يستطيع الطفل ترتيب الصور من الأكبر إلى الأصغر",
    "55- يفهم الطفل الكلمات التي تدل على الكمية (النصف، الكل)",
    "56- يفهم الطفل الكلمات الدالة على الترتيب الزمني (أول، ثاني)",
  ],
  "From 6 years to 6 years 5 months": [
    "57- يتعرف الطفل على الصوت الأول في الكلمة",
    "58- يستطيع الطفل فهم الكلمة الدالة على التحديد",
    "59- يدرك الطفل الأصوات التي لها نفس الوزن",
  ],
  "From 6 years 6 months to 6 years 11 months": [
    "60- يستطيع الطفل جمع وطرح أعداد إلى العدد خمسة",
    "61- يفهم الطفل الكلمات الدالة على فصول السنة",
    "62- يستطيع الطفل فهم الجملة الخطأ من ناحية القواعد",
  ],
  "From 7 years to 7 years 5 months": [
    // No receptive questions listed for this range in the provided data; you can fill if available
  ],
};

const SpeechExam = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [examDate, setExamDate] = useState(new Date());
  const [selectedAgeRange, setSelectedAgeRange] = useState("");  // البداية فارغة
  const [responses, setResponses] = useState({ expressive: {}, receptive: {} });
  const [overallNotes, setOverallNotes] = useState("");
  const [overallScores, setOverallScores] = useState({
    receptive: { raw: "", standard: "", languageAge: "", cutoffPoint: "" },
    expressive: { raw: "", standard: "", languageAge: "", cutoffPoint: "" },
    total: "",
  });

  const [weaknessReceptive, setWeaknessReceptive] = useState([]);
  const [weaknessExpressive, setWeaknessExpressive] = useState([]);
  const patientId = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("id") : null;
  const examDateIso = examDate.toISOString(); // or whatever format you use


    // 1) on mount, try to load existing data:
    useEffect(() => {
      if (!patientId || !selectedAgeRange) return;
    
      const qs = `?patientId=${patientId}&ageRange=${encodeURIComponent(selectedAgeRange)}`;
    
      axiosInstance.get(`/authentication/exam/expressive${qs}`)
        .then(({ data }) => {
          const eMap = {};
          data.expressiveQuestions.forEach(q => {
            eMap[q.questionNumber - 1] = {
              response: q.response,
              notes: q.notes,
            };
          });
          setResponses(r => ({ ...r, expressive: eMap }));
        })
        .catch(() => {
          setResponses(r => ({ ...r, expressive: {} }));
        });
    
      axiosInstance.get(`/authentication/exam/receptive${qs}`)
        .then(({ data }) => {
          const rMap = {};
          data.receptiveQuestions.forEach(q => {
            rMap[q.questionNumber - 1] = {
              response: q.response,
              notes: q.notes,
            };
          });
          setResponses(r => ({ ...r, receptive: rMap }));
        })
        .catch(() => {
          setResponses(r => ({ ...r, receptive: {} }));
        });
    }, [patientId, selectedAgeRange]);
    
    
  const handleWeaknessChange = (type, idx, value) => {
    if (type === "receptive") {
      setWeaknessReceptive((prev) => {
        const copy = [...prev];
        copy[idx] = value;
        return copy;
      });
    } else {
      setWeaknessExpressive((prev) => {
        const copy = [...prev];
        copy[idx] = value;
        return copy;
      });
    }
  };

  const addWeaknessPoint = (type) => {
    if (type === "receptive") {
      setWeaknessReceptive((prev) => [...prev, ""]);
    } else {
      setWeaknessExpressive((prev) => [...prev, ""]);
    }
  };

  const removeWeaknessPoint = (type, idx) => {
    if (type === "receptive") {
      setWeaknessReceptive((prev) => prev.filter((_, i) => i !== idx));
    } else {
      setWeaknessExpressive((prev) => prev.filter((_, i) => i !== idx));
    }
  };


  // Extract patientId from URL query param (adjust if needed)


  const handleScoreChange = (index, field, value) => {
    setOverallScores((scores) => {
      const newScores = [...scores];
      newScores[index] = { ...newScores[index], [field]: value };
      return newScores;
    });
  };


  // Handle answer change
  const handleChange = (section, idx, field, value) => {
    setResponses((r) => ({
      ...r,
      [section]: {
        ...r[section],
        [idx]: {
          ...((r[section] || {})[idx] || {}),
          [field]: value,
        },
      },
    }));
  };

  // Render question rows for expressive/receptive
  // Updated renderRows to handle empty lists with a message row
  const renderRows = (section, list) => {
    if (!list || list.length === 0) {
      return (
        <tr>
          <td colSpan={5} style={{ textAlign: "center", fontStyle: "italic", color: "#777" }}>
            {section === "receptive"
              ? "No receptive questions available for this age range."
              : "No expressive questions available for this age range."}
          </td>
        </tr>
      );
    }
    return list.map((text, i) => {
      const ans = responses[section]?.[i] || {};
      return (
        <tr key={i}>
          <td>{i + 1}</td>
          <td>{text}</td>
          <td style={{ textAlign: "center" }}>
  <label style={{ cursor: "pointer", userSelect: "none" }}>
    <input
      type="checkbox"
      checked={ans.response === "true"}  // "true" = صح
      onChange={(e) => handleChange(section, i, "response", e.target.checked ? "true" : "false")}
      style={{ width: 20, height: 20 }}
    />
    <span style={{ marginLeft: 6 }}>
      {ans.response === "true" ? "✓" : "✗"}
    </span>
  </label>
</td>

          
          <td>
            <textarea
              className="form-control"
              value={ans.notes || ""}
              onChange={(e) => handleChange(section, i, "notes", e.target.value)}
            />
          </td>
        </tr>
      );
    });
  };

  const handleSaveExpressive = async () => {
    if (!patientId) return Swal.fire("خطأ","معرف المريض مفقود","error");
  
    const expressiveQuestions = (expressiveByAge[selectedAgeRange]||[]).map((text,i)=>({
      questionNumber: i+1,
      questionText:   text,
      response: responses.expressive[i]?.response === "true",  // true/false boolean
      notes:          responses.expressive[i]?.notes     || "",
    }));
  
    try {
      await axiosInstance.post('/authentication/exam/expressive', {
        patientId,
        ageRange: selectedAgeRange.trim(),  // remove leading/trailing spaces if أي
        expressiveQuestions,
      });
      Swal.fire("نجاح","تم حفظ مهارات التعبيرية","success");
    } catch(e) {
      console.error(e);
      Swal.fire("خطأ","فشل الحفظ","error");
    }
  };

  const handleSaveReceptive = async () => {
    if (!patientId) return Swal.fire("خطأ","معرف المريض مفقود","error");
  
    const receptiveQuestions = (receptiveByAge[selectedAgeRange]||[]).map((text,i) => ({
      questionNumber: i + 1,
      questionText: text,
      response: responses.receptive[i]?.response === "true",  // يجب استخدام responses.receptive وليس expressive
      notes: responses.receptive[i]?.notes || "",
    }));
  
    try {
      await axiosInstance.post('/authentication/exam/receptive', {
        patientId,
        receptiveQuestions,
        ageRange: selectedAgeRange.trim(),
      });
      Swal.fire("نجاح","تم حفظ مهارات الإستقبالية","success");
    } catch(e) {
      console.error(e);
      Swal.fire("خطأ","فشل الحفظ","error");
    }
  };
  
  
  const handleSaveScores = async () => {
    if (!patientId) return Swal.fire("خطأ","معرف المريض مفقود","error");
  
    try {
      await axiosInstance.post('/authentication/exam/scores', {
        patientId,
        examDate,
        overallNotes,
        overallScores,
        weaknessReceptive,
        weaknessExpressive,
      });
      Swal.fire("نجاح","تم حفظ التقييم العام","success");
    } catch(e) {
      console.error(e);
      Swal.fire("خطأ","فشل الحفظ","error");
    }
  };
  

  
  // Next and previous navigation
  const nextStep = () => setCurrentStep((s) => Math.min(s + 1, 4));
  const prevStep = () => setCurrentStep((s) => Math.max(s - 1, 0));

  return (
    <div className="col-md-12">
      <div className="card p-4">
        <div style={{ display: "flex", gap: "30px", alignItems: "flex-start" }}>
          {/* Left wizard tabs */}
          <div
            style={{
              flex: 4,
              minWidth: 0,
              maxHeight: "80vh",
              overflowY: "auto",
              padding: "40px",
              border: "1px solid #ddd",
              borderRadius: "8px",
              boxShadow: "0 2px 8px rgb(0 0 0 / 0.1)",
              backgroundColor: "#fff",
            }}
          >
            <div className="form-wizard">
              <form onSubmit={(e) => e.preventDefault()}>
                <div className="form-wizard-header overflow-x-auto scroll-sm pb-8 my-32">
                  <ul className="list-unstyled form-wizard-list style-three">
                    {[0, 1, 2, 3].map((step) => (
                      <li
                        key={step}
                        className={`form-wizard-list__item d-flex align-items-center gap-8 ${currentStep === step ? "active" : ""
                          }`}
                        onClick={() => setCurrentStep(step)}
                        style={{ cursor: "pointer" }}
                      >
                        <div className="form-wizard-list__line">
                          <span className="count">{step + 1}</span>
                        </div>
                        <span className="text text-xs fw-semibold">
                          {[
                            "الفئة العمرية",
                            "مهارات اللغة التعبيرية",
                            "مهارات اللغة الإستقبالية",
                            "التقيم العام",
                          ][step]}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Tab 0: Date and Age */}
                {/* Tab 0: Date and Age */}
                {currentStep === 0 && (
                  <fieldset className="wizard-fieldset show">
                    <div style={{ maxWidth: "500px", margin: "auto" }}>
                      <h4 className="mb-4" style={{ borderBottom: "2px solid #007bff", paddingBottom: "8px", textAlign: "center" }}>
                        الفئة العمرية      </h4>
                      <div className="row gy-3">
                        <div className="col-12">
                          <select
                            className="form-select"
                            value={selectedAgeRange}
                            onChange={(e) => setSelectedAgeRange(e.target.value)}
                          >
                            {/* placeholder لاختيار الفئة العمرية */}
                            <option value="" disabled>-- اختر الفئة العمرية --</option>
                            {ageRanges.map((r) => (
                              <option key={r} value={r}>
                                {r}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="col-12 mt-4 text-end">
                          <button type="button" className="btn btn-primary px-32" onClick={nextStep}
                            style={{ marginTop: "20px" }}
                            disabled={!selectedAgeRange}    // معطّل إذا الفئة لم تُحدَّد

                          >
                            التالي
                          </button>
                        </div>
                      </div>
                    </div>
                  </fieldset>
                )}

                {/* Tab 1: Expressive questions */}
                {/* Tab 1: Expressive questions */}
                {currentStep === 1 && (
                  <fieldset className="wizard-fieldset show">
                    <div style={{ maxWidth: "800px", margin: "auto" }}>
                      <h4 className="mb-4" style={{ borderBottom: "2px solid #007bff", paddingBottom: "8px", textAlign: "center" }}>
                        مهارات اللغة التعبيرية
                      </h4>
                      <table
                        className="table table-bordered mb-4"
                        style={{ borderColor: "#dee2e6", fontSize: "1rem" }}
                      >
                        <thead className="table-primary">
                          <tr>
                            <th>#</th>
                            <th>الوصف</th>
                            <th>الحالة</th>
                            <th>ملاحظات</th>
                          </tr>
                        </thead>
                        <tbody>{renderRows("expressive", expressiveByAge[selectedAgeRange])}</tbody>
                      </table>

                      <div className="form-group text-end mt-3 d-flex gap-3 justify-content-end">
                        <button type="button" className="btn btn-secondary px-32" onClick={prevStep}>
                          السابق
                        </button>
                        <button type="button" className="btn btn-primary px-32" onClick={handleSaveExpressive}>
                          حفظ
                        </button>
                        <button type="button" className="btn btn-primary px-32" onClick={nextStep}>
                          التالي
                        </button>
                      </div>
                    </div>
                  </fieldset>
                )}

                {/* Tab 2: Receptive questions */}
                {currentStep === 2 && (
                  <fieldset className="wizard-fieldset show">
                    <div style={{ maxWidth: "800px", margin: "auto" }}>
                      <h4 className="mb-4" style={{ borderBottom: "2px solid #007bff", paddingBottom: "8px", textAlign: "center" }}>
                        مهارات اللغة الإستقبالية
                      </h4>
                      <table
                        className="table table-bordered mb-4"
                        style={{ borderColor: "#dee2e6", fontSize: "1rem" }}
                      >
                        <thead className="table-primary">
                          <tr>
                            <th>#</th>
                            <th>الوصف</th>
                            <th>الحالة</th>
                            <th>ملاحظات</th>
                          </tr>
                        </thead>
                        <tbody>{renderRows("receptive", receptiveByAge[selectedAgeRange])}</tbody>
                      </table>

                      <div className="form-group text-end mt-3 d-flex gap-3 justify-content-end">
                        <button type="button" className="btn btn-secondary px-32" onClick={prevStep}>
                          السابق
                        </button>
                        <button type="button" className="btn btn-primary px-32" onClick={handleSaveReceptive}>
                          حفظ
                        </button>
                        <button type="button" className="btn btn-primary px-32" onClick={nextStep}>
                          التالي
                        </button>
                      </div>
                    </div>
                  </fieldset>
                )}

                {/* Tab 3: Notes and scoring image */}

                {currentStep === 3 && (
                  <fieldset className="wizard-fieldset show">
                    <div style={{ maxWidth: "800px", margin: "auto" }}>
                      {/* عنوان الجدول */}
                      <h4 className="mb-4" style={{ borderBottom: "2px solid #007bff", paddingBottom: "8px", textAlign: "center" }}>
                        درجات التقييم
                      </h4>
                      <table
                        className="table table-bordered text-center mb-5"
                        style={{ borderColor: "#a6b5cc", fontSize: "1rem" }}>
                        <thead>
                          <tr>
                            <th></th> {/* خليها فاضية عشان العمود الرأسي */}
                            <th style={{ backgroundColor: '#cfe2ff' }}>الدرجة الخام</th>
                            <th style={{ backgroundColor: '#cfe2ff' }}>الدرجة المعيارية</th>
                            <th style={{ backgroundColor: '#cfe2ff' }}>العمر اللغوي المكافئ</th>
                            <th style={{ backgroundColor: '#cfe2ff' }}>نقطة الحد الفاصل</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <th className="align-middle"
                              style={{ backgroundColor: "#cfe2ff" }}
                            >اللغة الاستقبالية</th>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                value={overallScores.receptive.raw}
                                onChange={(e) =>
                                  setOverallScores((prev) => ({
                                    ...prev,
                                    receptive: { ...prev.receptive, raw: e.target.value },
                                  }))
                                }
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                value={overallScores.receptive.standard}
                                onChange={(e) =>
                                  setOverallScores((prev) => ({
                                    ...prev,
                                    receptive: { ...prev.receptive, standard: e.target.value },
                                  }))
                                }
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                value={overallScores.receptive.chronologicalAge || ""}
                                onChange={(e) =>
                                  setOverallScores((prev) => ({
                                    ...prev,
                                    receptive: { ...prev.receptive, chronologicalAge: e.target.value },
                                  }))
                                }
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                value={overallScores.receptive.cutoffPoint}
                                onChange={(e) =>
                                  setOverallScores((prev) => ({
                                    ...prev,
                                    receptive: { ...prev.receptive, cutoffPoint: e.target.value },
                                  }))
                                }
                              />
                            </td>
                          </tr>
                          <tr>
                            <th className="align-middle"
                              style={{ backgroundColor: "#cfe2ff" }}
                            >اللغة التعبيرية</th>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                value={overallScores.expressive.raw}
                                onChange={(e) =>
                                  setOverallScores((prev) => ({
                                    ...prev,
                                    expressive: { ...prev.expressive, raw: e.target.value },
                                  }))
                                }
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                value={overallScores.expressive.standard}
                                onChange={(e) =>
                                  setOverallScores((prev) => ({
                                    ...prev,
                                    expressive: { ...prev.expressive, standard: e.target.value },
                                  }))
                                }
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                value={overallScores.expressive.chronologicalAge || ""}
                                onChange={(e) =>
                                  setOverallScores((prev) => ({
                                    ...prev,
                                    expressive: { ...prev.expressive, chronologicalAge: e.target.value },
                                  }))
                                }
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                value={overallScores.expressive.cutoffPoint}
                                onChange={(e) =>
                                  setOverallScores((prev) => ({
                                    ...prev,
                                    expressive: { ...prev.expressive, cutoffPoint: e.target.value },
                                  }))
                                }
                              />
                            </td>
                          </tr>
                          <tr>
                            <th className="align-middle"
                              style={{ backgroundColor: "#cfe2ff" }}
                            >المجموع</th>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                value={overallScores.expressive.raw}
                                onChange={(e) =>
                                  setOverallScores((prev) => ({
                                    ...prev,
                                    expressive: { ...prev.expressive, raw: e.target.value },
                                  }))
                                }
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                value={overallScores.expressive.standard}
                                onChange={(e) =>
                                  setOverallScores((prev) => ({
                                    ...prev,
                                    expressive: { ...prev.expressive, standard: e.target.value },
                                  }))
                                }
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                value={overallScores.expressive.chronologicalAge || ""}
                                onChange={(e) =>
                                  setOverallScores((prev) => ({
                                    ...prev,
                                    expressive: { ...prev.expressive, chronologicalAge: e.target.value },
                                  }))
                                }
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                value={overallScores.expressive.cutoffPoint}
                                onChange={(e) =>
                                  setOverallScores((prev) => ({
                                    ...prev,
                                    expressive: { ...prev.expressive, cutoffPoint: e.target.value },
                                  }))
                                }
                              />
                            </td>
                          </tr>
                        </tbody>
                      </table>
                      {/* نقاط الضعف باللغة الاستقبالية */}
                      <section style={{ marginBottom: "30px" }}>
                        <h5 style={{ color: "#dc3545", marginBottom: "12px" }}>
                          نقاط الضعف باللغة الاستقبالية للطفل
                        </h5>
                        {weaknessReceptive.map((point, idx) => (
                          <div key={idx} className="d-flex gap-2 mb-3 align-items-center">
                            <input
                              type="number"
                              className="form-control"
                              value={point}
                              onChange={(e) => handleWeaknessChange("receptive", idx, e.target.value)}
                              placeholder={`نقطة ${idx + 1}`}
                              style={{ flex: 1 }}
                            />
                            <button
                              type="button"
                              className="btn btn-outline-danger btn-sm"
                              onClick={() => removeWeaknessPoint("receptive", idx)}
                              title="حذف"
                            >
                              حذف
                            </button>
                          </div>
                        ))}
                        <button
                          type="button"
                          className="btn btn-outline-success btn-sm"
                          style={{ marginTop: "10px" }}
                          onClick={() => addWeaknessPoint("receptive")}
                        >
                          + إضافة نقطة جديدة
                        </button>
                      </section>
                      {/* نقاط الضعف باللغة التعبيرية */}
                      <section>
                        <h5 style={{ color: "#0d6efd", marginBottom: "12px" }}>
                          نقاط الضعف باللغة التعبيرية للطفل
                        </h5>
                        {weaknessExpressive.map((point, idx) => (
                          <div key={idx} className="d-flex gap-2 mb-3 align-items-center">
                            <input
                              type="number"
                              className="form-control"
                              value={point}
                              onChange={(e) => handleWeaknessChange("expressive", idx, e.target.value)}
                              placeholder={`نقطة ${idx + 1}`}
                              style={{ flex: 1 }}
                            />
                            <button
                              type="button"
                              className="btn btn-outline-danger btn-sm"
                              onClick={() => removeWeaknessPoint("expressive", idx)}
                              title="حذف"
                            >
                              حذف
                            </button>
                          </div>
                        ))}
                        <button
                          type="button"
                          className="btn btn-outline-success btn-sm"
                          style={{ marginTop: "10px" }}
                          onClick={() => addWeaknessPoint("expressive")}
                        >
                          + إضافة نقطة جديدة
                        </button>
                      </section>
                      {/* أزرار التنقل والحفظ */}
                      <div className="form-group text-end mt-5 d-flex gap-3 justify-content-end">
                        <button type="button" className="btn btn-secondary px-32" onClick={prevStep}>
                          السابق
                        </button>
                        <button type="button" className="btn btn-primary px-32" onClick={handleSaveScores}>
                          حفظ
                        </button>
                      </div>
                    </div>
                  </fieldset>
                )}
              </form>
            </div>
          </div>
          {/* Right empty panel or summary */}
          <div
            style={{
              flex: 3,
              minWidth: 0,
              maxHeight: "80vh",
              overflowY: "auto",
              padding: "40px",
            }}
          >
<SpeechExamTable
  patientId="682cbad358274f52d374a4ae"
  ageRange="From birth to 2 months"
  language="ar"  // أو "en"
/>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SpeechExam;
