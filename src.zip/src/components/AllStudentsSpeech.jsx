'use client';

import { useState, useEffect } from "react";
import axios from "axios";
import { Icon } from "@iconify/react/dist/iconify.js";
import Link from "next/link";
import { useRouter } from "next/navigation";
import axiosInstance from "../helper/axiosSetup";

const AllStudentsSpeech = () => {
  const [assignments, setAssignments] = useState([]);  // بدل patients خلينا assignments
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const fetchAssignments = async () => {
      setLoading(true);
      try {
        // استدعاء endpoint يعيد المرضى المعينين فقط
        const response = await axiosInstance.get('/authentication/assignments', {
          params: {
            page: currentPage,
            search: search,
            limit: 10
          }
        });

        // response.data هو مصفوفة من التعيينات، كل تعيين يحتوي على patientId مع بيانات المريض
        setAssignments(response.data);
        // افتراضياً لو ما في totalPages من السيرفر: احسبها بناءً على طول البيانات (ممكن تحتاج إضافة في backend)
        setTotalPages(1); // لو عندك pagination بالـ backend حدثها هنا
      } catch (error) {
        console.error("Error fetching speech assignments:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchAssignments();
  }, [currentPage, search]);

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
    setCurrentPage(1);
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  // الانتقال لصفحات الاختبار/الفحص مع id المريض الحقيقي (patientId._id)
  const handleTest = (patientId) => {
    router.push(`/speech-test?id=${patientId}`);
  };
  const handleExam = (patientId) => {
    router.push(`/speech-exam?id=${patientId}`);
  };

  return (
    <div className='card h-100 p-0 radius-12'>
      <div className='card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between'>
        <div className='d-flex align-items-center flex-wrap gap-3'>
          <form className='navbar-search'>
            <input
              type='text'
              className='bg-base h-40-px w-auto'
              name='search'
              value={search}
              onChange={handleSearchChange}
              placeholder='Search'
            />
            <Icon icon='ion:search-outline' className='icon' />
          </form>
        </div>
      </div>
      <div className='card-body p-24'>
        <div className='table-responsive scroll-sm'>
          <table className='table bordered-table sm-table mb-0'>
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th className='text-center'>Action</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="7" className="text-center">Loading...</td>
                </tr>
              ) : (
                assignments.map((assignment, index) => {
                  const patient = assignment.patientId; // بيانات المريض من التعيين
                  if (!patient) return null; // لو ما في بيانات مريض نتجاهل الصف

                  return (
                    <tr key={patient._id}>
                      <td>{index + 1}</td>
                      <td>{patient.name}</td>
                      <td>{patient.email}</td>
                      <td>{patient.phone}</td>
                      <td className='text-center'>
                        <div className='d-flex align-items-center gap-10 justify-content-center'>
                          <button
                            type='button'
                            className='bg-primary-focus bg-hover-primary-200 text-primary-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle'
                            onClick={() => handleExam(patient._id)}
                          >
                            <Icon icon='majesticons:eye-line' className='icon text-xl' />
                          </button>
                          <button
                            type='button'
                            className='bg-info-focus bg-hover-info-200 text-info-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle'
                            onClick={() => handleTest(patient._id)}
                          >
                            <Icon icon='majesticons:eye-line' className='icon text-xl' />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        <div className='d-flex align-items-center justify-content-between flex-wrap gap-2 mt-24'>
          <span>
            Showing {((currentPage - 1) * 10) + 1} to {Math.min(currentPage * 10, assignments.length)} of {assignments.length} entries
          </span>
          <ul className='pagination d-flex flex-wrap align-items-center gap-2 justify-content-center'>
            {Array.from({ length: totalPages }, (_, i) => (
              <li key={i} className={`page-item ${currentPage === i + 1 ? 'active' : ''}`}>
                <Link
                  className='page-link text-secondary-light fw-semibold radius-8 border-0 d-flex align-items-center justify-content-center h-32-px  text-md'
                  href="#"
                  onClick={() => handlePageChange(i + 1)}
                >
                  {i + 1}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AllStudentsSpeech;
