import React, { useEffect, useState } from "react";
import axiosInstance from "@/helper/axiosSetup";

// Header component
const Header = ({ isRTL }) => (
  <div
    style={{
      maxWidth: 900,
      margin: "auto",
      fontFamily: "Arial, sans-serif",
      direction: isRTL ? "rtl" : "ltr",
      color: "#000",
      userSelect: "none",
      borderBottom: "3px solid #000",
      paddingBottom: 8,
      marginBottom: 20,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
    }}
  >
    <img
      src="/assets/dlogo.png"
      alt="Rukn Alwatikon Logo"
      style={{ height: 60 }}
    />
    <div style={{ textAlign: "center", flexGrow: 1 }}>
      <div style={{ fontSize: 18, fontWeight: "bold", marginBottom: 4 }}>
        {isRTL
          ? "مركز ركن الوتيقون لتأهيل ذوي الهمم"
          : "Rukn Alwatikon Center for Rehabilitation of People of Determination"}
      </div>
      <div style={{ fontSize: 16, fontWeight: "bold" }}>
        {isRTL
          ? "الخطة العلاجية الفصلية (للغة والتخاطب)"
          : "Quarterly Therapeutic Plan (Speech & Language)"}
      </div>
      <div style={{ marginTop: 6, fontWeight: "bold", fontSize: 14 }}>
        {isRTL ? "العام الدراسي 2025 - 2026" : "Academic Year 2025 - 2026"}
      </div>
    </div>
    <div style={{ width: 60 }} /> {/* spacer */}
  </div>
);

// Footer component
const Footer = ({ isRTL }) => (
  <div
    style={{
      maxWidth: 900,
      margin: "40px auto 20px auto",
      fontFamily: "Arial, sans-serif",
      direction: isRTL ? "rtl" : "ltr",
      color: "#000",
      userSelect: "none",
      borderTop: "3px solid #000",
      paddingTop: 12,
      fontSize: 14,
      display: "flex",
      justifyContent: isRTL ? "flex-start" : "flex-end",
      gap: 30,
      fontWeight: "bold",
    }}
  >
    <div>{isRTL ? "توقيع أخصائي اللغة:" : "Speech Therapist Signature:"} ___________________</div>
    <div>{isRTL ? "التاريخ:" : "Date:"} ___________________</div>
  </div>
);

const SpeechExamTable = ({ patientId, ageRange, language = "ar" }) => {
  const [expressiveQuestions, setExpressiveQuestions] = useState([]);
  const [receptiveQuestions, setReceptiveQuestions] = useState([]);
  const isRTL = language === "ar";

  useEffect(() => {
    if (!patientId || !ageRange) return;

    const qs = `?patientId=${patientId}&ageRange=${encodeURIComponent(ageRange)}`;

    axiosInstance.get(`/authentication/exam/tableexpressive${qs}`)
      .then(({ data }) => setExpressiveQuestions(data.expressiveQuestions || []))
      .catch(() => setExpressiveQuestions([]));

    axiosInstance.get(`/authentication/exam/tablereceptive${qs}`)
      .then(({ data }) => setReceptiveQuestions(data.receptiveQuestions || []))
      .catch(() => setReceptiveQuestions([]));
  }, [patientId, ageRange]);

  const handleCheckboxChange = (section, index) => {
    if(section === "expressive"){
      const updated = [...expressiveQuestions];
      updated[index].response = !updated[index].response;
      setExpressiveQuestions(updated);
    } else {
      const updated = [...receptiveQuestions];
      updated[index].response = !updated[index].response;
      setReceptiveQuestions(updated);
    }
  };

  const renderRows = (questions, section) => {
    if (!questions.length) {
      return (
        <tr>
          <td colSpan={4} style={{ textAlign: "center", color: "#999", fontStyle: "italic", padding: 12 }}>
            {isRTL ? "لا توجد بيانات" : "No data available"}
          </td>
        </tr>
      );
    }

    return questions.map((q, idx) => (
      <tr key={q._id || idx} style={{ backgroundColor: idx % 2 === 1 ? "#f9f1ed" : "transparent" }}>
        <td style={{ border: "1px solid #444", padding: "6px", textAlign: isRTL ? "right" : "left" }}>{q.questionNumber}</td>
        <td style={{ border: "1px solid #444", padding: "6px", textAlign: isRTL ? "right" : "left" }}>{q.questionText}</td>
        <td style={{ border: "1px solid #444", padding: "6px", textAlign: "center" }}>
          <label style={{ cursor: "pointer", userSelect: "none" }}>
            <input
              type="checkbox"
              checked={q.response === true || q.response === "true"}
              onChange={() => handleCheckboxChange(section, idx)}
              style={{ width: 20, height: 20 }}
            />
            <span style={{ marginLeft: 6 }}>
              {(q.response === true || q.response === "true") ? "✓" : "✗"}
            </span>
          </label>
        </td>
        <td style={{ border: "1px solid #444", padding: "6px", textAlign: isRTL ? "right" : "left" }}>{q.notes}</td>
      </tr>
    ));
  };

  const renderTableSection = (title, questions, color, section) => (
    <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: 30 }}>
      <thead>
        <tr>
          <th
            colSpan={5}
            style={{
              backgroundColor: color,
              color: "#fff",
              fontWeight: "bold",
              fontSize: 16,
              textAlign: isRTL ? "right" : "left",
              padding: "8px 12px",
              border: "1px solid #444",
            }}
          >
            {title}
          </th>
        </tr>
        <tr style={{ backgroundColor: "#f0c6ac" }}>
          {[isRTL ? "رقم السؤال" : "Question No.",
            isRTL ? "نص السؤال" : "Question Text",
            isRTL ? "الإجابة" : "Response",
            isRTL ? "ملاحظات" : "Notes",
          ].map((header) => (
            <th
              key={header}
              style={{ border: "1px solid #444", padding: "6px", fontWeight: "bold", textAlign: "center" }}
            >
              {header}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>{renderRows(questions, section)}</tbody>
    </table>
  );

  return (
    <div
      style={{
        fontFamily: "Arial, sans-serif",
        maxWidth: 900,
        margin: "auto",
        direction: isRTL ? "rtl" : "ltr",
        color: "#000",
        userSelect: "none",
      }}
    >
      <Header isRTL={isRTL} />

      <h2 style={{ textAlign: "center", margin: "20px 0" }}>
        {isRTL ? "نتائج تقييم مهارات اللغة" : "Speech Exam Results"}
      </h2>

      {renderTableSection(isRTL ? "مهارات اللغة التعبيرية" : "Expressive Language Skills", expressiveQuestions, "#f4a261", "expressive")}
      {renderTableSection(isRTL ? "مهارات اللغة الاستقبالية" : "Receptive Language Skills", receptiveQuestions, "#2a9d8f", "receptive")}

      <Footer isRTL={isRTL} />
    </div>
  );
};

export default SpeechExamTable;
